-- phpMyAdmin SQL Dump
-- version 5.1.1deb5ubuntu1
-- https://www.phpmyadmin.net/
--
-- Хост: localhost:3306
-- Время создания: Июн 10 2026 г., 10:26
-- Версия сервера: 10.6.23-MariaDB-0ubuntu0.22.04.1
-- Версия PHP: 8.1.2-1ubuntu2.24

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `project_Buziyan`
--

-- --------------------------------------------------------

--
-- Структура таблицы `bios_info`
--

CREATE TABLE `bios_info` (
  `id` int(11) NOT NULL,
  `vendor` varchar(100) DEFAULT NULL,
  `version` varchar(50) DEFAULT NULL,
  `build_date` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `bios_info`
--

INSERT INTO `bios_info` (`id`, `vendor`, `version`, `build_date`) VALUES
(1, 'American Megatrends Inc.', '5.19.01.0011', '03/15/2024');

-- --------------------------------------------------------

--
-- Структура таблицы `bios_logs`
--

CREATE TABLE `bios_logs` (
  `id` int(11) NOT NULL,
  `action` varchar(100) DEFAULT NULL,
  `user_ip` varchar(45) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `bios_logs`
--

INSERT INTO `bios_logs` (`id`, `action`, `user_ip`, `created_at`, `user_id`) VALUES
(1, 'Database initialized with default data', '::1', '2026-04-13 10:34:45', NULL),
(2, 'Database initialized with default data', '::1', '2026-04-13 10:35:21', NULL),
(3, 'Settings saved: 24 settings updated', '::1', '2026-04-13 10:35:23', NULL),
(4, 'Advanced settings saved', '::1', '2026-04-13 10:35:23', NULL),
(5, 'Database initialized with default data', '::1', '2026-04-13 10:35:24', NULL),
(6, 'Database initialized with default data', '::1', '2026-04-13 10:37:23', NULL),
(7, 'Settings saved: 24 settings updated', '::1', '2026-04-13 10:37:25', NULL),
(8, 'Advanced settings saved', '::1', '2026-04-13 10:37:25', NULL),
(9, 'Database initialized with default data', '::1', '2026-04-13 10:37:26', NULL),
(10, 'Database initialized with default data', '::1', '2026-04-13 10:37:39', NULL),
(11, 'Database initialized with default data', '::1', '2026-04-13 10:38:57', NULL),
(12, 'Settings saved: 24 settings updated', '::1', '2026-04-13 10:38:59', NULL),
(13, 'Advanced settings saved', '::1', '2026-04-13 10:39:00', NULL),
(14, 'Database initialized with default data', '::1', '2026-04-13 10:39:00', NULL),
(15, 'Database initialized with default data', '::1', '2026-04-13 10:39:13', NULL),
(16, 'Settings saved: 24 settings updated', '::1', '2026-04-13 10:39:15', NULL),
(17, 'Advanced settings saved', '::1', '2026-04-13 10:39:16', NULL),
(18, 'Database initialized with default data', '::1', '2026-04-13 10:39:16', NULL),
(19, 'Database initialized with default data', '::1', '2026-04-13 10:39:26', NULL),
(20, 'Database initialized with default data', '::1', '2026-04-13 11:03:20', NULL),
(21, 'Database initialized with default data', '::1', '2026-04-13 11:03:27', NULL),
(22, 'Database initialized with default data', '::1', '2026-04-13 11:03:45', NULL),
(23, 'Settings saved: 24 settings updated', '::1', '2026-04-13 11:03:48', NULL),
(24, 'Advanced settings saved', '::1', '2026-04-13 11:03:48', NULL),
(25, 'Database initialized with default data', '::1', '2026-04-13 11:03:48', NULL),
(26, 'Database initialized with default data', '::1', '2026-04-14 02:19:50', NULL),
(27, 'Database initialized with default data', '::1', '2026-04-14 02:20:19', NULL),
(28, 'Settings saved: 24 settings updated', '::1', '2026-04-14 02:20:20', NULL),
(29, 'Advanced settings saved', '::1', '2026-04-14 02:20:20', NULL),
(30, 'Database initialized with default data', '::1', '2026-04-14 02:20:20', NULL),
(31, 'Database initialized with default data', '::1', '2026-04-14 02:23:03', NULL),
(32, 'Settings saved: 2 settings updated', '::1', '2026-04-14 02:23:04', NULL),
(33, 'Main settings saved', '::1', '2026-04-14 02:23:04', NULL),
(34, 'Database initialized with default data', '::1', '2026-04-14 02:23:04', NULL),
(35, 'Database initialized with default data', '::1', '2026-04-14 02:40:14', NULL),
(36, 'Settings saved: 24 settings updated', '::1', '2026-04-14 02:40:14', NULL),
(37, 'Advanced settings saved', '::1', '2026-04-14 02:40:14', NULL),
(38, 'Database initialized with default data', '::1', '2026-04-14 02:40:14', NULL),
(39, 'Database initialized with default data', '::1', '2026-04-14 03:51:16', NULL),
(40, 'Settings saved: 2 settings updated', '::1', '2026-04-14 03:51:16', NULL),
(41, 'Main settings saved', '::1', '2026-04-14 03:51:16', NULL),
(42, 'Database initialized with default data', '::1', '2026-04-14 03:51:16', NULL),
(43, 'Database initialized with default data', '::1', '2026-04-14 04:01:06', NULL),
(44, 'Boot order updated', '::1', '2026-04-14 04:01:06', NULL),
(45, 'Settings saved: 5 settings updated', '::1', '2026-04-14 04:01:06', NULL),
(46, 'Boot settings saved', '::1', '2026-04-14 04:01:06', NULL),
(47, 'Database initialized with default data', '::1', '2026-04-14 04:01:06', NULL),
(48, 'Database initialized with default data', '::1', '2026-04-14 04:06:29', NULL),
(49, 'Boot order updated', '::1', '2026-04-14 04:06:29', NULL),
(50, 'Settings saved: 5 settings updated', '::1', '2026-04-14 04:06:29', NULL),
(51, 'Boot settings saved', '::1', '2026-04-14 04:06:29', NULL),
(52, 'Database initialized with default data', '::1', '2026-04-14 04:06:29', NULL),
(53, 'Database initialized with default data', '::1', '2026-04-14 04:38:57', NULL),
(54, 'Settings saved: 2 settings updated', '::1', '2026-04-14 04:38:57', NULL),
(55, 'Main settings saved', '::1', '2026-04-14 04:38:57', NULL),
(56, 'Database initialized with default data', '::1', '2026-04-14 04:38:57', NULL),
(57, 'Database initialized with default data', '::1', '2026-04-14 04:51:49', NULL),
(58, 'Boot order updated', '::1', '2026-04-14 04:51:49', NULL),
(59, 'Settings saved: 5 settings updated', '::1', '2026-04-14 04:51:49', NULL),
(60, 'Boot settings saved', '::1', '2026-04-14 04:51:49', NULL),
(61, 'Database initialized with default data', '::1', '2026-04-14 04:51:49', NULL),
(62, 'Database initialized with default data', '::1', '2026-04-23 13:01:29', NULL),
(63, 'Database initialized with default data', '::1', '2026-04-27 02:57:06', NULL),
(64, 'Database initialized with default data', '::1', '2026-04-27 03:11:41', NULL),
(65, 'Database initialized with default data', '::1', '2026-04-27 03:22:43', NULL),
(66, 'Database initialized with default data', '::1', '2026-04-27 03:23:05', NULL),
(67, 'Database initialized with default data', '::1', '2026-04-27 03:42:04', NULL),
(68, 'Database initialized with default data', '::1', '2026-04-27 03:42:06', NULL),
(69, 'Database initialized with default data', '::1', '2026-04-27 03:42:08', NULL),
(70, 'Database initialized with default data', '::1', '2026-04-27 03:42:09', NULL),
(71, 'Database initialized with default data', '::1', '2026-04-27 03:42:11', NULL),
(72, 'Database initialized with default data', '::1', '2026-04-27 03:55:59', NULL),
(73, 'Database initialized with default data', '::1', '2026-04-27 04:30:18', NULL),
(74, 'Database initialized with default data', '::1', '2026-04-27 05:34:30', NULL),
(75, 'Database initialized with default data', '::1', '2026-04-27 05:41:59', NULL),
(76, 'Database initialized with default data', '::1', '2026-04-27 05:42:00', NULL),
(77, 'Database initialized with default data', '::1', '2026-04-28 10:40:36', NULL),
(78, 'Database initialized with default data', '::1', '2026-04-28 11:45:00', NULL),
(79, 'Database initialized with default data', '::1', '2026-04-28 11:45:15', NULL),
(80, 'Database initialized with default data', '::1', '2026-04-28 11:46:20', NULL),
(81, 'Database initialized with default data', '::1', '2026-04-28 11:54:23', NULL),
(82, 'Database initialized with default data', '::1', '2026-04-28 11:54:53', NULL),
(83, 'Database initialized with default data', '::1', '2026-04-28 11:57:38', NULL),
(84, 'Database initialized with default data', '::1', '2026-04-28 12:22:22', NULL),
(85, 'Database initialized with default data', '::1', '2026-04-28 12:40:21', NULL),
(86, 'Database initialized with default data', '::1', '2026-04-28 12:42:34', NULL),
(87, 'Database initialized with default data', '::1', '2026-04-28 12:51:49', NULL),
(88, 'Database initialized with default data', '::1', '2026-04-28 12:57:31', NULL),
(89, 'Database initialized with default data', '::1', '2026-04-28 13:08:18', NULL),
(90, 'Database initialized with default data', '::1', '2026-04-28 13:09:32', NULL),
(91, 'Database initialized with default data', '::1', '2026-04-28 13:14:17', NULL),
(92, 'Database initialized with default data', '::1', '2026-04-28 13:17:04', NULL),
(93, 'Database initialized with default data', '::1', '2026-04-28 13:34:08', NULL),
(94, 'Database initialized with default data', '::1', '2026-04-28 14:56:30', NULL),
(95, 'Database initialized with default data', '::1', '2026-04-28 14:59:47', NULL),
(96, 'Database initialized with default data', '::1', '2026-04-28 14:59:50', NULL),
(97, 'Database initialized with default data', '::1', '2026-04-28 14:59:51', NULL),
(98, 'Database initialized with default data', '::1', '2026-05-13 06:50:45', NULL),
(99, 'Database initialized with default data', '::1', '2026-05-13 06:52:48', NULL),
(100, 'Database initialized with default data', '::1', '2026-05-13 06:52:50', NULL),
(101, 'Database initialized with default data', '::1', '2026-05-13 06:52:52', NULL),
(102, 'Database initialized with default data', '::1', '2026-05-13 06:52:53', NULL),
(103, 'Database initialized with default data', '::1', '2026-05-13 06:54:40', NULL),
(104, 'Password set for: admin', '::1', '2026-05-13 06:54:40', NULL),
(105, 'Database initialized with default data', '::1', '2026-05-13 06:54:41', NULL),
(106, 'Database initialized with default data', '::1', '2026-05-13 06:55:35', NULL),
(107, 'Settings saved: 24 settings updated', '::1', '2026-05-13 06:55:39', NULL),
(108, 'Advanced settings saved', '::1', '2026-05-13 06:55:39', NULL),
(109, 'Database initialized with default data', '::1', '2026-05-13 06:55:40', NULL),
(110, 'Database initialized with default data', '::1', '2026-05-13 06:57:05', NULL),
(111, 'Database initialized with default data', '::1', '2026-05-13 06:57:06', NULL),
(112, 'Database initialized with default data', '::1', '2026-05-13 06:57:16', NULL),
(113, 'Database initialized with default data', '::1', '2026-05-13 06:57:28', NULL),
(114, 'Database initialized with default data', '::1', '2026-05-13 06:57:29', NULL),
(115, 'Database initialized with default data', '::1', '2026-05-13 06:57:41', NULL),
(116, 'Database initialized with default data', '::1', '2026-05-13 06:57:42', NULL),
(117, 'Database initialized with default data', '::1', '2026-05-13 06:58:16', NULL),
(118, 'Database initialized with default data', '::1', '2026-05-13 06:58:17', NULL),
(119, 'Database initialized with default data', '::1', '2026-05-13 06:59:30', NULL),
(120, 'Database initialized with default data', '::1', '2026-05-13 06:59:31', NULL),
(121, 'Database initialized with default data', '::1', '2026-05-13 06:59:42', NULL),
(122, 'Database initialized with default data', '::1', '2026-05-13 06:59:43', NULL),
(123, 'Database initialized with default data', '::1', '2026-05-13 08:04:11', NULL),
(124, 'Database initialized with default data', '::1', '2026-05-13 08:04:39', NULL),
(125, 'Database initialized with default data', '::1', '2026-05-13 08:04:40', NULL),
(126, 'Database initialized with default data', '::1', '2026-05-13 08:05:02', NULL),
(127, 'Database initialized with default data', '::1', '2026-05-13 08:05:03', NULL),
(128, 'Database initialized with default data', '::1', '2026-05-13 08:09:54', NULL),
(129, 'Settings saved: 24 settings updated', '::1', '2026-05-13 08:09:58', NULL),
(130, 'Advanced settings saved', '::1', '2026-05-13 08:09:58', NULL),
(131, 'Database initialized with default data', '::1', '2026-05-13 08:09:59', NULL),
(132, 'Database initialized with default data', '::1', '2026-05-13 08:10:12', NULL),
(133, 'Database initialized with default data', '::1', '2026-05-13 08:10:13', NULL),
(134, 'Database initialized with default data', '::1', '2026-05-13 08:10:32', NULL),
(135, 'Database initialized with default data', '::1', '2026-05-13 08:10:33', NULL),
(136, 'Database initialized with default data', '::1', '2026-05-13 08:23:18', NULL),
(137, 'Database initialized with default data', '::1', '2026-05-13 08:23:19', NULL),
(138, 'Database initialized with default data', '::1', '2026-05-13 08:51:57', NULL),
(139, 'Database initialized with default data', '::1', '2026-05-13 08:52:30', NULL),
(140, 'Database initialized with default data', '::1', '2026-05-13 08:52:58', NULL),
(141, 'Database initialized with default data', '::1', '2026-05-13 08:52:59', NULL),
(142, 'Database initialized with default data', '::1', '2026-05-13 08:57:05', NULL),
(143, 'Database initialized with default data', '::1', '2026-05-13 08:57:06', NULL),
(144, 'Database initialized with default data', '::1', '2026-05-13 08:57:27', NULL),
(145, 'Settings saved: 24 settings updated', '::1', '2026-05-13 08:57:30', NULL),
(146, 'Advanced settings saved', '::1', '2026-05-13 08:57:30', NULL),
(147, 'Database initialized with default data', '::1', '2026-05-13 08:57:31', NULL),
(148, 'Database initialized with default data', '::1', '2026-05-13 08:58:09', NULL),
(149, 'Database initialized with default data', '::1', '2026-05-13 08:58:10', NULL),
(150, 'Database initialized with default data', '::1', '2026-05-13 08:58:33', NULL),
(151, 'Database initialized with default data', '::1', '2026-05-13 09:35:49', NULL),
(152, 'Password removed for: admin', '::1', '2026-05-13 09:35:50', NULL),
(153, 'Database initialized with default data', '::1', '2026-05-13 09:35:51', NULL),
(154, 'Database initialized with default data', '::1', '2026-05-13 09:44:11', NULL),
(155, 'Database initialized with default data', '::1', '2026-05-13 09:44:12', NULL),
(156, 'Database initialized with default data', '::1', '2026-05-13 09:52:47', NULL),
(157, 'Database initialized with default data', '::1', '2026-05-13 09:52:48', NULL),
(158, 'Database initialized with default data', '::1', '2026-05-13 10:08:31', NULL),
(159, 'Database initialized with default data', '::1', '2026-05-17 16:40:13', NULL),
(160, 'Database initialized with default data', '::1', '2026-05-17 16:40:30', NULL),
(161, 'Database initialized with default data', '::1', '2026-05-17 16:40:30', NULL),
(162, 'Database initialized with default data', '::1', '2026-05-17 16:40:47', NULL),
(163, 'Database initialized with default data', '::1', '2026-05-17 16:40:48', NULL),
(164, 'Database initialized with default data', '::1', '2026-05-17 16:44:11', NULL),
(165, 'Boot order updated for user 2', '::1', '2026-05-17 16:44:11', NULL),
(166, 'Settings saved: 5 settings updated', '::1', '2026-05-17 16:44:12', NULL),
(167, 'Boot settings saved', '::1', '2026-05-17 16:44:12', NULL),
(168, 'Database initialized with default data', '::1', '2026-05-17 16:44:13', NULL),
(169, 'Database initialized with default data', '::1', '2026-05-17 16:44:20', NULL),
(170, 'Database initialized with default data', '::1', '2026-05-17 16:44:20', NULL),
(171, 'Database initialized with default data', '::1', '2026-05-17 16:44:47', NULL),
(172, 'Database initialized with default data', '::1', '2026-05-17 16:44:48', NULL),
(173, 'Database initialized with default data', '::1', '2026-05-17 16:45:34', NULL),
(174, 'Database initialized with default data', '::1', '2026-05-17 16:45:35', NULL),
(175, 'Database initialized with default data', '::1', '2026-05-17 16:46:22', NULL),
(176, 'Database initialized with default data', '::1', '2026-05-17 16:46:23', NULL),
(177, 'Database initialized with default data', '::1', '2026-05-17 16:47:07', NULL),
(178, 'Database initialized with default data', '::1', '2026-05-17 16:47:08', NULL),
(179, 'Database initialized with default data', '::1', '2026-05-17 16:47:33', NULL),
(180, 'Database initialized with default data', '::1', '2026-05-17 16:47:34', NULL),
(181, 'Database initialized with default data', '::1', '2026-05-17 16:48:13', NULL),
(182, 'Settings saved: 24 settings updated', '::1', '2026-05-17 16:48:15', NULL),
(183, 'Advanced settings saved', '::1', '2026-05-17 16:48:15', NULL),
(184, 'Database initialized with default data', '::1', '2026-05-17 16:48:16', NULL),
(185, 'Database initialized with default data', '::1', '2026-05-17 16:48:29', NULL),
(186, 'Settings saved: 24 settings updated', '::1', '2026-05-17 16:48:31', NULL),
(187, 'Advanced settings saved', '::1', '2026-05-17 16:48:31', NULL),
(188, 'Database initialized with default data', '::1', '2026-05-17 16:48:32', NULL),
(189, 'Database initialized with default data', '::1', '2026-05-17 16:52:21', NULL),
(190, 'Settings saved: 24 settings updated', '::1', '2026-05-17 16:52:23', NULL),
(191, 'Advanced settings saved', '::1', '2026-05-17 16:52:23', NULL),
(192, 'Database initialized with default data', '::1', '2026-05-17 16:52:24', NULL),
(193, 'Database initialized with default data', '::1', '2026-05-17 16:53:30', NULL),
(194, 'Settings saved: 24 settings updated', '::1', '2026-05-17 16:53:32', NULL),
(195, 'Advanced settings saved', '::1', '2026-05-17 16:53:32', NULL),
(196, 'Database initialized with default data', '::1', '2026-05-17 16:53:33', NULL),
(197, 'Database initialized with default data', '::1', '2026-05-26 04:42:20', NULL),
(198, 'Database initialized with default data', '::1', '2026-05-27 10:39:45', NULL),
(199, 'Database initialized with default data', '::1', '2026-05-29 07:32:43', NULL),
(200, 'Database initialized with default data', '::1', '2026-06-10 02:31:59', NULL),
(201, 'Database initialized with default data', '::1', '2026-06-10 02:33:44', NULL),
(202, 'Database initialized with default data', '::1', '2026-06-10 02:33:44', NULL),
(203, 'Database initialized with default data', '::1', '2026-06-10 02:34:05', NULL),
(204, 'Database initialized with default data', '::1', '2026-06-10 02:34:05', NULL),
(205, 'Database initialized with default data', '::1', '2026-06-10 02:34:12', NULL),
(206, 'Database initialized with default data', '::1', '2026-06-10 02:34:12', NULL),
(207, 'Database initialized with default data', '::1', '2026-06-10 02:34:20', NULL),
(208, 'Database initialized with default data', '::1', '2026-06-10 02:34:20', NULL),
(209, 'Database initialized with default data', '::1', '2026-06-10 02:35:05', NULL),
(210, 'Database initialized with default data', '::1', '2026-06-10 02:35:06', 4),
(211, 'Database initialized with default data', '::1', '2026-06-10 02:35:27', 4),
(212, 'Boot order updated for user 4', '::1', '2026-06-10 02:35:27', 4),
(213, 'Settings saved: 5 settings updated', '::1', '2026-06-10 02:35:27', 4),
(214, 'Boot settings saved', '::1', '2026-06-10 02:35:27', 4),
(215, 'Database initialized with default data', '::1', '2026-06-10 02:35:27', 4),
(216, 'Database initialized with default data', '::1', '2026-06-10 02:35:36', 4),
(217, 'Boot order updated for user 4', '::1', '2026-06-10 02:35:36', 4),
(218, 'Settings saved: 5 settings updated', '::1', '2026-06-10 02:35:36', 4),
(219, 'Boot settings saved', '::1', '2026-06-10 02:35:36', 4),
(220, 'Database initialized with default data', '::1', '2026-06-10 02:35:37', 4),
(221, 'Database initialized with default data', '::1', '2026-06-10 02:37:38', 4),
(222, 'Settings saved: 2 settings updated', '::1', '2026-06-10 02:37:38', 4),
(223, 'Main settings saved', '::1', '2026-06-10 02:37:38', 4),
(224, 'Database initialized with default data', '::1', '2026-06-10 02:37:38', 4),
(225, 'Database initialized with default data', '::1', '2026-06-10 02:40:40', 4),
(226, 'Database initialized with default data', '::1', '2026-06-10 02:40:40', NULL),
(227, 'Database initialized with default data', '::1', '2026-06-10 02:40:49', NULL),
(228, 'Database initialized with default data', '::1', '2026-06-10 02:41:03', NULL),
(229, 'Database initialized with default data', '::1', '2026-06-10 02:41:04', 4),
(230, 'Database initialized with default data', '::1', '2026-06-10 02:46:53', 4),
(231, 'Database initialized with default data', '::1', '2026-06-10 02:46:55', 4),
(232, 'Database initialized with default data', '::1', '2026-06-10 02:46:55', NULL),
(233, 'Database initialized with default data', '::1', '2026-06-10 02:46:59', NULL),
(234, 'Database initialized with default data', '::1', '2026-06-10 02:47:26', NULL),
(235, 'Database initialized with default data', '::1', '2026-06-10 02:47:26', 4),
(236, 'Database initialized with default data', '::1', '2026-06-10 02:48:40', 4),
(237, 'Settings saved: 2 settings updated', '::1', '2026-06-10 02:48:40', 4),
(238, 'Main settings saved', '::1', '2026-06-10 02:48:41', 4),
(239, 'Database initialized with default data', '::1', '2026-06-10 02:48:41', 4),
(240, 'Database initialized with default data', '::1', '2026-06-10 02:49:18', 4),
(241, 'Database initialized with default data', '::1', '2026-06-10 02:49:18', NULL),
(242, 'Database initialized with default data', '::1', '2026-06-10 02:50:13', NULL),
(243, 'Database initialized with default data', '::1', '2026-06-10 02:50:13', 4),
(244, 'Database initialized with default data', '::1', '2026-06-10 02:50:23', 4),
(245, 'Boot order updated for user 4', '::1', '2026-06-10 02:50:23', 4),
(246, 'Settings saved: 5 settings updated', '::1', '2026-06-10 02:50:23', 4),
(247, 'Boot settings saved', '::1', '2026-06-10 02:50:23', 4),
(248, 'Database initialized with default data', '::1', '2026-06-10 02:50:23', 4),
(249, 'Database initialized with default data', '::1', '2026-06-10 02:52:39', 4),
(250, 'Settings saved: 2 settings updated', '::1', '2026-06-10 02:52:39', 4),
(251, 'Main settings saved', '::1', '2026-06-10 02:52:39', 4),
(252, 'Database initialized with default data', '::1', '2026-06-10 02:52:40', 4),
(253, 'Database initialized with default data', '::1', '2026-06-10 02:52:45', 4),
(254, 'Database initialized with default data', '::1', '2026-06-10 02:52:45', NULL),
(255, 'Database initialized with default data', '::1', '2026-06-10 02:52:54', NULL),
(256, 'Database initialized with default data', '::1', '2026-06-10 02:52:54', 4),
(257, 'Database initialized with default data', '::1', '2026-06-10 03:06:50', 4),
(258, 'Database initialized with default data', '::1', '2026-06-10 03:06:50', NULL),
(259, 'Database initialized with default data', '::1', '2026-06-10 03:07:02', NULL),
(260, 'Database initialized with default data', '::1', '2026-06-10 03:07:03', NULL),
(261, 'Database initialized with default data', '::1', '2026-06-10 03:07:17', NULL),
(262, 'Database initialized with default data', '::1', '2026-06-10 03:07:18', NULL),
(263, 'Database initialized with default data', '::1', '2026-06-10 03:07:28', NULL),
(264, 'Database initialized with default data', '::1', '2026-06-10 03:07:28', NULL),
(265, 'Database initialized with default data', '::1', '2026-06-10 03:15:08', NULL),
(266, 'Database initialized with default data', '::1', '2026-06-10 03:15:20', NULL),
(267, 'Database initialized with default data', '::1', '2026-06-10 03:15:20', NULL),
(268, 'Database initialized with default data', '::1', '2026-06-10 03:18:39', NULL),
(269, 'Database initialized with default data', '::1', '2026-06-10 03:20:47', NULL),
(270, 'Database initialized with default data', '::1', '2026-06-10 03:20:58', NULL),
(271, 'Database initialized with default data', '::1', '2026-06-10 03:20:58', 1),
(272, 'Database initialized with default data', '::1', '2026-06-10 03:21:09', 1),
(273, 'Database initialized with default data', '::1', '2026-06-10 03:21:09', NULL),
(274, 'Database initialized with default data', '::1', '2026-06-10 03:21:19', NULL),
(275, 'Database initialized with default data', '::1', '2026-06-10 03:21:19', 2),
(276, 'Database initialized with default data', '::1', '2026-06-10 03:21:20', 2),
(277, 'Database initialized with default data', '::1', '2026-06-10 03:21:21', NULL),
(278, 'Database initialized with default data', '::1', '2026-06-10 03:21:28', NULL),
(279, 'Database initialized with default data', '::1', '2026-06-10 03:21:28', 3),
(280, 'Database initialized with default data', '::1', '2026-06-10 03:21:36', 3),
(281, 'Database initialized with default data', '::1', '2026-06-10 03:21:36', NULL),
(282, 'Database initialized with default data', '::1', '2026-06-10 03:23:56', NULL),
(283, 'Database initialized with default data', '::1', '2026-06-10 03:24:28', NULL),
(284, 'Database initialized with default data', '::1', '2026-06-10 03:24:28', 4);

-- --------------------------------------------------------

--
-- Структура таблицы `bios_settings`
--

CREATE TABLE `bios_settings` (
  `id` int(11) NOT NULL,
  `setting_name` varchar(100) NOT NULL,
  `setting_value` text DEFAULT NULL,
  `category` varchar(50) DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `bios_id` int(11) NOT NULL DEFAULT 1,
  `user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `bios_settings`
--

INSERT INTO `bios_settings` (`id`, `setting_name`, `setting_value`, `category`, `updated_at`, `bios_id`, `user_id`) VALUES
(1, 'system_date', '2026-04-14', 'main', '2026-04-14 04:38:57', 1, NULL),
(2, 'system_time', '14:30:00', 'main', '2026-04-14 04:38:57', 1, NULL),
(3, 'vt_x', '0', 'advanced', '2026-04-14 02:40:14', 1, NULL),
(4, 'hyper_threading', '0', 'advanced', '2026-04-14 02:40:14', 1, NULL),
(5, 'turbo_mode', '0', 'advanced', '2026-04-14 02:40:14', 1, NULL),
(6, 'c_state', '0', 'advanced', '2026-04-14 02:40:14', 1, NULL),
(7, 'active_cores', '1', 'advanced', '2026-04-14 02:40:14', 1, NULL),
(8, 'sata_controller', '1', 'advanced', '2026-04-14 02:40:14', 1, NULL),
(9, 'sata_mode', 'ahci', 'advanced', '2026-04-14 02:40:14', 1, NULL),
(10, 'hot_plug', '0', 'advanced', '2026-04-14 02:40:14', 1, NULL),
(11, 'legacy_usb', 'enabled', 'advanced', '2026-04-14 02:40:14', 1, NULL),
(12, 'xhci_handoff', '1', 'advanced', '2026-04-14 02:40:14', 1, NULL),
(13, 'usb_mass_storage', '1', 'advanced', '2026-04-14 02:40:14', 1, NULL),
(14, 'fast_boot', '1', 'boot', '2026-04-14 04:51:49', 1, NULL),
(15, 'boot_logo', '0', 'boot', '2026-04-14 04:51:49', 1, NULL),
(16, 'quiet_boot', '1', 'boot', '2026-04-14 04:51:49', 1, NULL),
(17, 'csm_support', 'enabled', 'boot', '2026-04-14 04:51:49', 1, NULL),
(18, 'secure_boot', 'custom', 'boot', '2026-04-14 04:51:49', 1, NULL),
(19, 'speedstep', 'enabled', 'general', '2026-04-14 02:40:14', 1, NULL),
(20, 'pcie_root_port', 'enabled', 'general', '2026-04-14 02:40:14', 1, NULL),
(21, 'pcie_link_speed', 'auto', 'general', '2026-04-14 02:40:14', 1, NULL),
(22, 'above_4g', '1', 'general', '2026-04-14 02:40:14', 1, NULL),
(23, 'resize_bar', '0', 'general', '2026-04-14 02:40:14', 1, NULL),
(24, 'sr_iov', '0', 'general', '2026-04-14 02:40:14', 1, NULL),
(25, 'acpi_auto', '1', 'general', '2026-04-14 02:40:14', 1, NULL),
(26, 'acpi_sleep_state', 's3', 'general', '2026-04-14 02:40:14', 1, NULL),
(27, 'tpm_support', '1', 'general', '2026-04-14 02:40:14', 1, NULL),
(28, 'tpm_state', 'enabled', 'general', '2026-04-14 02:40:14', 1, NULL),
(29, 'network_stack', '1', 'general', '2026-04-14 02:40:14', 1, NULL),
(30, 'ipv4_pxe', '1', 'general', '2026-04-14 02:40:14', 1, NULL),
(31, 'ipv6_pxe', '1', 'general', '2026-04-14 02:40:14', 1, NULL),
(32, 'system_date', '2026-04-14', 'main', '2026-05-13 06:52:49', 1, 1),
(33, 'system_time', '14:30:00', 'main', '2026-05-13 06:52:49', 1, 1),
(34, 'vt_x', '1', 'advanced', '2026-05-13 06:55:35', 1, 1),
(35, 'hyper_threading', '1', 'advanced', '2026-05-13 06:55:35', 1, 1),
(36, 'turbo_mode', '1', 'advanced', '2026-05-13 06:55:36', 1, 1),
(37, 'c_state', '1', 'advanced', '2026-05-13 06:55:36', 1, 1),
(38, 'active_cores', '1', 'advanced', '2026-05-13 06:55:35', 1, 1),
(39, 'sata_controller', '1', 'advanced', '2026-05-13 06:55:36', 1, 1),
(40, 'sata_mode', 'ahci', 'advanced', '2026-05-13 06:55:36', 1, 1),
(41, 'hot_plug', '1', 'advanced', '2026-05-13 06:55:36', 1, 1),
(42, 'legacy_usb', 'enabled', 'advanced', '2026-05-13 06:55:36', 1, 1),
(43, 'xhci_handoff', '1', 'advanced', '2026-05-13 06:55:37', 1, 1),
(44, 'usb_mass_storage', '1', 'advanced', '2026-05-13 06:55:37', 1, 1),
(45, 'fast_boot', '1', 'boot', '2026-05-13 06:52:49', 1, 1),
(46, 'boot_logo', '0', 'boot', '2026-05-13 06:52:49', 1, 1),
(47, 'quiet_boot', '1', 'boot', '2026-05-13 06:52:49', 1, 1),
(48, 'csm_support', 'enabled', 'boot', '2026-05-13 06:52:49', 1, 1),
(49, 'secure_boot', 'custom', 'boot', '2026-05-13 06:52:49', 1, 1),
(50, 'speedstep', 'enabled', 'general', '2026-05-13 06:55:36', 1, 1),
(51, 'pcie_root_port', 'enabled', 'general', '2026-05-13 06:55:37', 1, 1),
(52, 'pcie_link_speed', 'auto', 'general', '2026-05-13 06:55:37', 1, 1),
(53, 'above_4g', '1', 'general', '2026-05-13 06:55:37', 1, 1),
(54, 'resize_bar', '1', 'general', '2026-05-13 06:55:37', 1, 1),
(55, 'sr_iov', '0', 'general', '2026-05-13 06:55:37', 1, 1),
(56, 'acpi_auto', '1', 'general', '2026-05-13 06:55:38', 1, 1),
(57, 'acpi_sleep_state', 's3', 'general', '2026-05-13 06:55:38', 1, 1),
(58, 'tpm_support', '1', 'general', '2026-05-13 06:55:38', 1, 1),
(59, 'tpm_state', 'enabled', 'general', '2026-05-13 06:55:38', 1, 1),
(60, 'network_stack', '1', 'general', '2026-05-13 06:55:38', 1, 1),
(61, 'ipv4_pxe', '1', 'general', '2026-05-13 06:55:38', 1, 1),
(62, 'ipv6_pxe', '1', 'general', '2026-05-13 06:55:38', 1, 1),
(63, 'system_date', '2026-04-14', 'main', '2026-05-13 06:58:16', 1, 2),
(64, 'system_time', '14:30:00', 'main', '2026-05-13 06:58:16', 1, 2),
(65, 'vt_x', '0', 'advanced', '2026-05-17 16:53:30', 1, 2),
(66, 'hyper_threading', '0', 'advanced', '2026-05-17 16:53:30', 1, 2),
(67, 'turbo_mode', '0', 'advanced', '2026-05-17 16:53:30', 1, 2),
(68, 'c_state', '0', 'advanced', '2026-05-17 16:53:31', 1, 2),
(69, 'active_cores', '1', 'advanced', '2026-05-17 16:53:30', 1, 2),
(70, 'sata_controller', '1', 'advanced', '2026-05-17 16:53:31', 1, 2),
(71, 'sata_mode', 'ahci', 'advanced', '2026-05-17 16:53:31', 1, 2),
(72, 'hot_plug', '0', 'advanced', '2026-05-17 16:53:31', 1, 2),
(73, 'legacy_usb', 'enabled', 'advanced', '2026-05-17 16:53:31', 1, 2),
(74, 'xhci_handoff', '0', 'advanced', '2026-05-17 16:53:31', 1, 2),
(75, 'usb_mass_storage', '0', 'advanced', '2026-05-17 16:53:31', 1, 2),
(76, 'fast_boot', '1', 'boot', '2026-05-17 16:44:12', 1, 2),
(77, 'boot_logo', '0', 'boot', '2026-05-17 16:44:12', 1, 2),
(78, 'quiet_boot', '1', 'boot', '2026-05-17 16:44:12', 1, 2),
(79, 'csm_support', 'enabled', 'boot', '2026-05-17 16:44:12', 1, 2),
(80, 'secure_boot', 'custom', 'boot', '2026-05-17 16:44:12', 1, 2),
(81, 'speedstep', 'enabled', 'general', '2026-05-17 16:53:30', 1, 2),
(82, 'pcie_root_port', 'enabled', 'general', '2026-05-17 16:53:31', 1, 2),
(83, 'pcie_link_speed', 'auto', 'general', '2026-05-17 16:53:31', 1, 2),
(84, 'above_4g', '1', 'general', '2026-05-17 16:53:31', 1, 2),
(85, 'resize_bar', '0', 'general', '2026-05-17 16:53:31', 1, 2),
(86, 'sr_iov', '0', 'general', '2026-05-17 16:53:31', 1, 2),
(87, 'acpi_auto', '1', 'general', '2026-05-17 16:53:32', 1, 2),
(88, 'acpi_sleep_state', 's3', 'general', '2026-05-17 16:53:32', 1, 2),
(89, 'tpm_support', '1', 'general', '2026-05-17 16:53:32', 1, 2),
(90, 'tpm_state', 'enabled', 'general', '2026-05-17 16:53:32', 1, 2),
(91, 'network_stack', '1', 'general', '2026-05-17 16:53:32', 1, 2),
(92, 'ipv4_pxe', '1', 'general', '2026-05-17 16:53:32', 1, 2),
(93, 'ipv6_pxe', '1', 'general', '2026-05-17 16:53:32', 1, 2),
(94, 'system_date', '2026-04-14', 'main', '2026-05-17 16:46:22', 1, 3),
(95, 'system_time', '14:30:00', 'main', '2026-05-17 16:46:22', 1, 3),
(96, 'vt_x', '0', 'advanced', '2026-05-17 16:46:22', 1, 3),
(97, 'hyper_threading', '0', 'advanced', '2026-05-17 16:46:22', 1, 3),
(98, 'turbo_mode', '0', 'advanced', '2026-05-17 16:46:22', 1, 3),
(99, 'c_state', '0', 'advanced', '2026-05-17 16:46:22', 1, 3),
(100, 'active_cores', '1', 'advanced', '2026-05-17 16:46:22', 1, 3),
(101, 'sata_controller', '1', 'advanced', '2026-05-17 16:46:22', 1, 3),
(102, 'sata_mode', 'ahci', 'advanced', '2026-05-17 16:46:22', 1, 3),
(103, 'hot_plug', '0', 'advanced', '2026-05-17 16:46:22', 1, 3),
(104, 'legacy_usb', 'enabled', 'advanced', '2026-05-17 16:46:22', 1, 3),
(105, 'xhci_handoff', '1', 'advanced', '2026-05-17 16:46:22', 1, 3),
(106, 'usb_mass_storage', '1', 'advanced', '2026-05-17 16:46:22', 1, 3),
(107, 'fast_boot', '1', 'boot', '2026-05-17 16:46:22', 1, 3),
(108, 'boot_logo', '0', 'boot', '2026-05-17 16:46:22', 1, 3),
(109, 'quiet_boot', '1', 'boot', '2026-05-17 16:46:22', 1, 3),
(110, 'csm_support', 'enabled', 'boot', '2026-05-17 16:46:22', 1, 3),
(111, 'secure_boot', 'custom', 'boot', '2026-05-17 16:46:22', 1, 3),
(112, 'speedstep', 'enabled', 'general', '2026-05-17 16:46:22', 1, 3),
(113, 'pcie_root_port', 'enabled', 'general', '2026-05-17 16:46:22', 1, 3),
(114, 'pcie_link_speed', 'auto', 'general', '2026-05-17 16:46:22', 1, 3),
(115, 'above_4g', '1', 'general', '2026-05-17 16:46:22', 1, 3),
(116, 'resize_bar', '0', 'general', '2026-05-17 16:46:22', 1, 3),
(117, 'sr_iov', '0', 'general', '2026-05-17 16:46:22', 1, 3),
(118, 'acpi_auto', '1', 'general', '2026-05-17 16:46:22', 1, 3),
(119, 'acpi_sleep_state', 's3', 'general', '2026-05-17 16:46:22', 1, 3),
(120, 'tpm_support', '1', 'general', '2026-05-17 16:46:22', 1, 3),
(121, 'tpm_state', 'enabled', 'general', '2026-05-17 16:46:22', 1, 3),
(122, 'network_stack', '1', 'general', '2026-05-17 16:46:22', 1, 3),
(123, 'ipv4_pxe', '1', 'general', '2026-05-17 16:46:22', 1, 3),
(124, 'ipv6_pxe', '1', 'general', '2026-05-17 16:46:22', 1, 3),
(125, 'pch_thermal', '1', 'chipset', '2026-05-17 17:13:19', 1, NULL),
(126, 'hpet', '1', 'chipset', '2026-05-17 17:13:19', 1, NULL),
(127, 'dmi_speed', 'auto', 'chipset', '2026-05-17 17:13:19', 1, NULL),
(128, 'vt_d', '1', 'chipset', '2026-05-17 17:13:19', 1, NULL),
(129, 'memory_profile', 'auto', 'chipset', '2026-05-17 17:13:19', 1, NULL),
(130, 'mem_freq', 'auto', 'chipset', '2026-05-17 17:13:19', 1, NULL),
(131, 'mem_fast_boot', '1', 'chipset', '2026-05-17 17:13:19', 1, NULL),
(132, 'primary_gpu', 'auto', 'chipset', '2026-05-17 17:13:19', 1, NULL),
(133, 'internal_gpu', 'auto', 'chipset', '2026-05-17 17:13:19', 1, NULL),
(134, 'pcie_speed', 'auto', 'chipset', '2026-05-17 17:13:19', 1, NULL),
(135, 'sr_iov', '0', 'general', '2026-05-17 17:13:19', 1, NULL),
(136, 'acpi_auto', '1', 'general', '2026-05-17 17:13:19', 1, NULL),
(137, 'acpi_sleep_state', 's3', 'general', '2026-05-17 17:13:19', 1, NULL),
(138, 'tpm_support', '1', 'general', '2026-05-17 17:13:19', 1, NULL),
(139, 'tpm_state', 'enabled', 'general', '2026-05-17 17:13:19', 1, NULL),
(140, 'network_stack', '0', 'general', '2026-05-17 17:13:19', 1, NULL),
(141, 'ipv4_pxe', '0', 'general', '2026-05-17 17:13:19', 1, NULL),
(142, 'ipv6_pxe', '0', 'general', '2026-05-17 17:13:19', 1, NULL),
(143, 'pcie_root_port', 'enabled', 'general', '2026-05-17 17:13:19', 1, NULL),
(144, 'pcie_link_speed', 'auto', 'general', '2026-05-17 17:13:19', 1, NULL),
(145, 'above_4g', '1', 'general', '2026-05-17 17:13:19', 1, NULL),
(146, 'resize_bar', '0', 'general', '2026-05-17 17:13:19', 1, NULL),
(147, 'system_date', '2006-12-01', 'main', '2026-06-10 02:52:39', 1, 4),
(148, 'system_time', '14:30:00', 'main', '2026-06-10 02:52:39', 1, 4),
(149, 'vt_x', '0', 'advanced', '2026-06-10 02:35:06', 1, 4),
(150, 'hyper_threading', '0', 'advanced', '2026-06-10 02:35:06', 1, 4),
(151, 'turbo_mode', '0', 'advanced', '2026-06-10 02:35:06', 1, 4),
(152, 'c_state', '0', 'advanced', '2026-06-10 02:35:06', 1, 4),
(153, 'active_cores', '1', 'advanced', '2026-06-10 02:35:06', 1, 4),
(154, 'sata_controller', '1', 'advanced', '2026-06-10 02:35:06', 1, 4),
(155, 'sata_mode', 'ahci', 'advanced', '2026-06-10 02:35:06', 1, 4),
(156, 'hot_plug', '0', 'advanced', '2026-06-10 02:35:06', 1, 4),
(157, 'legacy_usb', 'enabled', 'advanced', '2026-06-10 02:35:06', 1, 4),
(158, 'xhci_handoff', '1', 'advanced', '2026-06-10 02:35:06', 1, 4),
(159, 'usb_mass_storage', '1', 'advanced', '2026-06-10 02:35:06', 1, 4),
(160, 'fast_boot', '1', 'boot', '2026-06-10 02:50:23', 1, 4),
(161, 'boot_logo', '0', 'boot', '2026-06-10 02:50:23', 1, 4),
(162, 'quiet_boot', '1', 'boot', '2026-06-10 02:50:23', 1, 4),
(163, 'csm_support', 'enabled', 'boot', '2026-06-10 02:50:23', 1, 4),
(164, 'secure_boot', 'custom', 'boot', '2026-06-10 02:50:23', 1, 4),
(165, 'speedstep', 'enabled', 'general', '2026-06-10 02:35:06', 1, 4),
(166, 'pcie_root_port', 'enabled', 'general', '2026-06-10 02:35:06', 1, 4),
(167, 'pcie_link_speed', 'auto', 'general', '2026-06-10 02:35:06', 1, 4),
(168, 'above_4g', '1', 'general', '2026-06-10 02:35:06', 1, 4),
(169, 'resize_bar', '0', 'general', '2026-06-10 02:35:06', 1, 4),
(170, 'sr_iov', '0', 'general', '2026-06-10 02:35:06', 1, 4),
(171, 'acpi_auto', '1', 'general', '2026-06-10 02:35:06', 1, 4),
(172, 'acpi_sleep_state', 's3', 'general', '2026-06-10 02:35:06', 1, 4),
(173, 'tpm_support', '1', 'general', '2026-06-10 02:35:06', 1, 4),
(174, 'tpm_state', 'enabled', 'general', '2026-06-10 02:35:06', 1, 4),
(175, 'network_stack', '1', 'general', '2026-06-10 02:35:06', 1, 4),
(176, 'ipv4_pxe', '1', 'general', '2026-06-10 02:35:06', 1, 4),
(177, 'ipv6_pxe', '1', 'general', '2026-06-10 02:35:06', 1, 4),
(178, 'pch_thermal', '1', 'chipset', '2026-06-10 02:35:06', 1, 4),
(179, 'hpet', '1', 'chipset', '2026-06-10 02:35:06', 1, 4),
(180, 'dmi_speed', 'auto', 'chipset', '2026-06-10 02:35:06', 1, 4),
(181, 'vt_d', '1', 'chipset', '2026-06-10 02:35:06', 1, 4),
(182, 'memory_profile', 'auto', 'chipset', '2026-06-10 02:35:06', 1, 4),
(183, 'mem_freq', 'auto', 'chipset', '2026-06-10 02:35:06', 1, 4),
(184, 'mem_fast_boot', '1', 'chipset', '2026-06-10 02:35:06', 1, 4),
(185, 'primary_gpu', 'auto', 'chipset', '2026-06-10 02:35:06', 1, 4),
(186, 'internal_gpu', 'auto', 'chipset', '2026-06-10 02:35:06', 1, 4),
(187, 'pcie_speed', 'auto', 'chipset', '2026-06-10 02:35:06', 1, 4),
(188, 'sr_iov', '0', 'general', '2026-06-10 02:35:06', 1, 4),
(189, 'acpi_auto', '1', 'general', '2026-06-10 02:35:06', 1, 4),
(190, 'acpi_sleep_state', 's3', 'general', '2026-06-10 02:35:06', 1, 4),
(191, 'tpm_support', '1', 'general', '2026-06-10 02:35:06', 1, 4),
(192, 'tpm_state', 'enabled', 'general', '2026-06-10 02:35:06', 1, 4),
(193, 'network_stack', '0', 'general', '2026-06-10 02:35:06', 1, 4),
(194, 'ipv4_pxe', '0', 'general', '2026-06-10 02:35:06', 1, 4),
(195, 'ipv6_pxe', '0', 'general', '2026-06-10 02:35:06', 1, 4),
(196, 'pcie_root_port', 'enabled', 'general', '2026-06-10 02:35:06', 1, 4),
(197, 'pcie_link_speed', 'auto', 'general', '2026-06-10 02:35:06', 1, 4),
(198, 'above_4g', '1', 'general', '2026-06-10 02:35:06', 1, 4),
(199, 'resize_bar', '0', 'general', '2026-06-10 02:35:06', 1, 4);

-- --------------------------------------------------------

--
-- Структура таблицы `boot_order`
--

CREATE TABLE `boot_order` (
  `id` int(11) NOT NULL,
  `device_name` varchar(50) NOT NULL,
  `device_type` varchar(30) DEFAULT NULL,
  `priority` int(11) DEFAULT 0,
  `is_enabled` tinyint(1) DEFAULT 1,
  `bios_id` int(11) NOT NULL DEFAULT 1,
  `user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `boot_order`
--

INSERT INTO `boot_order` (`id`, `device_name`, `device_type`, `priority`, `is_enabled`, `bios_id`, `user_id`) VALUES
(1, 'Windows Boot Manager', 'windows', 5, 1, 1, NULL),
(2, 'SATA SSD: Samsung 970 EVO', 'ssd', 4, 1, 1, NULL),
(3, 'SATA HDD: WD Blue 1TB', 'hdd', 3, 1, 1, NULL),
(4, 'USB Drive', 'usb', 2, 1, 1, NULL),
(5, 'CD/DVD-ROM Drive', 'cdrom', 6, 1, 1, NULL),
(6, 'Network: PXE Boot', 'network', 1, 1, 1, NULL),
(7, 'Windows Boot Manager', 'windows', 5, 1, 1, 1),
(8, 'SATA SSD: Samsung 970 EVO', 'ssd', 4, 1, 1, 1),
(9, 'SATA HDD: WD Blue 1TB', 'hdd', 3, 1, 1, 1),
(10, 'USB Drive', 'usb', 2, 1, 1, 1),
(11, 'CD/DVD-ROM Drive', 'cdrom', 6, 1, 1, 1),
(12, 'Network: PXE Boot', 'network', 1, 1, 1, 1),
(14, 'Windows Boot Manager', 'windows', 5, 1, 1, 2),
(15, 'SATA SSD: Samsung 970 EVO', 'ssd', 1, 1, 1, 2),
(16, 'SATA HDD: WD Blue 1TB', 'hdd', 3, 1, 1, 2),
(17, 'USB Drive', 'usb', 4, 1, 1, 2),
(18, 'CD/DVD-ROM Drive', 'cdrom', 6, 1, 1, 2),
(19, 'Network: PXE Boot', 'network', 2, 1, 1, 2),
(21, 'Windows Boot Manager', 'windows', 5, 1, 1, 3),
(22, 'SATA SSD: Samsung 970 EVO', 'ssd', 4, 1, 1, 3),
(23, 'SATA HDD: WD Blue 1TB', 'hdd', 3, 1, 1, 3),
(24, 'USB Drive', 'usb', 2, 1, 1, 3),
(25, 'CD/DVD-ROM Drive', 'cdrom', 6, 1, 1, 3),
(26, 'Network: PXE Boot', 'network', 1, 1, 1, 3),
(28, 'Windows Boot Manager', 'windows', 6, 1, 1, 4),
(29, 'SATA SSD: Samsung 970 EVO', 'ssd', 3, 1, 1, 4),
(30, 'SATA HDD: WD Blue 1TB', 'hdd', 2, 1, 1, 4),
(31, 'USB Drive', 'usb', 1, 1, 1, 4),
(32, 'CD/DVD-ROM Drive', 'cdrom', 5, 1, 1, 4),
(33, 'Network: PXE Boot', 'network', 4, 1, 1, 4);

-- --------------------------------------------------------

--
-- Структура таблицы `cpu_info`
--

CREATE TABLE `cpu_info` (
  `id` int(11) NOT NULL,
  `cpu_name` varchar(100) DEFAULT NULL,
  `speed` varchar(50) DEFAULT NULL,
  `cores` varchar(50) DEFAULT NULL,
  `cache` varchar(50) DEFAULT NULL,
  `bios_id` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `cpu_info`
--

INSERT INTO `cpu_info` (`id`, `cpu_name`, `speed`, `cores`, `cache`, `bios_id`) VALUES
(1, 'Intel Core i9-14900K', '3.2 GHz (5.8 GHz Turbo)', '24 (8P + 16E)', '36 MB', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `memory_info`
--

CREATE TABLE `memory_info` (
  `id` int(11) NOT NULL,
  `total_memory` varchar(20) DEFAULT NULL,
  `frequency` varchar(20) DEFAULT NULL,
  `dimm1` varchar(100) DEFAULT NULL,
  `dimm2` varchar(100) DEFAULT NULL,
  `dimm3` varchar(100) DEFAULT NULL,
  `dimm4` varchar(100) DEFAULT NULL,
  `bios_id` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `memory_info`
--

INSERT INTO `memory_info` (`id`, `total_memory`, `frequency`, `dimm1`, `dimm2`, `dimm3`, `dimm4`, `bios_id`) VALUES
(1, '32 GB', 'DDR5-7200', '16 GB Kingston Fury', '16 GB Kingston Fury', 'Empty', 'Empty', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `passwords`
--

CREATE TABLE `passwords` (
  `id` int(11) NOT NULL,
  `password_type` varchar(20) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `bios_id` int(11) NOT NULL DEFAULT 1,
  `user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password_hash` varchar(255) DEFAULT NULL,
  `role` varchar(20) DEFAULT 'user'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `username`, `password_hash`, `role`) VALUES
(1, 'teacher1', '$2y$10$D4W9Z6zjiXyojyR1z/29I..qhVeWYBsvP1XWo8GMI44z0b9oTiFYe', 'user'),
(2, 'teacher2', '$2y$10$G4POna70pc.CMg05Z/rF7.pjrEeLDp7zzgc3phmj5RTRhkqQn0/vu', 'user'),
(3, 'teacher3', '$2y$10$z3Z6d0eQPqmVCQBxn//lQuzd.24Y10Cv0gbXJRbty8VZFnOt16pjy', 'user'),
(4, 'User', '$2y$10$cKndrYO1AB.plnEhLrb2C.L6UkgNJNf347EDo4pzUc72KTh5mW/4G', 'user');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `bios_info`
--
ALTER TABLE `bios_info`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `bios_logs`
--
ALTER TABLE `bios_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_bios_logs_users` (`user_id`);

--
-- Индексы таблицы `bios_settings`
--
ALTER TABLE `bios_settings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_bios_settings_bios_info` (`bios_id`),
  ADD KEY `idx_user_id` (`user_id`);

--
-- Индексы таблицы `boot_order`
--
ALTER TABLE `boot_order`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_boot_order_bios_info` (`bios_id`),
  ADD KEY `idx_user_id` (`user_id`);

--
-- Индексы таблицы `cpu_info`
--
ALTER TABLE `cpu_info`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_cpu_info_bios_info` (`bios_id`);

--
-- Индексы таблицы `memory_info`
--
ALTER TABLE `memory_info`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_memory_info_bios_info` (`bios_id`);

--
-- Индексы таблицы `passwords`
--
ALTER TABLE `passwords`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_passwords_bios_info` (`bios_id`),
  ADD KEY `idx_user_id` (`user_id`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `bios_info`
--
ALTER TABLE `bios_info`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT для таблицы `bios_logs`
--
ALTER TABLE `bios_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=285;

--
-- AUTO_INCREMENT для таблицы `bios_settings`
--
ALTER TABLE `bios_settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=210;

--
-- AUTO_INCREMENT для таблицы `boot_order`
--
ALTER TABLE `boot_order`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT для таблицы `cpu_info`
--
ALTER TABLE `cpu_info`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT для таблицы `memory_info`
--
ALTER TABLE `memory_info`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT для таблицы `passwords`
--
ALTER TABLE `passwords`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `bios_logs`
--
ALTER TABLE `bios_logs`
  ADD CONSTRAINT `fk_bios_logs_users` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Ограничения внешнего ключа таблицы `bios_settings`
--
ALTER TABLE `bios_settings`
  ADD CONSTRAINT `fk_bios_settings_bios_info` FOREIGN KEY (`bios_id`) REFERENCES `bios_info` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_bios_settings_users` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Ограничения внешнего ключа таблицы `boot_order`
--
ALTER TABLE `boot_order`
  ADD CONSTRAINT `fk_boot_order_bios_info` FOREIGN KEY (`bios_id`) REFERENCES `bios_info` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_boot_order_users` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Ограничения внешнего ключа таблицы `cpu_info`
--
ALTER TABLE `cpu_info`
  ADD CONSTRAINT `fk_cpu_info_bios_info` FOREIGN KEY (`bios_id`) REFERENCES `bios_info` (`id`) ON DELETE CASCADE;

--
-- Ограничения внешнего ключа таблицы `memory_info`
--
ALTER TABLE `memory_info`
  ADD CONSTRAINT `fk_memory_info_bios_info` FOREIGN KEY (`bios_id`) REFERENCES `bios_info` (`id`) ON DELETE CASCADE;

--
-- Ограничения внешнего ключа таблицы `passwords`
--
ALTER TABLE `passwords`
  ADD CONSTRAINT `fk_passwords_bios_info` FOREIGN KEY (`bios_id`) REFERENCES `bios_info` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_passwords_users` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
