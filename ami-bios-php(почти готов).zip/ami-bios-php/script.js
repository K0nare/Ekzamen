/**
 * AMI BIOS JavaScript
 */

// Глобальные переменные
let currentTab = 'main';
let currentSubmenu = 'cpu-config';

let reminderTimer = null;
let unlockTimerInterval = null;
// 45 минут работы до напоминания, 5 минут отдыха
const REMINDER_DELAY_MS = 45 * 60 * 1000;   // 45 минут (для теста можно поставить 3*60*1000)
const BREAK_MINUTES = 5;                    // 5 минут блокировки

// Инициализация при загрузке
document.addEventListener('DOMContentLoaded', function() {
    initTabs();
    initTreeMenu();
    initBootOrder();
    initKeyboardNavigation();
    initDateTime();
    updateLiveTime();
    loadSavedSettings();
    initPasswordForm();
    // initModalClose();   // <-- ЭТОЙ ФУНКЦИИ НЕТ, УДАЛЯЕМ
    startReminderTimer();               // Запускаем таймер напоминания
    console.log('Таймер запущен, сработает через', REMINDER_DELAY_MS / 1000, 'секунд');
});

// ========== ИНИЦИАЛИЗАЦИЯ ЭЛЕМЕНТОВ ==========

function initTabs() {
    const tabs = document.querySelectorAll('.nav-tabs li');
    const tabContents = document.querySelectorAll('.bios-tab');
    
    tabs.forEach(tab => {
        tab.addEventListener('click', function(e) {
            const tabId = this.dataset.tab;
            tabs.forEach(t => t.classList.remove('active'));
            tabContents.forEach(c => c.classList.remove('active'));
            this.classList.add('active');
            document.getElementById(`tab-${tabId}`).classList.add('active');
            currentTab = tabId;
            localStorage.setItem('biosLastTab', tabId);
        });
    });
    
    const lastTab = localStorage.getItem('biosLastTab');
    if (lastTab) {
        const tab = document.querySelector(`[data-tab="${lastTab}"]`);
        if (tab) tab.click();
    }
}

function initTreeMenu() {
    const treeItems = document.querySelectorAll('.tree-item');
    const submenus = document.querySelectorAll('.submenu-panel');
    
    treeItems.forEach(item => {
        item.addEventListener('click', function() {
            const submenuId = this.dataset.submenu;
            treeItems.forEach(i => i.classList.remove('active'));
            submenus.forEach(s => s.classList.remove('active'));
            this.classList.add('active');
            document.getElementById(submenuId).classList.add('active');
            currentSubmenu = submenuId;
        });
    });
}

function initBootOrder() {
    const bootList = document.getElementById('bootList');
    if (!bootList) return;
    
    let draggedItem = null;
    
    document.querySelectorAll('.boot-item').forEach(item => {
        item.setAttribute('draggable', 'true');
        
        item.addEventListener('dragstart', function(e) {
            draggedItem = this;
            this.classList.add('dragging');
            e.dataTransfer.effectAllowed = 'move';
        });
        
        item.addEventListener('dragend', function() {
            this.classList.remove('dragging');
            draggedItem = null;
        });
        
        item.addEventListener('dragover', function(e) {
            e.preventDefault();
            e.dataTransfer.dropEffect = 'move';
        });
        
        item.addEventListener('drop', function(e) {
            e.preventDefault();
            if (draggedItem && draggedItem !== this) {
                const items = [...bootList.children];
                const draggedIndex = items.indexOf(draggedItem);
                const targetIndex = items.indexOf(this);
                if (draggedIndex < targetIndex) {
                    this.parentNode.insertBefore(draggedItem, this.nextSibling);
                } else {
                    this.parentNode.insertBefore(draggedItem, this);
                }
                updateBootOrderHiddenFields();
            }
        });
    });
}

function updateBootOrderHiddenFields() {
    const bootItems = document.querySelectorAll('.boot-item');
    bootItems.forEach((item, index) => {
        const hiddenInput = item.querySelector('input[type="hidden"]');
        if (hiddenInput) {
            hiddenInput.value = item.dataset.device;
        }
    });
}

function initDateTime() {
    const dateInput = document.querySelector('input[name="system_date"]');
    const timeInput = document.querySelector('input[name="system_time"]');
    if (dateInput && !dateInput.value) {
        dateInput.value = new Date().toISOString().split('T')[0];
    }
    if (timeInput && !timeInput.value) {
        timeInput.value = new Date().toTimeString().split(' ')[0];
    }
}

function updateLiveTime() {
    const timeElement = document.getElementById('liveTime');
    if (timeElement) {
        setInterval(() => {
            timeElement.textContent = new Date().toLocaleTimeString();
        }, 1000);
    }
}

function initKeyboardNavigation() {
    document.addEventListener('keydown', function(e) {
        const overlay = document.getElementById('breakOverlay');
        if (overlay && overlay.style.display === 'flex') return;
        if (e.target.tagName === 'INPUT' || e.target.tagName === 'SELECT') return;
        
        switch(e.key) {
            case 'ArrowLeft': e.preventDefault(); navigateTabs(-1); break;
            case 'ArrowRight': e.preventDefault(); navigateTabs(1); break;
            case 'ArrowUp': e.preventDefault(); navigateTree(-1); break;
            case 'ArrowDown': e.preventDefault(); navigateTree(1); break;
            case 'Enter': e.preventDefault(); activateCurrentItem(); break;
            case 'F1': e.preventDefault(); showHelp(); break;
            case 'F9': e.preventDefault(); loadOptimizedDefaults(); break;
            case 'F10': e.preventDefault(); saveAndExit(); break;
            case 'Escape':
                e.preventDefault();
                const override = document.getElementById('bootOverride');
                if (override && override.style.display === 'block') {
                    override.style.display = 'none';
                } else {
                    discardAndExit();
                }
                break;
            case 'F8': e.preventDefault(); bootOverride(); break;
        }
    });
}

function navigateTabs(direction) {
    const tabs = document.querySelectorAll('.nav-tabs li');
    const activeTab = document.querySelector('.nav-tabs li.active');
    let index = Array.from(tabs).indexOf(activeTab);
    index = (index + direction + tabs.length) % tabs.length;
    tabs[index].click();
}

function navigateTree(direction) {
    const treeItems = document.querySelectorAll('.tree-item');
    if (treeItems.length === 0) return;
    const activeItem = document.querySelector('.tree-item.active');
    let index = activeItem ? Array.from(treeItems).indexOf(activeItem) : 0;
    index = (index + direction + treeItems.length) % treeItems.length;
    treeItems[index].click();
}

function activateCurrentItem() {
    // Заглушка
}

function checkAuthBeforeSave(event) {
    if (document.querySelector('.user-name')) return true;
    alert('Для сохранения настроек необходимо войти в систему.');
    showAuthModal();
    event.preventDefault();
    return false;
}

document.querySelectorAll('.bios-form').forEach(form => {
    form.addEventListener('submit', checkAuthBeforeSave);
});

// ========== ФУНКЦИИ ДЛЯ ВКЛАДКИ SAVE & EXIT ==========

function saveAllForms() {
    const forms = document.querySelectorAll('.bios-form');
    let allData = new FormData();
    allData.append('action', 'save_all');
    
    forms.forEach(form => {
        const formData = new FormData(form);
        for (let [key, value] of formData.entries()) {
            if (key !== 'action') {
                allData.append(key, value);
            }
        }
    });
    
    return fetch(window.location.href, {
        method: 'POST',
        body: allData,
        headers: { 'X-Requested-With': 'XMLHttpRequest' }
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showMessage(data.message, 'success');
        } else {
            showMessage(data.message, 'error');
            throw new Error(data.message);
        }
    })
    .catch(error => {
        console.error('Save error:', error);
        showMessage('Network error!', 'error');
        throw error;
    });
}

function saveAndExit() {
    if (confirm('Сохранить изменения и перезагрузить систему?')) {
        saveAllForms()
            .then(() => {
                showRebootAnimation();
                setTimeout(() => { window.location.reload(); }, 2000);
            })
            .catch(() => {});
    }
}

function discardAndExit() {
    if (confirm('Отменить изменения и выйти без сохранения?')) {
        window.location.reload();
    }
}

function loadOptimizedDefaults() {
    if (confirm('Загрузить оптимизированные настройки по умолчанию?')) {
        const form = document.createElement('form');
        form.method = 'POST';
        form.innerHTML = '<input type="hidden" name="action" value="load_defaults">';
        document.body.appendChild(form);
        form.submit();
    }
}

function saveUserDefaults() {
    const settings = collectAllSettings();
    localStorage.setItem('biosUserDefaults', JSON.stringify(settings));
    showMessage('User defaults saved');
}

function loadUserDefaults() {
    const defaults = localStorage.getItem('biosUserDefaults');
    if (defaults) {
        if (confirm('Загрузить пользовательские настройки?')) {
            const settings = JSON.parse(defaults);
            applySettings(settings);
            showMessage('Пользовательские настройки загружены');
        }
    } else {
        showMessage('No user defaults found', 'error');
    }
}

function bootOverride() {
    const panel = document.getElementById('bootOverride');
    if (panel) {
        panel.style.display = panel.style.display === 'none' ? 'block' : 'none';
    }
}

function bootFrom(device) {
    if (confirm(`Загрузиться с устройства ${device}?`)) {
        showRebootAnimation();
    }
}

function collectAllSettings() {
    const settings = {};
    document.querySelectorAll('input, select').forEach(input => {
        if (input.type === 'checkbox') {
            settings[input.name] = input.checked;
        } else if (input.type === 'hidden' && input.name === 'boot_order[]') {
            if (!settings.boot_order) settings.boot_order = [];
            settings.boot_order.push(input.value);
        } else {
            settings[input.name] = input.value;
        }
    });
    return settings;
}

function applySettings(settings) {
    for (let [key, value] of Object.entries(settings)) {
        const inputs = document.querySelectorAll(`[name="${key}"], [name="${key}[]"]`);
        inputs.forEach(input => {
            if (input.type === 'checkbox') {
                input.checked = value === true || value === 'true' || value === 1;
            } else {
                input.value = value;
            }
        });
    }
}

function showMessage(text, type = 'success') {
    const messageDiv = document.createElement('div');
    messageDiv.className = `bios-message ${type}`;
    messageDiv.innerHTML = `${text}<span class="close-btn" onclick="this.parentElement.remove()">&times;</span>`;
    const content = document.querySelector('.bios-content');
    if (content) content.insertBefore(messageDiv, content.firstChild);
    setTimeout(() => { if (messageDiv.parentElement) messageDiv.remove(); }, 5000);
}

function showRebootAnimation() {
    const overlay = document.createElement('div');
    overlay.className = 'reboot-overlay';
    overlay.innerHTML = `
        <div class="reboot-content">
            <div class="reboot-logo">AMI</div>
            <div class="reboot-text">System is restarting...</div>
            <div class="reboot-progress"></div>
            <div class="reboot-hint">Press DEL to enter BIOS Setup</div>
        </div>
    `;
    document.body.appendChild(overlay);
    
    const style = document.createElement('style');
    style.textContent = `
        .reboot-overlay {
            position: fixed; top: 0; left: 0; width: 100%; height: 100%;
            background: #000; color: #0f0; display: flex; justify-content: center;
            align-items: center; z-index: 10000; font-family: 'Courier New', monospace;
            animation: fadeOut 3s forwards;
        }
        .reboot-content { text-align: center; }
        .reboot-logo { font-size: 48px; font-weight: bold; color: #ff6b2b; margin-bottom: 20px; }
        .reboot-text { font-size: 24px; margin-bottom: 20px; }
        .reboot-progress { width: 300px; height: 2px; background: #333; margin: 20px auto; position: relative; overflow: hidden; }
        .reboot-progress::after { content: ''; position: absolute; top: 0; left: -100%; width: 100%; height: 100%; background: #0f0; animation: progress 2s linear; }
        .reboot-hint { font-size: 14px; color: #666; }
        @keyframes progress { to { left: 0; } }
        @keyframes fadeOut { 0% { opacity: 1; } 70% { opacity: 1; } 100% { opacity: 0; visibility: hidden; } }
    `;
    document.head.appendChild(style);
    setTimeout(() => { window.location.reload(); }, 3000);
}

// ========== ТАЙМЕР НАПОМИНАНИЯ И БЛОКИРОВКИ ==========

function startReminderTimer() {
    if (reminderTimer) clearTimeout(reminderTimer);
    reminderTimer = setTimeout(showBreakReminder, REMINDER_DELAY_MS);
    console.log('Таймер напоминания запущен');
}

function showBreakReminder() {
    console.log('Показываем напоминание о перерыве');
    const overlay = document.getElementById('breakOverlay');
    if (!overlay) return;
    
    overlay.style.display = 'flex';
    const unlockBtn = document.getElementById('unlockButton');
    if (unlockBtn) {
        unlockBtn.disabled = false;
        unlockBtn.classList.remove('disabled');
        unlockBtn.textContent = 'Продолжить работу';
        unlockBtn.removeEventListener('click', unlockInterface);
        unlockBtn.addEventListener('click', unlockInterface);
    }
}

function unlockInterface() {
    alert('⚠️ Страница с игрой временно недоступна. Ведутся работы для решения этой проблемы.\n\nНачнём 5-минутный перерыв для отдыха.');
    startBreakTimer();
}

function startBreakTimer() {
    const overlay = document.getElementById('breakOverlay');
    const btn = document.getElementById('unlockButton');
    if (!overlay || !btn) return;
    
    if (unlockTimerInterval) clearInterval(unlockTimerInterval);
    
    btn.disabled = true;
    btn.classList.add('disabled');
    let secondsLeft = BREAK_MINUTES * 60;
    
    function updateButtonText() {
        const mins = Math.floor(secondsLeft / 60);
        const secs = secondsLeft % 60;
        btn.textContent = `Отдых ${mins}:${secs < 10 ? '0' : ''}${secs}`;
        if (secondsLeft <= 0) {
            clearInterval(unlockTimerInterval);
            finishBreak();
        }
        secondsLeft--;
    }
    
    updateButtonText();
    unlockTimerInterval = setInterval(updateButtonText, 1000);
}

function finishBreak() {
    const overlay = document.getElementById('breakOverlay');
    if (overlay) overlay.style.display = 'none';
    
    if (unlockTimerInterval) {
        clearInterval(unlockTimerInterval);
        unlockTimerInterval = null;
    }
    
    const btn = document.getElementById('unlockButton');
    if (btn) {
        btn.disabled = false;
        btn.classList.remove('disabled');
        btn.textContent = 'Продолжить работу';
    }
    
    startReminderTimer();
}

// ========== ПАРОЛИ ==========

function showPasswordModal(type) {
    const modal = document.getElementById('passwordModal');
    const title = document.getElementById('passwordModalTitle');
    const passwordType = document.getElementById('passwordType');
    if (!modal || !title || !passwordType) return;
    title.textContent = type === 'admin' ? 'Set Administrator Password' : 'Set User Password';
    passwordType.value = type;
    modal.style.display = 'flex';
    document.getElementById('newPassword').value = '';
    document.getElementById('confirmPassword').value = '';
}

function closePasswordModal() {
    const modal = document.getElementById('passwordModal');
    if (modal) modal.style.display = 'none';
}

function initPasswordForm() {
    const form = document.getElementById('passwordForm');
    if (form) {
        form.addEventListener('submit', function(e) {
            const pass1 = document.getElementById('newPassword').value;
            const pass2 = document.getElementById('confirmPassword').value;
            if (pass1 !== pass2) {
                e.preventDefault();
                alert('Пароли не совпадают!');
            }
        });
    }
}

function saveSecuritySettings() {
    showMessage('Security settings saved');
}

function loadSavedSettings() {
    // Можно загрузить сохранённые настройки из localStorage
}

function showHelp() {
    alert(
        'Справка AMI BIOS\n\n' +
        'Навигация:\n' +
        '↑↓ - Перемещение по пунктам\n' +
        '←→ - Переключение вкладок\n' +
        'Enter - Выбрать пункт\n' +
        'F1 - Эта справка\n' +
        'F9 - Загрузить настройки по умолчанию\n' +
        'F10 - Сохранить и выйти\n' +
        'ESC - Выйти без сохранения'
    );
}

// ========== ИНФОРМАЦИОННЫЕ МОДАЛЬНЫЕ ОКНА (РУССКИЙ ЯЗЫК) ==========

function closeInfoModal() {
    const modal = document.getElementById('infoModal');
    if (modal) modal.style.display = 'none';
}

function showInfo(title, contentHtml) {
    const modal = document.getElementById('infoModal');
    const titleEl = document.getElementById('infoModalTitle');
    const bodyEl = document.getElementById('infoModalBody');
    if (!modal || !titleEl || !bodyEl) return;
    titleEl.textContent = title;
    bodyEl.innerHTML = contentHtml;
    modal.style.display = 'flex';
}

function showInfoModal(type) {
    let title = '';
    let content = '';

    switch (type) {
        case 'system':
            title = 'Информация о системе';
            content = `
                <div class="info-icon">🖥️</div>
                <p><strong>AMI BIOS UEFI Setup Utility</strong></p>
                <p>Версия: ${biosConfig.version}<br>
                Дата сборки: ${biosConfig.buildDate}<br>
                Производитель: ${biosConfig.vendor}</p>
                <p>Этот экран отображает основную информацию о системе и позволяет установить дату и время.</p>
                <div class="info-note">Используйте ← → для переключения вкладок, ↑ ↓ для выбора пунктов.</div>
            `;
            break;
        case 'processor':
            title = 'Информация о процессоре';
            content = `
                <div class="info-icon">⚙️</div>
                <p><strong>Тип CPU:</strong> Intel Core i9-14900K</p>
                <p>Процессор поддерживает Intel® Turbo Boost, Hyper-Threading и многоядерность для высокой производительности.</p>
                <p>Изменение параметров (активные ядра, турбо-режим) может повлиять на стабильность и энергопотребление.</p>
            `;
            break;
        case 'memory':
            title = 'Информация о памяти';
            content = `
                <div class="info-icon">🧠</div>
                <p><strong>Конфигурация памяти</strong></p>
                <p>Установлено: 32 ГБ DDR5-7200</p>
                <p>Модули DDR5 поддерживают профили XMP для более высокой частоты. Включение «Быстрой загрузки памяти» сокращает время тренировки при каждом запуске.</p>
                <div class="info-note">При замене модулей памяти рекомендуется выполнить полное обучение.</div>
            `;
            break;
        case 'datetime':
            title = 'Системная дата и время';
            content = `
                <div class="info-icon">📅</div>
                <p>Установите системную дату и время. Эти значения хранятся в CMOS и используются операционной системой.</p>
                <p><strong>Формат даты:</strong> ГГГГ-ММ-ДД<br>
                <strong>Формат времени:</strong> ЧЧ:ММ:СС (24 часа)</p>
                <div class="info-note">Неправильное время может вызывать проблемы с запланированными задачами и SSL-сертификатами.</div>
            `;
            break;
        case 'cpu_config':
            title = 'Конфигурация процессора';
            content = `<p>Настройки виртуализации Intel (VT-x), Hyper-Threading, активных ядер, SpeedStep, турбо-режима и C-States.<br>Изменения влияют на производительность и энергопотребление.</p>`;
            break;
        case 'sata_config':
            title = 'Конфигурация SATA';
            content = `<p>Управление контроллером SATA, режимом (AHCI/RAID/IDE) и поддержкой Hot Plug.<br>AHCI рекомендуется для современных SSD.</p>`;
            break;
        case 'usb_config':
            title = 'Конфигурация USB';
            content = `<p>Поддержка Legacy USB, XHCI Hand-off и драйвер USB Mass Storage.<br>Включите Legacy USB для старых операционных систем.</p>`;
            break;
        case 'pcie_config':
            title = 'Конфигурация PCIe/PCI';
            content = `<p>Корневой порт PCIe, скорость линии, декодирование Above 4G и Resizable BAR.<br>Above 4G и Resizable BAR необходимы для современных видеокарт.</p>`;
            break;
        case 'acpi_config':
            title = 'Конфигурация ACPI';
            content = `<p>Автоконфигурация ACPI и состояние сна (S1/S3).<br>S3 (Suspend to RAM) — наиболее распространённый режим сна.</p>`;
            break;
        case 'tpm_config':
            title = 'Доверенные вычисления (TPM)';
            content = `<p>Поддержка TPM и состояние TPM.<br>TPM 2.0 требуется для Windows 11.</p>`;
            break;
        case 'network_config':
            title = 'Сетевой стек';
            content = `<p>Сетевой стек, поддержка IPv4/IPv6 PXE.<br>Включите для загрузки по сети (PXE).</p>`;
            break;
        default:
            title = 'Информация';
            content = '<p>Нет дополнительной информации для этого раздела.</p>';
    }
    showInfo(title, content);
}

function showBootInfo(type) {
    let title = 'Настройки загрузки';
    let content = '';

    if (type === 'bootPriority') {
        content = `
            <div class="info-icon">🔢</div>
            <p><strong>Приоритет загрузки</strong> – определяет порядок опроса устройств на наличие загрузочного носителя.</p>
            <p>Перетаскивайте устройства, чтобы изменить порядок. Устройство с наивысшим приоритетом (сверху) проверяется первым.</p>
            <ul><li>Диспетчер загрузки Windows – для UEFI-установок Windows</li>
            <li>SATA SSD – быстрый внутренний твердотельный накопитель</li>
            <li>SATA HDD – традиционный жёсткий диск</li>
            <li>USB Drive – съёмные флеш-накопители</li>
            <li>CD/DVD-ROM – оптический диск</li>
            <li>Сеть (PXE) – загрузка по сети</li></ul>
        `;
    } else if (type === 'bootOptions') {
        content = `
            <div class="info-icon">⚡</div>
            <p><strong>Быстрая загрузка</strong> – сокращает время загрузки, пропуская некоторые этапы инициализации.<br>
            <strong>Логотип загрузки</strong> – показывает или скрывает полноэкранное лого во время POST.<br>
            <strong>Тихая загрузка</strong> – подавляет большинство POST-сообщений.<br>
            <strong>Поддержка CSM</strong> – обеспечивает совместимость с устаревшими (не UEFI) операционными системами.<br>
            <strong>Безопасная загрузка (Secure Boot)</strong> – предотвращает загрузку неподписанного ПО.</p>
            <div class="info-note">Для Windows 11 рекомендуется отключить CSM и включить Secure Boot.</div>
        `;
    } else {
        content = '<p>Настройки загрузки управляют запуском системы. Неправильные параметры могут сделать систему незагружаемой.</p>';
    }
    showInfo(title, content);
}

function showSecurityInfo(type) {
    let title = 'Настройки безопасности';
    let content = '';

    if (type === 'passwordManagement') {
        content = `
            <div class="info-icon">🔒</div>
            <p><strong>Пароль администратора</strong> – ограничивает доступ к утилите настройки BIOS.<br>
            <strong>Пароль пользователя</strong> – используется для входа в систему или BIOS (с ограниченными правами).</p>
            <p>Пароли хэшируются и хранятся безопасно. Минимальная длина — 4 символа.</p>
            <div class="info-note">Если вы забыли пароль администратора, возможно, потребуется сбросить CMOS с помощью джампера на материнской плате.</div>
        `;
    } else if (type === 'secureBoot') {
        content = `
            <div class="info-icon">🔐</div>
            <p><strong>Безопасная загрузка (Secure Boot)</strong> гарантирует, что во время загрузки выполняется только подписанный доверенный код.</p>
            <p>Варианты:<br>
            – Стандартный: используются заводские ключи.<br>
            – Пользовательский: позволяет управлять своими ключами.<br>
            – Отключён: выключает Secure Boot.</p>
            <div class="info-note">Для сертификации Windows 11 Secure Boot должна быть включена.</div>
        `;
    } else if (type === 'additionalSecurity') {
        content = `
            <div class="info-icon">🛡️</div>
            <p><strong>Устройство TPM</strong> – модуль доверенной платформы, используется для аппаратного шифрования (BitLocker, Windows Hello).<br>
            <strong>Intel SGX</strong> – расширения для изолированных окружений (анклавов) для чувствительного кода.</p>
            <div class="info-note">Для Windows 11 требуется TPM 2.0. Убедитесь, что он включён.</div>
        `;
    } else {
        content = '<p>Настройки безопасности защищают систему от несанкционированного доступа. Используйте надёжные пароли и держите TPM/Secure Boot включёнными.</p>';
    }
    showInfo(title, content);
}

function showChipsetInfo(type) {
    let title = 'Конфигурация чипсета';
    let content = '';

    if (type === 'systemAgent') {
        content = `
            <div class="info-icon">🔌</div>
            <p><strong>VT‑d</strong> – технология виртуализации Intel для направленного ввода-вывода, улучшает производительность I/O в виртуальных машинах.<br>
            <strong>Декодирование Above 4G</strong> – позволяет 64-битным PCIe-устройствам обращаться к памяти выше 4 ГБ (требуется для Resizable BAR).<br>
            <strong>Re‑Size BAR</strong> – позволяет процессору получать доступ ко всей видеопамяти сразу, повышая производительность в современных играх.</p>
        `;
    } else if (type === 'memory') {
        content = `
            <div class="info-icon">⚙️</div>
            <p><strong>Профиль памяти (XMP)</strong> – загружает оптимизированные тайминги и частоту для вашего комплекта DDR5.<br>
            <strong>Частота памяти</strong> – ручная установка частоты DRAM.<br>
            <strong>Быстрая загрузка памяти</strong> – пропускает полное обучение памяти при каждом запуске, используя сохранённые параметры.</p>
            <div class="info-note">Включение XMP может повысить производительность, но снизить стабильность, если процессор или материнская плата не поддерживают выбранный профиль.</div>
        `;
    } else if (type === 'graphics') {
        content = `
            <div class="info-icon">🎮</div>
            <p><strong>Основной графический адаптер</strong> – выбирает, какой GPU используется первым (PCIe, iGPU или авто).<br>
            <strong>Встроенная графика</strong> – включает или отключает интегрированный GPU.<br>
            <strong>Скорость PCIe</strong> – устанавливает скорость линии основного слота PCIe (Gen3/Gen4/Авто).</p>
        `;
    } else {
        content = '<p>Настройки чипсета управляют взаимодействием процессора, памяти и слотов расширения. Их изменение может повлиять на стабильность и производительность системы.</p>';
    }
    showInfo(title, content);
}

function showSaveExitInfo(type) {
    let title = 'Сохранить и выйти';
    let content = '';

    switch (type) {
        case 'saveAndExit':
            content = `
                <div class="info-icon">💾</div>
                <p><strong>Сохранить изменения и перезагрузить</strong> – сохраняет все текущие настройки в CMOS и перезагружает систему.</p>
                <p>Аналог нажатия <span class="key">F10</span>.</p>
            `;
            break;
        case 'discardAndExit':
            content = `
                <div class="info-icon">❌</div>
                <p><strong>Отменить изменения и выйти</strong> – выходит из BIOS без сохранения изменений, сделанных в этой сессии.</p>
                <p>Аналог нажатия <span class="key">ESC</span>.</p>
            `;
            break;
        case 'loadOptimizedDefaults':
            content = `
                <div class="info-icon">⚙️</div>
                <p><strong>Загрузить оптимизированные настройки по умолчанию</strong> – загружает заводские рекомендованные настройки, обеспечивающие максимальную стабильность и производительность для большинства конфигураций.</p>
                <p>Аналог нажатия <span class="key">F9</span>.</p>
                <div class="info-note">Используйте эту опцию, если система стала нестабильной после изменения расширенных настроек.</div>
            `;
            break;
        case 'saveUserDefaults':
            content = `<div class="info-icon">📋</div><p><strong>Сохранить пользовательские настройки</strong> – сохраняет текущие настройки BIOS как пользовательский профиль (в localStorage браузера). Вы можете восстановить их позже через «Загрузить пользовательские настройки».</p>`;
            break;
        case 'loadUserDefaults':
            content = `<div class="info-icon">↩️</div><p><strong>Загрузить пользовательские настройки</strong> – восстанавливает ранее сохранённые пользовательские настройки из хранилища браузера.</p>`;
            break;
        case 'bootOverride':
            content = `
                <div class="info-icon">🚀</div>
                <p><strong>Однократная загрузка с устройства</strong> – позволяет выбрать конкретное устройство для однократной загрузки, не изменяя постоянный порядок загрузки.</p>
                <p>Аналог нажатия <span class="key">F8</span> во время POST.</p>
            `;
            break;
        default:
            content = '<p>Используйте это меню, чтобы сохранить или отменить изменения, загрузить профили по умолчанию или выполнить однократную загрузку с определённого устройства.</p>';
    }
    showInfo(title, content);
}

function showBiosInfo() {
    const title = 'Полезное о BIOS';
    const content = `
        <div class="info-icon">📘</div>
        <h4>Что такое BIOS?</h4>
        <p><strong>BIOS (Basic Input/Output System)</strong> — это микропрограмма, хранящаяся на чипе материнской платы. Она запускается первой при включении компьютера, инициализирует оборудование (процессор, память, диски, порты) и передаёт управление загрузчику операционной системы.</p>
        
        <h4>Зачем нужен BIOS?</h4>
        <p>BIOS позволяет:</p>
        <ul>
            <li><strong>Настраивать оборудование</strong> — частоту процессора, тайминги памяти, порядок загрузки.</li>
            <li><strong>Диагностировать систему</strong> — мониторинг температуры, напряжения, вентиляторов.</li>
            <li><strong>Обеспечивать безопасность</strong> — установка паролей, управление TPM, Secure Boot.</li>
            <li><strong>Обновлять прошивку</strong> — добавлять поддержку новых процессоров, исправлять ошибки.</li>
        </ul>
        
        <h4>Основные разделы настроек</h4>
        <ul>
            <li><strong>Main</strong> — системная информация, дата и время.</li>
            <li><strong>Advanced</strong> — детальные параметры CPU, SATA, USB, PCIe, ACPI, TPM, сети.</li>
            <li><strong>Chipset</strong> — настройки чипсета: виртуализация (VT-d), распределение памяти, графика.</li>
            <li><strong>Boot</strong> — порядок загрузки устройств, быстрый старт, Secure Boot, CSM.</li>
            <li><strong>Security</strong> — пароли администратора и пользователя, управление ключами Secure Boot.</li>
            <li><strong>Save & Exit</strong> — сохранение/отмена изменений, загрузка оптимизированных или пользовательских настроек, однократная загрузка с устройства.</li>
        </ul>
        
        <h4>Как правильно настраивать?</h4>
        <ul>
            <li><strong>Не меняйте параметры, если не знаете их назначение</strong> — неправильная настройка может привести к нестабильности или невозможности загрузки.</li>
            <li><strong>Начните с «Load Optimized Defaults»</strong> (F9) — это базовые безопасные настройки, оптимальные для вашего железа.</li>
            <li><strong>Изменяйте по одному параметру</strong> и проверяйте стабильность системы.</li>
            <li><strong>Для разгона</strong> используйте XMP-профили памяти и тестируйте с помощью специальных утилит (Prime95, MemTest).</li>
            <li><strong>Для Windows 11</strong> обязательно включите TPM 2.0, Secure Boot, отключите CSM.</li>
            <li><strong>Сохраняйте резервную копию настроек</strong> (Save User Defaults), чтобы быстро восстановить их после сброса CMOS.</li>
        </ul>
        
        <div class="info-note">
            💡 <strong>Совет:</strong> Если система перестала загружаться после изменения настроек, сбросьте BIOS до заводских — отключите питание, выньте батарейку CR2032 на 2–3 минуты или используйте джампер Clear CMOS на материнской плате.
        </div>
    `;
    showInfo(title, content);
}

// Закрытие модального окна по клику вне его и по Escape
document.addEventListener('DOMContentLoaded', function() {
    const modal = document.getElementById('infoModal');
    if (modal) {
        window.addEventListener('click', function(e) {
            if (e.target === modal) closeInfoModal();
        });
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape' && modal.style.display === 'flex') closeInfoModal();
        });
    }
});

// ========== АУТЕНТИФИКАЦИЯ ==========
function showAuthModal() {
    document.getElementById('authModal').style.display = 'flex';
    showLoginForm();
}

function closeAuthModal() {
    document.getElementById('authModal').style.display = 'none';
}

function showLoginForm() {
    document.getElementById('loginForm').style.display = 'block';
    document.getElementById('registerForm').style.display = 'none';
}

function showRegisterForm() {
    document.getElementById('loginForm').style.display = 'none';
    document.getElementById('registerForm').style.display = 'block';
}

// Закрытие по клику вне окна
window.addEventListener('click', function(e) {
    const modal = document.getElementById('authModal');
    if (e.target === modal) closeAuthModal();
});