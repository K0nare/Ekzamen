<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
/**
 * AMI BIOS UEFI Setup Utility
 * Version: 5.19.01.0011
 */

// Запуск сессии
session_start();

require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/db_functions.php';

// Текущий пользователь (теперь connectDB() доступна)
$currentUser = null;
if (isset($_SESSION['user_id'])) {
    try {
        $pdo = connectDB();
        $stmt = $pdo->prepare("SELECT id, username, role FROM users WHERE id = ?");
        $stmt->execute([$_SESSION['user_id']]);
        $currentUser = $stmt->fetch();
    } catch (Exception $e) {
        // Если таблица users ещё не создана или ошибка
        $currentUser = null;
    }
}

// Если пользователь не авторизован, блокируем сохранение через JavaScript
$isGuest = ($currentUser === null);

// Переменные по умолчанию
$biosSettings = [];
$systemInfo = [];
$db_error = false;

// Проверяем подключение к БД
if (!testConnection()) {
    $db_error = true;
    error_log("Database connection failed, using file storage fallback");
    $biosSettings = loadBiosSettings();
    $systemInfo = getSystemInfo();
} else {
    $biosSettings = getCurrentUserSettings();
    $systemInfo = getFullSystemInfo();
    initializeDatabase();
}

// Обработка POST запросов
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
if ($action === 'save_all') {
    // Список всех полей-чекбоксов
    $checkboxFields = [
        'vt_x', 'hyper_threading', 'turbo_mode', 'c_state', 'sata_controller', 'hot_plug',
        'xhci_handoff', 'usb_mass_storage', 'above_4g', 'resize_bar', 'sr_iov', 'acpi_auto',
        'tpm_support', 'network_stack', 'ipv4_pxe', 'ipv6_pxe', 'pch_thermal', 'hpet', 'vt_d',
        'mem_fast_boot', 'fast_boot', 'boot_logo', 'quiet_boot'
    ];
    
    $allSettings = [];
    
    // Сначала обрабатываем дату и время из составных полей
    if (isset($_POST['system_date_day'], $_POST['system_date_month'], $_POST['system_date_year'])) {
        $day   = sprintf('%02d', (int)$_POST['system_date_day']);
        $month = sprintf('%02d', (int)$_POST['system_date_month']);
        $year  = $_POST['system_date_year'];
        $allSettings['system_date'] = "$year-$month-$day";
    }
    if (isset($_POST['system_time_hour'], $_POST['system_time_minute'], $_POST['system_time_second'])) {
        $hour   = sprintf('%02d', (int)$_POST['system_time_hour']);
        $minute = sprintf('%02d', (int)$_POST['system_time_minute']);
        $second = sprintf('%02d', (int)$_POST['system_time_second']);
        $allSettings['system_time'] = "$hour:$minute:$second";
    }
    
    // Преобразуем остальные поля
    foreach ($_POST as $key => $value) {
        if ($key === 'action' || $key === 'boot_order') continue;
        if (in_array($key, ['system_date_day','system_date_month','system_date_year','system_time_hour','system_time_minute','system_time_second'])) {
            continue; // уже обработаны
        }
        if ($value === 'on') {
            $allSettings[$key] = '1';
        } else {
            $allSettings[$key] = $value;
        }
    }
    
    // Чекбоксы, которые не пришли, выключаем
    foreach ($checkboxFields as $field) {
        if (!isset($allSettings[$field])) {
            $allSettings[$field] = '0';
        }
    }
    
    // Сохраняем порядок загрузки
    if (isset($_POST['boot_order']) && is_array($_POST['boot_order'])) {
        updateBootOrder($_POST['boot_order']);
    }
    
    $success = saveSettings($allSettings);
    
    header('Content-Type: application/json');
    if ($success) {
        echo json_encode(['success' => true, 'message' => 'Все настройки успешно сохранены!']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Ошибка сохранения настроек!']);
    }
    exit;
}

    // ---- НОВЫЕ ДЕЙСТВИЯ ДЛЯ ПОЛЬЗОВАТЕЛЕЙ ----
    if ($action === 'login') {
        $username = $_POST['username'] ?? '';
        $password = $_POST['password'] ?? '';
        $user = loginUser($username, $password);
        if ($user) {
            $_SESSION['message'] = "Добро пожаловать, {$user['username']}!";
            $_SESSION['message_type'] = 'success';
        } else {
            $_SESSION['message'] = "Неверное имя пользователя или пароль.";
            $_SESSION['message_type'] = 'error';
        }
        header('Location: ' . $_SERVER['PHP_SELF']);
        exit;
    }
    
    if ($action === 'register') {
        $username = $_POST['reg_username'] ?? '';
        $password = $_POST['reg_password'] ?? '';
        $confirm = $_POST['reg_confirm'] ?? '';
        if ($password !== $confirm) {
            $_SESSION['message'] = "Пароли не совпадают.";
            $_SESSION['message_type'] = 'error';
        } elseif (strlen($password) < 4) {
            $_SESSION['message'] = "Пароль должен быть не менее 4 символов.";
            $_SESSION['message_type'] = 'error';
        } else {
            $userId = registerUser($username, $password);
            if ($userId) {
                loginUser($username, $password); // автоматический вход
                $_SESSION['message'] = "Регистрация успешна! Добро пожаловать.";
                $_SESSION['message_type'] = 'success';
            } else {
                $_SESSION['message'] = "Пользователь с таким именем уже существует.";
                $_SESSION['message_type'] = 'error';
            }
        }
        header('Location: ' . $_SERVER['PHP_SELF']);
        exit;
    }
    
    if ($action === 'logout') {
        logoutUser();
        $_SESSION['message'] = "Вы вышли из системы.";
        $_SESSION['message_type'] = 'success';
        header('Location: ' . $_SERVER['PHP_SELF']);
        exit;
    }
    
    // ---- СУЩЕСТВУЮЩАЯ ОБРАБОТКА НАСТРОЕК ----
    if (!$db_error && testConnection()) {
        $response = handleBiosRequestDB($_POST);
    } else {
        $response = handleBiosRequest($_POST);
    }
    
    $_SESSION['message'] = $response['message'];
    $_SESSION['message_type'] = $response['success'] ? 'success' : 'error';
    header('Location: ' . $_SERVER['PHP_SELF']);
    exit;
}

$message = $_SESSION['message'] ?? '';
$messageType = $_SESSION['message_type'] ?? '';
unset($_SESSION['message'], $_SESSION['message_type']);

$currentTime = date('H:i:s');
$currentDate = date('Y-m-d');

// Функция обработки запросов с БД (добавлен case 'load_defaults')
function handleBiosRequestDB($postData) {
    $action = $postData['action'] ?? '';
    
    switch ($action) {
        case 'save_main':
case 'save_main':
    // Собираем дату из трёх полей
    $day   = isset($postData['system_date_day'])   ? sprintf('%02d', (int)$postData['system_date_day'])   : date('d');
    $month = isset($postData['system_date_month']) ? sprintf('%02d', (int)$postData['system_date_month']) : date('m');
    $year  = isset($postData['system_date_year'])  ? $postData['system_date_year']                      : date('Y');
    $system_date = "$year-$month-$day";
    
    // Собираем время из трёх полей
    $hour   = isset($postData['system_time_hour'])   ? sprintf('%02d', (int)$postData['system_time_hour'])   : date('H');
    $minute = isset($postData['system_time_minute']) ? sprintf('%02d', (int)$postData['system_time_minute']) : date('i');
    $second = isset($postData['system_time_second']) ? sprintf('%02d', (int)$postData['system_time_second']) : date('s');
    $system_time = "$hour:$minute:$second";
    
    $settings = [
        'system_date' => $system_date,
        'system_time' => $system_time
    ];
    if (saveSettings($settings)) {
        logAction("Main settings saved");
        return ['success' => true, 'message' => 'Основные настройки успешно сохранены!'];
    }
    break;
            
        case 'save_advanced':
            $settings = [
                'vt_x' => isset($postData['vt_x']) ? '1' : '0',
                'hyper_threading' => isset($postData['hyper_threading']) ? '1' : '0',
                'active_cores' => $postData['active_cores'] ?? 'all',
                'speedstep' => $postData['speedstep'] ?? 'auto',
                'turbo_mode' => isset($postData['turbo_mode']) ? '1' : '0',
                'c_state' => isset($postData['c_state']) ? '1' : '0',
                'sata_controller' => isset($postData['sata_controller']) ? '1' : '0',
                'sata_mode' => $postData['sata_mode'] ?? 'ahci',
                'hot_plug' => isset($postData['hot_plug']) ? '1' : '0',
                'legacy_usb' => $postData['legacy_usb'] ?? 'enabled',
                'xhci_handoff' => isset($postData['xhci_handoff']) ? '1' : '0',
                'usb_mass_storage' => isset($postData['usb_mass_storage']) ? '1' : '0',
                'pcie_root_port' => $postData['pcie_root_port'] ?? 'enabled',
                'pcie_link_speed' => $postData['pcie_link_speed'] ?? 'auto',
                'above_4g' => isset($postData['above_4g']) ? '1' : '0',
                'resize_bar' => isset($postData['resize_bar']) ? '1' : '0',
                'sr_iov' => isset($postData['sr_iov']) ? '1' : '0',
                'acpi_auto' => isset($postData['acpi_auto']) ? '1' : '0',
                'acpi_sleep_state' => $postData['acpi_sleep_state'] ?? 's3',
                'tpm_support' => isset($postData['tpm_support']) ? '1' : '0',
                'tpm_state' => $postData['tpm_state'] ?? 'enabled',
                'network_stack' => isset($postData['network_stack']) ? '1' : '0',
                'ipv4_pxe' => isset($postData['ipv4_pxe']) ? '1' : '0',
                'ipv6_pxe' => isset($postData['ipv6_pxe']) ? '1' : '0'
            ];
            if (saveSettings($settings)) {
                logAction("Advanced settings saved");
                return ['success' => true, 'message' => 'Расширенные настройки успешно сохранены!'];
            }
            break;
            
        case 'save_chipset':
            $settings = [
                'pch_thermal' => isset($postData['pch_thermal']) ? '1' : '0',
                'hpet' => isset($postData['hpet']) ? '1' : '0',
                'dmi_speed' => $postData['dmi_speed'] ?? 'auto',
                'vt_d' => isset($postData['vt_d']) ? '1' : '0',
                'above_4g' => isset($postData['above_4g']) ? '1' : '0',
                'resize_bar' => isset($postData['resize_bar']) ? '1' : '0',
                'memory_profile' => $postData['memory_profile'] ?? 'auto',
                'mem_freq' => $postData['mem_freq'] ?? 'auto',
                'mem_fast_boot' => isset($postData['mem_fast_boot']) ? '1' : '0',
                'primary_gpu' => $postData['primary_gpu'] ?? 'auto',
                'internal_gpu' => $postData['internal_gpu'] ?? 'auto',
                'pcie_speed' => $postData['pcie_speed'] ?? 'auto'
            ];
            if (saveSettings($settings)) {
                logAction("Chipset settings saved");
                return ['success' => true, 'message' => 'Настройки чипсета успешно сохранены!'];
            }
            break;
            
        case 'save_boot':
            if (isset($postData['boot_order']) && is_array($postData['boot_order'])) {
                updateBootOrder($postData['boot_order']);
            }
            $settings = [
                'fast_boot' => isset($postData['fast_boot']) ? '1' : '0',
                'boot_logo' => isset($postData['boot_logo']) ? '1' : '0',
                'quiet_boot' => isset($postData['quiet_boot']) ? '1' : '0',
                'csm_support' => $postData['csm_support'] ?? 'auto',
                'secure_boot' => $postData['secure_boot'] ?? 'standard'
            ];
            if (saveSettings($settings)) {
                logAction("Boot settings saved");
                return ['success' => true, 'message' => 'Настройки загрузки успешно сохранены!'];
            }
            break;
            
        case 'set_password':
            $passwordType = $postData['password_type'] ?? '';
            $newPassword = $postData['new_password'] ?? '';
            $confirmPassword = $postData['confirm_password'] ?? '';
            if ($newPassword !== $confirmPassword) {
                return ['success' => false, 'message' => 'Пароли не совпадают!'];
            }
            if (strlen($newPassword) > 0 && strlen($newPassword) < 4) {
                return ['success' => false, 'message' => 'Пароль должен содержать не менее 4 символов!'];
            }
            if (strlen($newPassword) > 0) {
                if (setPassword($passwordType, $newPassword)) {
                    $typeText = ($passwordType === 'admin') ? 'администратора' : 'пользователя';
                    return ['success' => true, 'message' => "Пароль $typeText успешно установлен!"];
                }
            } else {
                if (removePassword($passwordType)) {
                    $typeText = ($passwordType === 'admin') ? 'администратора' : 'пользователя';
                    return ['success' => true, 'message' => "Пароль $typeText удалён!"];
                }
            }
            break;
            
        // Добавлена обработка загрузки оптимизированных настроек (F9)
        case 'load_defaults':
            if (resetToDefaults()) {
                logAction("Optimized defaults loaded");
                return ['success' => true, 'message' => 'Оптимизированные настройки по умолчанию загружены!'];
            }
            break;
    }
    
    return ['success' => false, 'message' => 'Не удалось сохранить настройки!'];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AMI BIOS Setup Utility - Version <?php echo BIOS_VERSION; ?></title>
    <link rel="stylesheet" href="style.css?v=<?php echo time(); ?>">
</head>
<body>
<div class="bios-container">
    <!-- Header -->
    <div class="bios-header">
        <div class="header-left">
            <div class="ami-logo">
                <span class="ami-text">AMI</span>
                <span class="bios-badge">BIOS</span>
            </div>
            <div class="bios-version-info">
                <span>Version <?php echo BIOS_VERSION; ?></span>
                <span><?php echo BIOS_BUILD_DATE; ?></span>
            </div>
        </div>
            <div class="header-right">
    <div class="system-time" id="liveTime"><?php echo $currentTime; ?></div>
    <div class="system-date"><?php echo $currentDate; ?></div>
    <?php if ($currentUser): ?>
        <div class="user-info" style="display: inline-flex; align-items: center; gap: 10px; margin-left: 15px;">
            <span class="user-name" style="color: var(--bios-success);">👤 <?php echo htmlspecialchars($currentUser['username']); ?></span>
            <form method="post" style="display: inline;">
                <input type="hidden" name="action" value="logout">
                <button type="submit" class="bios-info-header" style="margin-left: 0;">Выйти</button>
            </form>
        </div>
    <?php else: ?>
        <button type="button" class="bios-info-header" onclick="showAuthModal()" style="margin-left: 15px;">🔐 Вход / Регистрация</button>
    <?php endif; ?>
    <button type="button" class="bios-info-header" onclick="showBiosInfo()" title="Полезное о BIOS">📖 BIOS Info</button>
</div>
</div>

    <!-- Navigation Tabs -->
    <div class="bios-nav">
        <ul class="nav-tabs">
            <li data-tab="main" class="active">Main</li>
            <li data-tab="advanced">Advanced</li>
            <li data-tab="chipset">Chipset</li>
            <li data-tab="boot">Boot</li>
            <li data-tab="security">Security</li>
            <li data-tab="save_exit">Save & Exit</li>
        </ul>
    </div>

    <!-- Content -->
    <div class="bios-content">
        <?php if ($message): ?>
            <div class="bios-message <?php echo $messageType; ?>">
                <?php echo htmlspecialchars($message); ?>
                <span class="close-btn" onclick="this.parentElement.remove()">&times;</span>
            </div>
        <?php endif; ?>

        <!-- Tab: Main -->
        <div id="tab-main" class="bios-tab active">
            <div class="tab-header">
                <h2>Main</h2>
                <p class="tab-description">System overview and basic settings</p>
            </div>
            <div class="settings-panel">
                <div class="settings-section" id="system-info-section">
                    <div class="section-header">
                        <h3>System Information</h3>
                        <button type="button" class="info-btn" onclick="showInfoModal('system')">ⓘ</button>
                    </div>
                    <table class="settings-table">
                        <tr><td>BIOS Vendor</td><td><?php echo BIOS_VENDOR; ?></td></tr>
                        <tr><td>Core Version</td><td><?php echo BIOS_CORE_VERSION; ?></td></tr>
                        <tr><td>Compliancy</td><td><?php echo BIOS_COMPLIANCY; ?></td></tr>
                        <tr><td>Project Version</td><td><?php echo BIOS_VERSION; ?></td></tr>
                        <tr><td>Build Date</td><td><?php echo BIOS_BUILD_DATE; ?></td></tr>
                    </table>
                </div>
                <div class="settings-section" id="processor-info-section">
                    <div class="section-header">
                        <h3>Processor Information</h3>
                        <button type="button" class="info-btn" onclick="showInfoModal('processor')">ⓘ</button>
                    </div>
                    <table class="settings-table">
                        <tr><td>CPU Type</td><td><?php echo $systemInfo['cpu']['name'] ?? 'Intel Core i9-14900K'; ?></td></tr>
                        <tr><td>CPU Speed</td><td><?php echo $systemInfo['cpu']['speed'] ?? '3.2 GHz'; ?></td></tr>
                        <tr><td>CPU Cores</td><td><?php echo $systemInfo['cpu']['cores'] ?? '24'; ?></td></tr>
                        <tr><td>Microcode</td><td><?php echo $systemInfo['cpu']['microcode'] ?? '0x11C'; ?></td></tr>
                        <tr><td>L3 Cache</td><td><?php echo $systemInfo['cpu']['cache'] ?? '36 MB'; ?></td></tr>
                    </table>
                </div>
                <div class="settings-section" id="memory-info-section">
                    <div class="section-header">
                        <h3>Memory Information</h3>
                        <button type="button" class="info-btn" onclick="showInfoModal('memory')">ⓘ</button>
                    </div>
                    <table class="settings-table">
                        <tr><td>Total Memory</td><td><?php echo $systemInfo['memory']['total'] ?? '32 GB'; ?></td></tr>
                        <tr><td>Memory Frequency</td><td><?php echo $systemInfo['memory']['frequency'] ?? 'DDR5-7200'; ?></td></tr>
                        <tr><td>DIMM_A1</td><td><?php echo $systemInfo['memory']['dimm1'] ?? '16 GB Kingston Fury'; ?></td></tr>
                        <tr><td>DIMM_A2</td><td><?php echo $systemInfo['memory']['dimm2'] ?? '16 GB Kingston Fury'; ?></td></tr>
                        <tr><td>DIMM_B1</td><td><?php echo $systemInfo['memory']['dimm3'] ?? 'Empty'; ?></td></tr>
                        <tr><td>DIMM_B2</td><td><?php echo $systemInfo['memory']['dimm4'] ?? 'Empty'; ?></td></tr>
                    </table>
                </div>
                <div class="settings-section" id="datetime-section">
                    <div class="section-header">
                        <h3>System Date & Time</h3>
                        <button type="button" class="info-btn" onclick="showInfoModal('datetime')">ⓘ</button>
                    </div>
<form method="post" class="bios-form">
    <input type="hidden" name="action" value="save_main">
    <table class="settings-table">
        <!-- System Date (день, месяц, год) -->
        <tr>
            <td>System Date</td>
            <td>
                <?php
                $currentDate = $biosSettings['system_date'] ?? date('Y-m-d');
                $dateParts = explode('-', $currentDate);
                $year  = $dateParts[0] ?? date('Y');
                $month = $dateParts[1] ?? date('m');
                $day   = $dateParts[2] ?? date('d');
                ?>
                <select name="system_date_day" class="bios-select" style="width:70px;">
                    <?php for ($d = 1; $d <= 31; $d++): ?>
                        <option value="<?php echo $d; ?>" <?php echo ($day == $d) ? 'selected' : ''; ?>><?php echo $d; ?></option>
                    <?php endfor; ?>
                </select>
                <select name="system_date_month" class="bios-select" style="width:80px;">
                    <?php for ($m = 1; $m <= 12; $m++): ?>
                        <option value="<?php echo $m; ?>" <?php echo ($month == $m) ? 'selected' : ''; ?>><?php echo $m; ?></option>
                    <?php endfor; ?>
                </select>
                <select name="system_date_year" class="bios-select" style="width:80px;">
                    <?php $currentYear = date('Y'); ?>
                    <?php for ($y = $currentYear - 10; $y <= $currentYear + 10; $y++): ?>
                        <option value="<?php echo $y; ?>" <?php echo ($year == $y) ? 'selected' : ''; ?>><?php echo $y; ?></option>
                    <?php endfor; ?>
                </select>
            </td>
        </tr>
        <!-- System Time (часы, минуты, секунды) -->
        <tr>
            <td>System Time</td>
            <td>
                <?php
                $currentTime = $biosSettings['system_time'] ?? date('H:i:s');
                $timeParts = explode(':', $currentTime);
                $hour   = $timeParts[0] ?? date('H');
                $minute = $timeParts[1] ?? date('i');
                $second = $timeParts[2] ?? date('s');
                ?>
                <select name="system_time_hour" class="bios-select" style="width:70px;">
                    <?php for ($h = 0; $h <= 23; $h++): ?>
                        <option value="<?php echo sprintf('%02d', $h); ?>" <?php echo ($hour == sprintf('%02d', $h)) ? 'selected' : ''; ?>><?php echo sprintf('%02d', $h); ?></option>
                    <?php endfor; ?>
                </select> :
                <select name="system_time_minute" class="bios-select" style="width:70px;">
                    <?php for ($m = 0; $m <= 59; $m++): ?>
                        <option value="<?php echo sprintf('%02d', $m); ?>" <?php echo ($minute == sprintf('%02d', $m)) ? 'selected' : ''; ?>><?php echo sprintf('%02d', $m); ?></option>
                    <?php endfor; ?>
                </select> :
                <select name="system_time_second" class="bios-select" style="width:70px;">
                    <?php for ($s = 0; $s <= 59; $s++): ?>
                        <option value="<?php echo sprintf('%02d', $s); ?>" <?php echo ($second == sprintf('%02d', $s)) ? 'selected' : ''; ?>><?php echo sprintf('%02d', $s); ?></option>
                    <?php endfor; ?>
                </select>
            </td>
        </tr>
    </table>
    <div class="form-actions">
        <button type="submit" class="bios-btn primary">Save</button>
    </div>
</form>
                </div>
            </div>
        </div>

        <!-- Tab: Advanced -->
        <div id="tab-advanced" class="bios-tab">
            <div class="tab-header">
                <h2>Advanced</h2>
                <p class="tab-description">Advanced system configuration</p>
            </div>
            <div class="advanced-tree">
                <div class="tree-menu">
                    <ul>
                        <li class="tree-item active" data-submenu="cpu-config"><span class="tree-icon">▶</span> CPU Configuration</li>
                        <li class="tree-item" data-submenu="sata-config"><span class="tree-icon">▶</span> SATA Configuration</li>
                        <li class="tree-item" data-submenu="usb-config"><span class="tree-icon">▶</span> USB Configuration</li>
                        <li class="tree-item" data-submenu="pcie-config"><span class="tree-icon">▶</span> PCIe/PCI Configuration</li>
                        <li class="tree-item" data-submenu="acpi-config"><span class="tree-icon">▶</span> ACPI Configuration</li>
                        <li class="tree-item" data-submenu="tpm-config"><span class="tree-icon">▶</span> Trusted Computing</li>
                        <li class="tree-item" data-submenu="network-config"><span class="tree-icon">▶</span> Network Stack</li>
                    </ul>
                </div>
                <div class="submenu-content">
                    <form method="post" class="bios-form">
                        <input type="hidden" name="action" value="save_advanced">
                        <!-- CPU Configuration -->
                        <div id="cpu-config" class="submenu-panel active">
                            <div class="section-header">
                                <h3>CPU Configuration</h3>
                                <button type="button" class="info-btn" onclick="showInfoModal('cpu_config')">ⓘ</button>
                            </div>
                            <table class="settings-table">
                                <tr><td>Intel Virtualization Technology (VT-x)</td><td><label class="toggle-switch"><input type="checkbox" name="vt_x" <?php echo ($biosSettings['vt_x'] ?? '1') == '1' ? 'checked' : ''; ?>><span class="toggle-slider"></span></label></td></tr>
                                <tr><td>Hyper-Threading Technology</td><td><label class="toggle-switch"><input type="checkbox" name="hyper_threading" <?php echo ($biosSettings['hyper_threading'] ?? '1') == '1' ? 'checked' : ''; ?>><span class="toggle-slider"></span></label></td></tr>
                                <tr><td>Active Processor Cores</td><td><select name="active_cores" class="bios-select"><option value="all" <?php echo ($biosSettings['active_cores'] ?? 'all') == 'all' ? 'selected' : ''; ?>>All</option><option value="1" <?php echo ($biosSettings['active_cores'] ?? '') == '1' ? 'selected' : ''; ?>>1</option><option value="2" <?php echo ($biosSettings['active_cores'] ?? '') == '2' ? 'selected' : ''; ?>>2</option><option value="4" <?php echo ($biosSettings['active_cores'] ?? '') == '4' ? 'selected' : ''; ?>>4</option></select></td></tr>
                                <tr><td>Intel SpeedStep</td><td><select name="speedstep" class="bios-select"><option value="auto" <?php echo ($biosSettings['speedstep'] ?? 'auto') == 'auto' ? 'selected' : ''; ?>>Auto</option><option value="enabled" <?php echo ($biosSettings['speedstep'] ?? '') == 'enabled' ? 'selected' : ''; ?>>Enabled</option><option value="disabled" <?php echo ($biosSettings['speedstep'] ?? '') == 'disabled' ? 'selected' : ''; ?>>Disabled</option></select></td></tr>
                                <tr><td>Turbo Mode</td><td><label class="toggle-switch"><input type="checkbox" name="turbo_mode" <?php echo ($biosSettings['turbo_mode'] ?? '1') == '1' ? 'checked' : ''; ?>><span class="toggle-slider"></span></label></td></tr>
                                <tr><td>C-States</td><td><label class="toggle-switch"><input type="checkbox" name="c_state" <?php echo ($biosSettings['c_state'] ?? '1') == '1' ? 'checked' : ''; ?>><span class="toggle-slider"></span></label></td></tr>
                            </table>
                        </div>
                        <!-- SATA Configuration -->
                        <div id="sata-config" class="submenu-panel">
                            <div class="section-header"><h3>SATA Configuration</h3><button type="button" class="info-btn" onclick="showInfoModal('sata_config')">ⓘ</button></div>
                            <table class="settings-table">
                                <tr><td>SATA Controller</td><td><label class="toggle-switch"><input type="checkbox" name="sata_controller" <?php echo ($biosSettings['sata_controller'] ?? '1') == '1' ? 'checked' : ''; ?>><span class="toggle-slider"></span></label></td></tr>
                                <tr><td>SATA Mode</td><td><select name="sata_mode" class="bios-select"><option value="ahci" <?php echo ($biosSettings['sata_mode'] ?? 'ahci') == 'ahci' ? 'selected' : ''; ?>>AHCI</option><option value="raid" <?php echo ($biosSettings['sata_mode'] ?? '') == 'raid' ? 'selected' : ''; ?>>RAID</option><option value="ide" <?php echo ($biosSettings['sata_mode'] ?? '') == 'ide' ? 'selected' : ''; ?>>IDE (Legacy)</option></select></td></tr>
                                <tr><td>Hot Plug</td><td><label class="toggle-switch"><input type="checkbox" name="hot_plug" <?php echo ($biosSettings['hot_plug'] ?? '0') == '1' ? 'checked' : ''; ?>><span class="toggle-slider"></span></label></td></tr>
                            </table>
                        </div>
                        <!-- USB Configuration -->
                        <div id="usb-config" class="submenu-panel">
                            <div class="section-header"><h3>USB Configuration</h3><button type="button" class="info-btn" onclick="showInfoModal('usb_config')">ⓘ</button></div>
                            <table class="settings-table">
                                <tr><td>Legacy USB Support</td><td><select name="legacy_usb" class="bios-select"><option value="enabled" <?php echo ($biosSettings['legacy_usb'] ?? 'enabled') == 'enabled' ? 'selected' : ''; ?>>Enabled</option><option value="disabled" <?php echo ($biosSettings['legacy_usb'] ?? '') == 'disabled' ? 'selected' : ''; ?>>Disabled</option><option value="auto" <?php echo ($biosSettings['legacy_usb'] ?? '') == 'auto' ? 'selected' : ''; ?>>Auto</option></select></td></tr>
                                <tr><td>XHCI Hand-off</td><td><label class="toggle-switch"><input type="checkbox" name="xhci_handoff" <?php echo ($biosSettings['xhci_handoff'] ?? '1') == '1' ? 'checked' : ''; ?>><span class="toggle-slider"></span></label></td></tr>
                                <tr><td>USB Mass Storage Driver</td><td><label class="toggle-switch"><input type="checkbox" name="usb_mass_storage" <?php echo ($biosSettings['usb_mass_storage'] ?? '1') == '1' ? 'checked' : ''; ?>><span class="toggle-slider"></span></label></td></tr>
                            </table>
                        </div>
                        <!-- PCIe Configuration -->
                        <div id="pcie-config" class="submenu-panel">
                            <div class="section-header"><h3>PCIe/PCI Configuration</h3><button type="button" class="info-btn" onclick="showInfoModal('pcie_config')">ⓘ</button></div>
                            <table class="settings-table">
                                <tr><td>PCIe Root Port</td><td><select name="pcie_root_port" class="bios-select"><option value="enabled" <?php echo ($biosSettings['pcie_root_port'] ?? 'enabled') == 'enabled' ? 'selected' : ''; ?>>Enabled</option><option value="disabled" <?php echo ($biosSettings['pcie_root_port'] ?? '') == 'disabled' ? 'selected' : ''; ?>>Disabled</option></select></td></tr>
                                <tr><td>PCIe Link Speed</td><td><select name="pcie_link_speed" class="bios-select"><option value="auto" <?php echo ($biosSettings['pcie_link_speed'] ?? 'auto') == 'auto' ? 'selected' : ''; ?>>Auto</option><option value="gen1" <?php echo ($biosSettings['pcie_link_speed'] ?? '') == 'gen1' ? 'selected' : ''; ?>>Gen1</option><option value="gen2" <?php echo ($biosSettings['pcie_link_speed'] ?? '') == 'gen2' ? 'selected' : ''; ?>>Gen2</option><option value="gen3" <?php echo ($biosSettings['pcie_link_speed'] ?? '') == 'gen3' ? 'selected' : ''; ?>>Gen3</option><option value="gen4" <?php echo ($biosSettings['pcie_link_speed'] ?? '') == 'gen4' ? 'selected' : ''; ?>>Gen4</option></select></td></tr>
                                <tr><td>Above 4G Decoding</td><td><label class="toggle-switch"><input type="checkbox" name="above_4g" <?php echo ($biosSettings['above_4g'] ?? '1') == '1' ? 'checked' : ''; ?>><span class="toggle-slider"></span></label></td></tr>
                                <tr><td>Resizable BAR</td><td><label class="toggle-switch"><input type="checkbox" name="resize_bar" <?php echo ($biosSettings['resize_bar'] ?? '0') == '1' ? 'checked' : ''; ?>><span class="toggle-slider"></span></label></td></tr>
                            </table>
                        </div>
                        <!-- ACPI Configuration -->
                        <div id="acpi-config" class="submenu-panel">
                            <div class="section-header"><h3>ACPI Configuration</h3><button type="button" class="info-btn" onclick="showInfoModal('acpi_config')">ⓘ</button></div>
                            <table class="settings-table">
                                <tr><td>ACPI Auto Configuration</td><td><label class="toggle-switch"><input type="checkbox" name="acpi_auto" <?php echo ($biosSettings['acpi_auto'] ?? '1') == '1' ? 'checked' : ''; ?>><span class="toggle-slider"></span></label></td></tr>
                                <tr><td>ACPI Sleep State</td><td><select name="acpi_sleep_state" class="bios-select"><option value="s1" <?php echo ($biosSettings['acpi_sleep_state'] ?? 's3') == 's1' ? 'selected' : ''; ?>>S1 (POS)</option><option value="s3" <?php echo ($biosSettings['acpi_sleep_state'] ?? 's3') == 's3' ? 'selected' : ''; ?>>S3 (Suspend to RAM)</option></select></td></tr>
                            </table>
                        </div>
                        <!-- TPM Configuration -->
                        <div id="tpm-config" class="submenu-panel">
                            <div class="section-header"><h3>Trusted Computing</h3><button type="button" class="info-btn" onclick="showInfoModal('tpm_config')">ⓘ</button></div>
                            <table class="settings-table">
                                <tr><td>TPM Support</td><td><label class="toggle-switch"><input type="checkbox" name="tpm_support" <?php echo ($biosSettings['tpm_support'] ?? '1') == '1' ? 'checked' : ''; ?>><span class="toggle-slider"></span></label></td></tr>
                                <tr><td>TPM State</td><td><select name="tpm_state" class="bios-select"><option value="enabled" <?php echo ($biosSettings['tpm_state'] ?? 'enabled') == 'enabled' ? 'selected' : ''; ?>>Enabled</option><option value="disabled" <?php echo ($biosSettings['tpm_state'] ?? '') == 'disabled' ? 'selected' : ''; ?>>Disabled</option></select></td></tr>
                            </table>
                        </div>
                        <!-- Network Stack -->
                        <div id="network-config" class="submenu-panel">
                            <div class="section-header"><h3>Network Stack</h3><button type="button" class="info-btn" onclick="showInfoModal('network_config')">ⓘ</button></div>
                            <table class="settings-table">
                                <tr><td>Network Stack</td><td><label class="toggle-switch"><input type="checkbox" name="network_stack" <?php echo ($biosSettings['network_stack'] ?? '0') == '1' ? 'checked' : ''; ?>><span class="toggle-slider"></span></label></td></tr>
                                <tr><td>IPv4 PXE Support</td><td><label class="toggle-switch"><input type="checkbox" name="ipv4_pxe" <?php echo ($biosSettings['ipv4_pxe'] ?? '0') == '1' ? 'checked' : ''; ?>><span class="toggle-slider"></span></label></td></tr>
                                <tr><td>IPv6 PXE Support</td><td><label class="toggle-switch"><input type="checkbox" name="ipv6_pxe" <?php echo ($biosSettings['ipv6_pxe'] ?? '0') == '1' ? 'checked' : ''; ?>><span class="toggle-slider"></span></label></td></tr>
                            </table>
                        </div>
                        <div class="form-actions">
                            <button type="submit" class="bios-btn primary">Save</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- Tab: Chipset -->
        <div id="tab-chipset" class="bios-tab">
            <div class="tab-header">
                <h2>Chipset</h2>
                <p class="tab-description">Chipset configuration</p>
            </div>
            <form method="post" class="bios-form">
                <input type="hidden" name="action" value="save_chipset">
                <div class="settings-panel">
                    <div class="settings-section">
                        <div class="section-header"><h3>System Agent (SA) Configuration</h3><button type="button" class="info-btn" onclick="showChipsetInfo('systemAgent')">ⓘ</button></div>
                        <table class="settings-table">
                            <tr><td>VT-d</td><td><label class="toggle-switch"><input type="checkbox" name="vt_d" <?php echo ($biosSettings['vt_d'] ?? '1') == '1' ? 'checked' : ''; ?>><span class="toggle-slider"></span></label></td></tr>
                            <tr><td>Above 4G Decoding</td><td><label class="toggle-switch"><input type="checkbox" name="above_4g" <?php echo ($biosSettings['above_4g'] ?? '1') == '1' ? 'checked' : ''; ?>><span class="toggle-slider"></span></label></td></tr>
                            <tr><td>Re-Size BAR Support</td><td><label class="toggle-switch"><input type="checkbox" name="resize_bar" <?php echo ($biosSettings['resize_bar'] ?? '0') == '1' ? 'checked' : ''; ?>><span class="toggle-slider"></span></label></td></tr>
                        </table>
                    </div>
                    <div class="settings-section">
                        <div class="section-header"><h3>Memory Configuration</h3><button type="button" class="info-btn" onclick="showChipsetInfo('memory')">ⓘ</button></div>
                        <table class="settings-table">
                            <tr><td>Memory Profile (XMP)</td><td><select name="memory_profile" class="bios-select"><option value="auto" <?php echo ($biosSettings['memory_profile'] ?? 'auto') == 'auto' ? 'selected' : ''; ?>>Auto</option><option value="xmp1" <?php echo ($biosSettings['memory_profile'] ?? '') == 'xmp1' ? 'selected' : ''; ?>>XMP Profile 1</option><option value="xmp2" <?php echo ($biosSettings['memory_profile'] ?? '') == 'xmp2' ? 'selected' : ''; ?>>XMP Profile 2</option></select></td></tr>
                            <tr><td>Memory Frequency</td><td><select name="mem_freq" class="bios-select"><option value="auto" <?php echo ($biosSettings['mem_freq'] ?? 'auto') == 'auto' ? 'selected' : ''; ?>>Auto</option><option value="4800" <?php echo ($biosSettings['mem_freq'] ?? '') == '4800' ? 'selected' : ''; ?>>4800 MHz</option><option value="5600" <?php echo ($biosSettings['mem_freq'] ?? '') == '5600' ? 'selected' : ''; ?>>5600 MHz</option><option value="6000" <?php echo ($biosSettings['mem_freq'] ?? '') == '6000' ? 'selected' : ''; ?>>6000 MHz</option><option value="6400" <?php echo ($biosSettings['mem_freq'] ?? '') == '6400' ? 'selected' : ''; ?>>6400 MHz</option></select></td></tr>
                            <tr><td>Memory Fast Boot</td><td><label class="toggle-switch"><input type="checkbox" name="mem_fast_boot" <?php echo ($biosSettings['mem_fast_boot'] ?? '1') == '1' ? 'checked' : ''; ?>><span class="toggle-slider"></span></label></td></tr>
                        </table>
                    </div>
                    <div class="settings-section">
                        <div class="section-header"><h3>Graphics Configuration</h3><button type="button" class="info-btn" onclick="showChipsetInfo('graphics')">ⓘ</button></div>
                        <table class="settings-table">
                            <tr><td>Primary Graphics Adapter</td><td><select name="primary_gpu" class="bios-select"><option value="auto" <?php echo ($biosSettings['primary_gpu'] ?? 'auto') == 'auto' ? 'selected' : ''; ?>>Auto</option><option value="pcie" <?php echo ($biosSettings['primary_gpu'] ?? '') == 'pcie' ? 'selected' : ''; ?>>PCIe</option><option value="igpu" <?php echo ($biosSettings['primary_gpu'] ?? '') == 'igpu' ? 'selected' : ''; ?>>IGPU</option></select></td></tr>
                            <tr><td>Internal Graphics</td><td><select name="internal_gpu" class="bios-select"><option value="auto" <?php echo ($biosSettings['internal_gpu'] ?? 'auto') == 'auto' ? 'selected' : ''; ?>>Auto</option><option value="enabled" <?php echo ($biosSettings['internal_gpu'] ?? '') == 'enabled' ? 'selected' : ''; ?>>Enabled</option><option value="disabled" <?php echo ($biosSettings['internal_gpu'] ?? '') == 'disabled' ? 'selected' : ''; ?>>Disabled</option></select></td></tr>
                            <tr><td>PCIe Speed</td><td><select name="pcie_speed" class="bios-select"><option value="auto" <?php echo ($biosSettings['pcie_speed'] ?? 'auto') == 'auto' ? 'selected' : ''; ?>>Auto</option><option value="gen3" <?php echo ($biosSettings['pcie_speed'] ?? '') == 'gen3' ? 'selected' : ''; ?>>Gen3</option><option value="gen4" <?php echo ($biosSettings['pcie_speed'] ?? '') == 'gen4' ? 'selected' : ''; ?>>Gen4</option></select></td></tr>
                        </table>
                    </div>
                </div>
                <div class="form-actions">
                    <button type="submit" class="bios-btn primary">Save</button>
                </div>
            </form>
        </div>

        <!-- Tab: Boot -->
        <div id="tab-boot" class="bios-tab">
            <div class="tab-header">
                <h2>Boot</h2>
                <p class="tab-description">Boot configuration</p>
            </div>
            <form method="post" class="bios-form">
                <input type="hidden" name="action" value="save_boot">
                <div class="boot-settings">
                    <div class="boot-priority">
                        <div class="section-header">
                            <h3>Boot Priority</h3>
                            <button type="button" class="info-btn" onclick="showBootInfo('bootPriority')">ⓘ</button>
                        </div>
                        <div id="bootList" class="boot-list">
                            <?php 
                            $bootOrder = getBootOrderSimple();
                            foreach ($bootOrder as $index => $device): ?>
                                <div class="boot-item" data-device="<?php echo htmlspecialchars($device); ?>" draggable="true">
                                    <span class="boot-handle">⋮⋮</span>
                                    <span class="boot-icon">💾</span>
                                    <span class="boot-name"><?php echo htmlspecialchars($device); ?></span>
                                    <input type="hidden" name="boot_order[]" value="<?php echo htmlspecialchars($device); ?>">
                                </div>
                            <?php endforeach; ?>
                        </div>
                        <div class="boot-note">Drag and drop to change order</div>
                    </div>
                    <div class="boot-options">
                        <div class="section-header">
                            <h3>Boot Options</h3>
                            <button type="button" class="info-btn" onclick="showBootInfo('bootOptions')">ⓘ</button>
                        </div>
                        <table class="settings-table">
                            <tr><td>Fast Boot</td><td><label class="toggle-switch"><input type="checkbox" name="fast_boot" <?php echo ($biosSettings['fast_boot'] ?? '1') == '1' ? 'checked' : ''; ?>><span class="toggle-slider"></span></label></td></tr>
                            <tr><td>Boot Logo</td><td><label class="toggle-switch"><input type="checkbox" name="boot_logo" <?php echo ($biosSettings['boot_logo'] ?? '1') == '1' ? 'checked' : ''; ?>><span class="toggle-slider"></span></label></td></tr>
                            <tr><td>Quiet Boot</td><td><label class="toggle-switch"><input type="checkbox" name="quiet_boot" <?php echo ($biosSettings['quiet_boot'] ?? '1') == '1' ? 'checked' : ''; ?>><span class="toggle-slider"></span></label></td></tr>
                            <tr><td>CSM Support</td><td><select name="csm_support" class="bios-select"><option value="auto" <?php echo ($biosSettings['csm_support'] ?? 'auto') == 'auto' ? 'selected' : ''; ?>>Auto</option><option value="enabled" <?php echo ($biosSettings['csm_support'] ?? '') == 'enabled' ? 'selected' : ''; ?>>Enabled</option><option value="disabled" <?php echo ($biosSettings['csm_support'] ?? '') == 'disabled' ? 'selected' : ''; ?>>Disabled</option></select></td></tr>
                            <tr><td>Secure Boot</td><td><select name="secure_boot" class="bios-select"><option value="standard" <?php echo ($biosSettings['secure_boot'] ?? 'standard') == 'standard' ? 'selected' : ''; ?>>Standard</option><option value="custom" <?php echo ($biosSettings['secure_boot'] ?? '') == 'custom' ? 'selected' : ''; ?>>Custom</option><option value="disabled" <?php echo ($biosSettings['secure_boot'] ?? '') == 'disabled' ? 'selected' : ''; ?>>Disabled</option></select></td></tr>
                        </table>
                    </div>
                </div>
                <div class="form-actions">
                    <button type="submit" class="bios-btn primary">Save</button>
                </div>
            </form>
        </div>

        <!-- Tab: Security -->
        <div id="tab-security" class="bios-tab">
            <div class="tab-header">
                <h2>Security</h2>
                <p class="tab-description">Security settings</p>
            </div>
            <div class="security-settings">
                <div class="security-section">
                    <div class="section-header">
                        <h3>Password Management</h3>
                        <button type="button" class="info-btn" onclick="showSecurityInfo('passwordManagement')">ⓘ</button>
                    </div>
                    <table class="settings-table">
                        <tr>
                            <td>Administrator Password</td>
                            <td>
                                <span class="password-status <?php echo hasPassword('admin') ? 'installed' : 'not-installed'; ?>">
                                    <?php echo hasPassword('admin') ? 'Installed' : 'Not Installed'; ?>
                                </span>
                                <button type="button" class="bios-btn small" onclick="showPasswordModal('admin')">Change</button>
                            </td>
                        </tr>
                        <tr>
                            <td>User Password</td>
                            <td>
                                <span class="password-status <?php echo hasPassword('user') ? 'installed' : 'not-installed'; ?>">
                                    <?php echo hasPassword('user') ? 'Installed' : 'Not Installed'; ?>
                                </span>
                                <button type="button" class="bios-btn small" onclick="showPasswordModal('user')">Change</button>
                            </td>
                        </tr>
                    </table>
                </div>
                <div class="security-section">
                    <div class="section-header">
                        <h3>Secure Boot</h3>
                        <button type="button" class="info-btn" onclick="showSecurityInfo('secureBoot')">ⓘ</button>
                    </div>
                    <table class="settings-table">
                        <tr><td>Secure Boot Mode</td><td><select name="secure_boot" class="bios-select" disabled><option selected>Standard</option></select></td></tr>
                        <tr><td>Key Management</td><td><button type="button" class="bios-btn small" disabled>Manage Keys</button></td></tr>
                    </table>
                </div>
                <div class="security-section">
                    <div class="section-header">
                        <h3>Additional Security</h3>
                        <button type="button" class="info-btn" onclick="showSecurityInfo('additionalSecurity')">ⓘ</button>
                    </div>
                    <table class="settings-table">
                        <tr><td>TPM Device</td><td><span class="password-status installed">Available</span></td></tr>
                        <tr><td>Intel SGX</td><td><span>Software Controlled</span></td></tr>
                    </table>
                </div>
            </div>
        </div>

        <!-- Tab: Save & Exit -->
        <div id="tab-save_exit" class="bios-tab">
            <div class="tab-header">
                <h2>Save & Exit</h2>
                <p class="tab-description">Save or discard changes</p>
            </div>
            <div class="exit-options">
                <div class="exit-card" onclick="saveAndExit()">
                    <div class="exit-icon">💾</div>
                    <div class="exit-info"><h3>Save Changes and Reset</h3><p>Save changes and reboot system</p></div>
                    <div class="exit-key">F10</div>
                </div>
                <div class="exit-card" onclick="discardAndExit()">
                    <div class="exit-icon">❌</div>
                    <div class="exit-info"><h3>Discard Changes and Exit</h3><p>Discard changes and exit setup</p></div>
                    <div class="exit-key">ESC</div>
                </div>
                <div class="exit-card" onclick="loadOptimizedDefaults()">
                    <div class="exit-icon">⚙️</div>
                    <div class="exit-info"><h3>Load Optimized Defaults</h3><p>Load factory optimized settings</p></div>
                    <div class="exit-key">F9</div>
                </div>
                <div class="exit-card" onclick="saveUserDefaults()">
                    <div class="exit-icon">📋</div>
                    <div class="exit-info"><h3>Save User Defaults</h3><p>Save current settings as user default</p></div>
                    <div class="exit-key"></div>
                </div>
                <div class="exit-card" onclick="loadUserDefaults()">
                    <div class="exit-icon">↩️</div>
                    <div class="exit-info"><h3>Load User Defaults</h3><p>Load previously saved user settings</p></div>
                    <div class="exit-key"></div>
                </div>
                <div class="exit-card" onclick="bootOverride()">
                    <div class="exit-icon">🚀</div>
                    <div class="exit-info"><h3>Boot Override</h3><p>Boot from a specific device (one time)</p></div>
                    <div class="exit-key">F8</div>
                </div>
            </div>
            <div id="bootOverride" class="boot-override-panel" style="display: none;">
                <h3>Select boot device</h3>
                <ul class="boot-device-list">
                    <li onclick="bootFrom('Windows Boot Manager')">🪟 Windows Boot Manager</li>
                    <li onclick="bootFrom('SATA SSD')">💽 SATA SSD</li>
                    <li onclick="bootFrom('USB Drive')">🔌 USB Drive</li>
                    <li onclick="bootFrom('CD/DVD-ROM')">📀 CD/DVD-ROM</li>
                </ul>
            </div>
        </div>
    </div>

    <div class="bios-footer">
        <div class="help-bar">
            <div class="help-item"><span class="key">←→</span> Select Tab</div>
            <div class="help-item"><span class="key">↑↓</span> Select Item</div>
            <div class="help-item"><span class="key">Enter</span> Select</div>
            <div class="help-item"><span class="key">F1</span> Help</div>
            <div class="help-item"><span class="key">F9</span> Defaults</div>
            <div class="help-item"><span class="key">F10</span> Save & Exit</div>
            <div class="help-item"><span class="key">ESC</span> Exit</div>
        </div>
        <div class="copyright">© American Megatrends Inc. All rights reserved.</div>
    </div>
</div>

<!-- Password Modal -->
<div id="passwordModal" class="modal">
    <div class="modal-content">
        <h3 id="passwordModalTitle">Set Password</h3>
        <form id="passwordForm" method="post">
            <input type="hidden" name="action" value="set_password">
            <input type="hidden" name="password_type" id="passwordType">
            <div class="form-group">
                <label>New Password</label>
                <input type="password" name="new_password" id="newPassword" class="bios-input" style="width:100%">
            </div>
            <div class="form-group">
                <label>Confirm Password</label>
                <input type="password" name="confirm_password" id="confirmPassword" class="bios-input" style="width:100%">
            </div>
            <div class="modal-actions">
                <button type="submit" class="bios-btn primary">Set</button>
                <button type="button" class="bios-btn" onclick="closePasswordModal()">Cancel</button>
            </div>
        </form>
    </div>
</div>

<!-- Info Modal -->
<div class="modal" id="infoModal">
    <div class="modal-content info-modal">
        <div class="modal-header">
            <h3 id="infoModalTitle">Information</h3>
            <span class="close-modal" onclick="closeInfoModal()">&times;</span>
        </div>
        <div class="modal-body" id="infoModalBody"></div>
        <div class="modal-actions">
            <button type="button" class="bios-btn primary" onclick="closeInfoModal()">OK</button>
        </div>
    </div>
</div>

<script src="script.js?v=<?php echo time(); ?>"></script>
<script>
    const biosConfig = {
        version: '<?php echo BIOS_VERSION; ?>',
        buildDate: '<?php echo BIOS_BUILD_DATE; ?>',
        vendor: '<?php echo BIOS_VENDOR; ?>'
    };
    <?php if ($db_error): ?>
    console.warn('Database connection failed, using file storage');
    <?php endif; ?>
</script>
<!-- Auth Modal -->
<div id="authModal" class="modal">
    <div class="modal-content auth-modal-content">
        <div class="modal-header">
            <h3>Вход в систему</h3>
            <span class="close-modal" onclick="closeAuthModal()">&times;</span>
        </div>
        <div class="modal-body">
            <form method="post" id="loginForm">
                <input type="hidden" name="action" value="login">
                <div class="form-group">
                    <label>Имя пользователя</label>
                    <input type="text" name="username" class="bios-input" style="width:100%" required>
                </div>
                <div class="form-group">
                    <label>Пароль</label>
                    <input type="password" name="password" class="bios-input" style="width:100%" required>
                </div>
                <div class="modal-actions">
                    <button type="submit" class="bios-btn primary">Войти</button>
                    <button type="button" class="bios-btn" onclick="showRegisterForm()">Регистрация</button>
                    <button type="button" class="bios-btn" onclick="closeAuthModal()">Отмена</button>
                </div>
            </form>
            <form method="post" id="registerForm" style="display:none;">
                <input type="hidden" name="action" value="register">
                <div class="form-group">
                    <label>Имя пользователя</label>
                    <input type="text" name="reg_username" class="bios-input" style="width:100%" required>
                </div>
                <div class="form-group">
                    <label>Пароль (мин. 4 символа)</label>
                    <input type="password" name="reg_password" class="bios-input" style="width:100%" required>
                </div>
                <div class="form-group">
                    <label>Подтверждение пароля</label>
                    <input type="password" name="reg_confirm" class="bios-input" style="width:100%" required>
                </div>
                <div class="modal-actions">
                    <button type="submit" class="bios-btn primary">Зарегистрироваться</button>
                    <button type="button" class="bios-btn" onclick="showLoginForm()">Назад ко входу</button>
                    <button type="button" class="bios-btn" onclick="closeAuthModal()">Отмена</button>
                </div>
            </form>
        </div>
    </div>
</div>
<script>
    // Флаг авторизации, передаваемый из PHP
    var isLoggedIn = <?php echo $currentUser ? 'true' : 'false'; ?>;
</script>
<!-- Break Reminder Overlay -->
<div id="breakOverlay" class="break-overlay" style="display: none;">
    <div class="break-modal">
        <h2>Время размяться! 🧘</h2>
        <p>Вы работаете с настройками BIOS уже некоторое время. Пора сделать перерыв.</p>
        <p><strong>⚠️ Страница с игрой временно недоступна. Ведутся работы для решения этой проблемы.</strong></p>
        <p>Пожалуйста, просто отдохните 5 минут или выполните небольшую разминку самостоятельно.</p>
        <button id="unlockButton" class="bios-btn primary">Продолжить работу</button>
    </div>
</div>
</body>
</html>