<?php
/**
 * Функции для работы с базой данных BIOS
 * Сервер: 134.90.167.42:10306
 * База данных: project_Buziyan
 */

// Настройки подключения к базе данных
$db_host = '134.90.167.42';
$db_port = '10306';
$db_name = 'project_Buziyan';
$db_user = 'Buziyan';
$db_pass = '9t-kwE';

// Кэш соединения (один экземпляр PDO на запрос)
$pdoInstance = null;

// Подключение к базе данных (с кэшированием)
function connectDB() {
    global $pdoInstance, $db_host, $db_port, $db_name, $db_user, $db_pass;
    if ($pdoInstance !== null) {
        return $pdoInstance;
    }
    try {
        $dsn = "mysql:host=$db_host;port=$db_port;dbname=$db_name;charset=utf8mb4";
        $pdo = new PDO($dsn, $db_user, $db_pass);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
        $pdoInstance = $pdo;
        return $pdo;
    } catch(PDOException $e) {
        error_log("Database connection error: " . $e->getMessage());
        die("Ошибка подключения к базе данных. Пожалуйста, попробуйте позже.");
    }
}

// Получить ID текущего пользователя из сессии
function getCurrentUserId() {
    session_start(); // убедитесь, что сессия запущена (в index.php уже есть)
    return $_SESSION['user_id'] ?? null;
}

// Установить текущего пользователя
function setCurrentUser($userId) {
    session_start();
    $_SESSION['user_id'] = $userId;
}

// Очистить сессию (выход)
function logoutUser() {
    session_start();
    unset($_SESSION['user_id']);
    session_destroy();
}

// Зарегистрировать нового пользователя
function registerUser($username, $password, $role = 'user') {
    $pdo = connectDB();
    // Проверка существования
    $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ?");
    $stmt->execute([$username]);
    if ($stmt->fetch()) return false;
    
    $hash = password_hash($password, PASSWORD_DEFAULT);
    $stmt = $pdo->prepare("INSERT INTO users (username, password_hash, role) VALUES (?, ?, ?)");
    if ($stmt->execute([$username, $hash, $role])) {
        $userId = $pdo->lastInsertId();
        // Копируем глобальные настройки для нового пользователя
        copyGlobalSettingsToUser($userId);
        return $userId;
    }
    return false;
}

// Аутентификация
function loginUser($username, $password) {
    $pdo = connectDB();
    $stmt = $pdo->prepare("SELECT id, username, password_hash, role FROM users WHERE username = ?");
    $stmt->execute([$username]);
    $user = $stmt->fetch();
    if ($user && password_verify($password, $user['password_hash'])) {
        setCurrentUser($user['id']);
        return $user;
    }
    return false;
}

// Копирование глобальных настроек (bios_id=1 и user_id IS NULL) для нового пользователя
function copyGlobalSettingsToUser($userId) {
    $pdo = connectDB();
    // Копируем настройки BIOS
    $pdo->prepare("
        INSERT INTO bios_settings (setting_name, setting_value, category, updated_at, bios_id, user_id)
        SELECT setting_name, setting_value, category, NOW(), bios_id, ?
        FROM bios_settings
        WHERE user_id IS NULL AND bios_id = 1
    ")->execute([$userId]);
    
    // Копируем порядок загрузки
    $pdo->prepare("
        INSERT INTO boot_order (device_name, device_type, priority, is_enabled, bios_id, user_id)
        SELECT device_name, device_type, priority, is_enabled, bios_id, ?
        FROM boot_order
        WHERE user_id IS NULL AND bios_id = 1
    ")->execute([$userId]);
    
    // Копируем пароли
    $pdo->prepare("
        INSERT INTO passwords (password_type, password_hash, created_at, bios_id, user_id)
        SELECT password_type, password_hash, NOW(), bios_id, ?
        FROM passwords
        WHERE user_id IS NULL AND bios_id = 1
    ")->execute([$userId]);
    
    // Дополнительно синхронизируем недостающие настройки
    ensureUserSettingsComplete($userId);
}

function ensureUserSettingsComplete($userId) {
    $pdo = connectDB();
    // Получаем все имена глобальных настроек
    $stmt = $pdo->query("SELECT setting_name FROM bios_settings WHERE user_id IS NULL");
    $globalNames = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    foreach ($globalNames as $name) {
        $stmt = $pdo->prepare("SELECT id FROM bios_settings WHERE setting_name = ? AND user_id = ?");
        $stmt->execute([$name, $userId]);
        if (!$stmt->fetch()) {
            // Копируем недостающую настройку
            $pdo->prepare("
                INSERT INTO bios_settings (setting_name, setting_value, category, bios_id, user_id, updated_at)
                SELECT setting_name, setting_value, category, bios_id, ?, NOW()
                FROM bios_settings
                WHERE setting_name = ? AND user_id IS NULL
            ")->execute([$userId, $name]);
        }
    }
}

// ============================================
// ВСПОМОГАТЕЛЬНАЯ: получить активный bios_id
// ============================================
function getCurrentBiosId() {
    $pdo = connectDB();
    // Проверяем, есть ли запись в bios_info
    $stmt = $pdo->query("SELECT id FROM bios_info LIMIT 1");
    $row = $stmt->fetch();
    if ($row) {
        return (int)$row['id'];
    }
    // Если нет – создаём запись по умолчанию
    $pdo->exec("INSERT INTO bios_info (vendor, version, build_date) VALUES ('American Megatrends Inc.', '5.19.01.0011', '03/15/2024')");
    return (int)$pdo->lastInsertId();
}

// ============================================
// 1. ФУНКЦИИ ДЛЯ РАБОТЫ С НАСТРОЙКАМИ
// ============================================

// Получить одну настройку по имени
function getSetting($name) {
    $pdo = connectDB();
    $userId = getCurrentUserId();
    $stmt = $pdo->prepare("
        SELECT setting_value FROM bios_settings 
        WHERE setting_name = ? AND (user_id = ? OR (user_id IS NULL AND ? IS NOT NULL))
        ORDER BY user_id DESC LIMIT 1
    ");
    $stmt->execute([$name, $userId, $userId]);
    $result = $stmt->fetch();
    return $result ? $result['setting_value'] : null;
}

// Получить все настройки из категории
function getSettingsByCategory($category) {
    $pdo = connectDB();
    $stmt = $pdo->prepare("SELECT setting_name, setting_value FROM bios_settings WHERE category = ?");
    $stmt->execute([$category]);
    $result = $stmt->fetchAll();
    $settings = [];
    foreach ($result as $row) {
        $settings[$row['setting_name']] = $row['setting_value'];
    }
    return $settings;
}

// Получить ВСЕ настройки
function getAllSettings() {
    $pdo = connectDB();
    $stmt = $pdo->query("SELECT setting_name, setting_value FROM bios_settings");
    $result = $stmt->fetchAll();
    $settings = [];
    foreach ($result as $row) {
        $settings[$row['setting_name']] = $row['setting_value'];
    }
    return $settings;
}

function getCurrentUserSettings() {
    $pdo = connectDB();
    $userId = getCurrentUserId();
    if (!$userId) {
        // Гость – показываем только глобальные настройки
        $stmt = $pdo->query("SELECT setting_name, setting_value FROM bios_settings WHERE user_id IS NULL");
        $result = $stmt->fetchAll();
        $settings = [];
        foreach ($result as $row) {
            $settings[$row['setting_name']] = $row['setting_value'];
        }
        return $settings;
    }
    // Для авторизованного пользователя: его настройки + глобальные (которых у него нет)
    $stmt = $pdo->prepare("
        SELECT setting_name, setting_value FROM bios_settings WHERE user_id = ?
        UNION
        SELECT setting_name, setting_value FROM bios_settings 
        WHERE user_id IS NULL 
          AND setting_name NOT IN (SELECT setting_name FROM bios_settings WHERE user_id = ?)
    ");
    $stmt->execute([$userId, $userId]);
    $result = $stmt->fetchAll();
    $settings = [];
    foreach ($result as $row) {
        $settings[$row['setting_name']] = $row['setting_value'];
    }
    return $settings;
}

// Обновить настройку
function updateSetting($name, $value) {
    $pdo = connectDB();
    $stmt = $pdo->prepare("UPDATE bios_settings SET setting_value = ?, updated_at = NOW() WHERE setting_name = ?");
    return $stmt->execute([$value, $name]);
}

// Сохранить несколько настроек (исправлена проблема с bios_id)
function saveSettings($settings) {
    $pdo = connectDB();
    $userId = getCurrentUserId();
    if (!$userId) return false;

    $pdo->beginTransaction();
    try {
        foreach ($settings as $name => $value) {
            // Получаем категорию и bios_id из глобальной записи (если есть)
            $stmt = $pdo->prepare("SELECT category, bios_id FROM bios_settings WHERE setting_name = ? AND user_id IS NULL LIMIT 1");
            $stmt->execute([$name]);
            $global = $stmt->fetch();
            $category = $global ? $global['category'] : 'general';
            $biosId = $global ? $global['bios_id'] : 1;

            // INSERT ... ON DUPLICATE KEY UPDATE
            $stmt = $pdo->prepare("
                INSERT INTO bios_settings (setting_name, setting_value, category, bios_id, user_id, updated_at)
                VALUES (?, ?, ?, ?, ?, NOW())
                ON DUPLICATE KEY UPDATE
                    setting_value = VALUES(setting_value),
                    updated_at = NOW()
            ");
            $stmt->execute([$name, $value, $category, $biosId, $userId]);
        }
        $pdo->commit();
        logAction("Settings saved: " . count($settings) . " settings updated for user $userId");
        return true;
    } catch(Exception $e) {
        $pdo->rollBack();
        error_log("Error saving settings: " . $e->getMessage());
        return false;
    }
}
// ============================================
// 2. ФУНКЦИИ ДЛЯ ПОРЯДКА ЗАГРУЗКИ (исправленные)
// ============================================

/**
 * Гарантирует наличие записей boot_order для пользователя.
 * Если у пользователя нет своих устройств – копирует глобальные.
 */
function ensureUserBootOrderExists($userId) {
    $pdo = connectDB();
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM boot_order WHERE user_id = ?");
    $stmt->execute([$userId]);
    if ($stmt->fetchColumn() == 0) {
        $pdo->prepare("
            INSERT INTO boot_order (device_name, device_type, priority, is_enabled, bios_id, user_id)
            SELECT device_name, device_type, priority, is_enabled, bios_id, ?
            FROM boot_order
            WHERE user_id IS NULL AND bios_id = 1
        ")->execute([$userId]);
        logAction("Boot order copied for user $userId");
    }
}

/**
 * Получить порядок загрузки (отсортированный по приоритету) для текущего пользователя.
 */
function getBootOrder() {
    $pdo = connectDB();
    $userId = getCurrentUserId();
    if (!$userId) return [];
    ensureUserBootOrderExists($userId);
    $stmt = $pdo->prepare("
        SELECT device_name, device_type, priority, is_enabled 
        FROM boot_order 
        WHERE user_id = ? AND is_enabled = TRUE 
        ORDER BY priority
    ");
    $stmt->execute([$userId]);
    return $stmt->fetchAll();
}

/**
 * Получить порядок загрузки как простой массив (только названия).
 */
function getBootOrderSimple() {
    $pdo = connectDB();
    $userId = getCurrentUserId();
    if (!$userId) return [];
    ensureUserBootOrderExists($userId);
    $stmt = $pdo->prepare("
        SELECT device_name, priority 
        FROM boot_order 
        WHERE user_id = ? AND is_enabled = TRUE 
        ORDER BY priority
    ");
    $stmt->execute([$userId]);
    $result = $stmt->fetchAll();
    $bootOrder = [];
    foreach ($result as $item) {
        $bootOrder[] = $item['device_name'];
    }
    return $bootOrder;
}

/**
 * Обновить порядок загрузки (перестановка устройств).
 */
function updateBootOrder($devices) {
    $pdo = connectDB();
    $userId = getCurrentUserId();
    if (!$userId) return false;
    $pdo->beginTransaction();
    try {
        foreach ($devices as $priority => $deviceName) {
            $stmt = $pdo->prepare("UPDATE boot_order SET priority = ? WHERE device_name = ? AND user_id = ?");
            $stmt->execute([$priority + 1, $deviceName, $userId]);
        }
        $pdo->commit();
        logAction("Boot order updated for user $userId");
        return true;
    } catch(Exception $e) {
        $pdo->rollBack();
        error_log("Error updating boot order: " . $e->getMessage());
        return false;
    }
}

/**
 * Включить/выключить загрузочное устройство.
 */
function toggleBootDevice($deviceName, $enabled) {
    $pdo = connectDB();
    $userId = getCurrentUserId();
    if (!$userId) return false;
    $stmt = $pdo->prepare("UPDATE boot_order SET is_enabled = ? WHERE device_name = ? AND user_id = ?");
    return $stmt->execute([$enabled, $deviceName, $userId]);
}

// ============================================
// 3. ФУНКЦИИ ДЛЯ СИСТЕМНОЙ ИНФОРМАЦИИ
// ============================================

// Получить информацию о BIOS
function getBiosInfo() {
    $pdo = connectDB();
    $stmt = $pdo->query("SELECT * FROM bios_info ORDER BY id DESC LIMIT 1");
    return $stmt->fetch();
}

// Получить информацию о процессоре
function getCpuInfo() {
    $pdo = connectDB();
    $stmt = $pdo->query("SELECT * FROM cpu_info ORDER BY id DESC LIMIT 1");
    return $stmt->fetch();
}

// Получить информацию о памяти
function getMemoryInfo() {
    $pdo = connectDB();
    $stmt = $pdo->query("SELECT * FROM memory_info ORDER BY id DESC LIMIT 1");
    return $stmt->fetch();
}

// ============================================
// 4. ФУНКЦИИ ДЛЯ ПАРОЛЕЙ (с поддержкой пользователей)
// ============================================

// Установить пароль (для текущего пользователя)
function setPassword($type, $password) {
    $pdo = connectDB();
    $userId = getCurrentUserId();
    $hash = password_hash($password, PASSWORD_DEFAULT);
    
    // Проверяем, существует ли запись для данного типа и user_id
    if ($userId) {
        $stmt = $pdo->prepare("SELECT id FROM passwords WHERE password_type = ? AND user_id = ?");
        $stmt->execute([$type, $userId]);
    } else {
        $stmt = $pdo->prepare("SELECT id FROM passwords WHERE password_type = ? AND user_id IS NULL");
        $stmt->execute([$type]);
    }
    
    if ($stmt->fetch()) {
        // Обновляем существующую запись
        if ($userId) {
            $stmt = $pdo->prepare("UPDATE passwords SET password_hash = ? WHERE password_type = ? AND user_id = ?");
            $result = $stmt->execute([$hash, $type, $userId]);
        } else {
            $stmt = $pdo->prepare("UPDATE passwords SET password_hash = ? WHERE password_type = ? AND user_id IS NULL");
            $result = $stmt->execute([$hash, $type]);
        }
    } else {
        // Вставляем новую запись
        $stmt = $pdo->prepare("INSERT INTO passwords (password_type, password_hash, user_id) VALUES (?, ?, ?)");
        $result = $stmt->execute([$type, $hash, $userId]);
    }
    
    if ($result) {
        logAction("Password set for: $type");
    }
    return $result;
}

// Проверить пароль (для текущего пользователя)
function verifyPassword($type, $password) {
    $pdo = connectDB();
    $userId = getCurrentUserId();
    if ($userId) {
        $stmt = $pdo->prepare("SELECT password_hash FROM passwords WHERE password_type = ? AND user_id = ?");
        $stmt->execute([$type, $userId]);
    } else {
        $stmt = $pdo->prepare("SELECT password_hash FROM passwords WHERE password_type = ? AND user_id IS NULL");
        $stmt->execute([$type]);
    }
    $result = $stmt->fetch();
    if ($result) {
        return password_verify($password, $result['password_hash']);
    }
    return false;
}

// Проверить, установлен ли пароль (для текущего пользователя)
function hasPassword($type) {
    $pdo = connectDB();
    $userId = getCurrentUserId();
    if ($userId) {
        $stmt = $pdo->prepare("SELECT id FROM passwords WHERE password_type = ? AND user_id = ?");
        $stmt->execute([$type, $userId]);
    } else {
        $stmt = $pdo->prepare("SELECT id FROM passwords WHERE password_type = ? AND user_id IS NULL");
        $stmt->execute([$type]);
    }
    return $stmt->fetch() !== false;
}

// Удалить пароль (для текущего пользователя)
function removePassword($type) {
    $pdo = connectDB();
    $userId = getCurrentUserId();
    if ($userId) {
        $stmt = $pdo->prepare("DELETE FROM passwords WHERE password_type = ? AND user_id = ?");
        $result = $stmt->execute([$type, $userId]);
    } else {
        $stmt = $pdo->prepare("DELETE FROM passwords WHERE password_type = ? AND user_id IS NULL");
        $result = $stmt->execute([$type]);
    }
    if ($result) {
        logAction("Password removed for: $type");
    }
    return $result;
}

// ============================================
// 5. ФУНКЦИИ ДЛЯ ЛОГИРОВАНИЯ
// ============================================

// Записать действие в лог
function logAction($action, $ip = null) {
    $pdo = connectDB();
    if (!$ip) $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    $userId = getCurrentUserId(); // может быть null для гостя
    $stmt = $pdo->prepare("INSERT INTO bios_logs (action, user_ip, user_id) VALUES (?, ?, ?)");
    return $stmt->execute([$action, $ip, $userId]);
}

// Получить последние логи
function getRecentLogs($limit = 50) {
    $pdo = connectDB();
    $stmt = $pdo->prepare("SELECT * FROM bios_logs ORDER BY created_at DESC LIMIT ?");
    $stmt->execute([$limit]);
    return $stmt->fetchAll();
}

// Очистить старые логи
function clearOldLogs($days = 30) {
    $pdo = connectDB();
    $stmt = $pdo->prepare("DELETE FROM bios_logs WHERE created_at < DATE_SUB(NOW(), INTERVAL ? DAY)");
    return $stmt->execute([$days]);
}

// ============================================
// 6. ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ
// ============================================

// Сбросить настройки по умолчанию (расширенный список)
function resetToDefaults() {
    $defaultSettings = [
        // Main
        'system_date' => date('Y-m-d'),
        'system_time' => date('H:i:s'),
        // Advanced
        'vt_x' => '1',
        'hyper_threading' => '1',
        'active_cores' => 'all',
        'speedstep' => 'auto',
        'turbo_mode' => '1',
        'c_state' => '1',
        'sata_controller' => '1',
        'sata_mode' => 'ahci',
        'hot_plug' => '0',
        'legacy_usb' => 'enabled',
        'xhci_handoff' => '1',
        'usb_mass_storage' => '1',
        'pcie_root_port' => 'enabled',
        'pcie_link_speed' => 'auto',
        'above_4g' => '1',
        'resize_bar' => '0',
        'acpi_auto' => '1',
        'acpi_sleep_state' => 's3',
        'tpm_support' => '1',
        'tpm_state' => 'enabled',
        'network_stack' => '0',
        'ipv4_pxe' => '0',
        'ipv6_pxe' => '0',
        // Chipset
        'pch_thermal' => '1',
        'hpet' => '1',
        'dmi_speed' => 'auto',
        'vt_d' => '1',
        'memory_profile' => 'auto',
        'mem_freq' => 'auto',
        'mem_fast_boot' => '1',
        'primary_gpu' => 'auto',
        'internal_gpu' => 'auto',
        'pcie_speed' => 'auto',
        // Boot
        'fast_boot' => '1',
        'boot_logo' => '1',
        'quiet_boot' => '1',
        'csm_support' => 'auto',
        'secure_boot' => 'standard'
    ];
    
    $result = saveSettings($defaultSettings);
    if ($result) {
        logAction("Settings reset to defaults");
    }
    return $result;
}

// Получить всю информацию о системе
function getFullSystemInfo() {
    return [
        'bios' => getBiosInfo(),
        'cpu' => getCpuInfo(),
        'memory' => getMemoryInfo(),
        'boot_order' => getBootOrder()
    ];
}

// Проверка подключения
function testConnection() {
    try {
        $pdo = connectDB();
        $pdo->query("SELECT 1");
        return true;
    } catch(Exception $e) {
        return false;
    }
}

// Получить количество записей в таблице (исправлена SQL-инъекция)
function getTableCount($tableName) {
    // Белый список разрешённых таблиц
    $allowedTables = ['bios_settings', 'boot_order', 'bios_logs'];
    if (!in_array($tableName, $allowedTables, true)) {
        return 0;
    }
    $pdo = connectDB();
    // Экранируем имя таблицы обратными кавычками
    $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM `$tableName`");
    $stmt->execute();
    $result = $stmt->fetch();
    return $result ? (int)$result['count'] : 0;
}

// Получить статистику БД
function getDatabaseStats() {
    return [
        'settings_count' => getTableCount('bios_settings'),
        'boot_devices_count' => getTableCount('boot_order'),
        'logs_count' => getTableCount('bios_logs'),
        'has_admin_password' => hasPassword('admin'),
        'has_user_password' => hasPassword('user'),
        'connection_ok' => testConnection()
    ];
}

// ============================================
// 7. ИНИЦИАЛИЗАЦИЯ БАЗЫ ДАННЫХ
// ============================================

// Проверить и инициализировать таблицы начальными данными
function initializeDatabase() {
    $pdo = connectDB();
    
    // 1. Проверяем bios_info
    $stmt = $pdo->query("SELECT COUNT(*) as count FROM bios_info");
    $count = $stmt->fetch();
    if ($count['count'] == 0) {
        $pdo->exec("
            INSERT INTO bios_info (vendor, version, build_date) VALUES
            ('American Megatrends Inc.', '5.19.01.0011', '03/15/2024');
        ");
    }
    
    // 2. Проверяем cpu_info
    $stmt = $pdo->query("SELECT COUNT(*) as count FROM cpu_info");
    $count = $stmt->fetch();
    if ($count['count'] == 0) {
        $pdo->exec("
            INSERT INTO cpu_info (cpu_name, speed, cores, cache) VALUES
            ('Intel Core i9-14900K', '3.2 GHz (5.8 GHz Turbo)', '24 (8P + 16E)', '36 MB');
        ");
    }
    
    // 3. Проверяем memory_info
    $stmt = $pdo->query("SELECT COUNT(*) as count FROM memory_info");
    $count = $stmt->fetch();
    if ($count['count'] == 0) {
        $pdo->exec("
            INSERT INTO memory_info (total_memory, frequency, dimm1, dimm2, dimm3, dimm4) VALUES
            ('32 GB', 'DDR5-7200', '16 GB Kingston Fury', '16 GB Kingston Fury', 'Empty', 'Empty');
        ");
    }
    
    // 4. Проверяем boot_order (если пусто – добавляем устройства по умолчанию)
    $stmt = $pdo->query("SELECT COUNT(*) as count FROM boot_order");
    $count = $stmt->fetch();
    if ($count['count'] == 0) {
        $biosId = getCurrentBiosId();
        $pdo->exec("
            INSERT INTO boot_order (device_name, device_type, priority, is_enabled, bios_id) VALUES
            ('Windows Boot Manager', 'windows', 1, 1, $biosId),
            ('SATA SSD: Samsung 970 EVO', 'ssd', 2, 1, $biosId),
            ('SATA HDD: WD Blue 1TB', 'hdd', 3, 1, $biosId),
            ('USB Drive', 'usb', 4, 1, $biosId),
            ('CD/DVD-ROM Drive', 'cdrom', 5, 1, $biosId),
            ('Network: PXE Boot', 'network', 6, 1, $biosId);
        ");
    }

        // Добавляем недостающие глобальные настройки (на основе массива)
    $requiredSettings = [
        // main
        'system_date', 'system_time',
        // advanced
        'vt_x', 'hyper_threading', 'active_cores', 'speedstep', 'turbo_mode', 'c_state',
        'sata_controller', 'sata_mode', 'hot_plug',
        'legacy_usb', 'xhci_handoff', 'usb_mass_storage',
        'pcie_root_port', 'pcie_link_speed', 'above_4g', 'resize_bar', 'sr_iov',
        'acpi_auto', 'acpi_sleep_state',
        'tpm_support', 'tpm_state',
        'network_stack', 'ipv4_pxe', 'ipv6_pxe',
        // chipset
        'pch_thermal', 'hpet', 'dmi_speed', 'vt_d',
        'memory_profile', 'mem_freq', 'mem_fast_boot',
        'primary_gpu', 'internal_gpu', 'pcie_speed',
        // boot
        'fast_boot', 'boot_logo', 'quiet_boot', 'csm_support', 'secure_boot'
    ];
    
    foreach ($requiredSettings as $name) {
        $stmt = $pdo->prepare("SELECT id FROM bios_settings WHERE setting_name = ? AND user_id IS NULL");
        $stmt->execute([$name]);
        if (!$stmt->fetch()) {
            $pdo->prepare("
                INSERT INTO bios_settings (setting_name, setting_value, category, bios_id, user_id, updated_at)
                VALUES (?, '0', 'general', 1, NULL, NOW())
            ")->execute([$name]);
        }
    }
    
    logAction("Database initialized with default data");
    return true;
}

// ============================================
// 8. ФУНКЦИИ-ОБЁРТКИ ДЛЯ СОВМЕСТИМОСТИ
// ============================================

if (!function_exists('hasAdminPassword')) {
    function hasAdminPassword() {
        return hasPassword('admin');
    }
}
if (!function_exists('hasUserPassword')) {
    function hasUserPassword() {
        return hasPassword('user');
    }
}
?>