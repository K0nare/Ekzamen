<?php
/**
 * AMI BIOS Configuration File
 */

// ============================================
// Режим работы (можно переключить на 'file' при отсутствии БД)
// ============================================
define('STORAGE_MODE', 'database'); // 'database' или 'file'

// ============================================
// BIOS версии и информация
// ============================================
define('BIOS_VENDOR', 'American Megatrends Inc.');
define('BIOS_VERSION', '5.19.01.0011');
define('BIOS_CORE_VERSION', '5.12');
define('BIOS_COMPLIANCY', 'UEFI 2.7, PI 1.6');
define('BIOS_BUILD_DATE', '03/15/2024');

// ============================================
// Пути к файлам (для файлового хранилища)
// ============================================
define('DATA_DIR', __DIR__ . '/data');
define('DATA_FILE', DATA_DIR . '/settings.json');
define('PASSWORD_FILE', DATA_DIR . '/passwords.php');
define('LOG_FILE', DATA_DIR . '/bios.log');

// Создаём директорию data, если её нет
if (!is_dir(DATA_DIR)) {
    mkdir(DATA_DIR, 0755, true);
}

// ============================================
// Настройки по умолчанию (расширенные и совместимые с БД)
// ============================================
define('DEFAULT_SETTINGS', [
    // Main
    'system_date' => date('Y-m-d'),
    'system_time' => date('H:i:s'),
    
    // Advanced
    'vt_x' => '1',
    'hyper_threading' => '1',
    'active_cores' => 'all',
    'speedstep' => 'auto',
    'turbo_mode' => '1',
    'c_state' => '1',
    'sata_controller' => '1',
    'sata_mode' => 'ahci',
    'hot_plug' => '0',
    'legacy_usb' => 'enabled',
    'xhci_handoff' => '1',
    'usb_mass_storage' => '1',
    'pcie_root_port' => 'enabled',
    'pcie_link_speed' => 'auto',
    'above_4g' => '1',
    'resize_bar' => '0',
    'sr_iov' => '0',
    'acpi_auto' => '1',
    'acpi_sleep_state' => 's3',
    'tpm_support' => '1',
    'tpm_state' => 'enabled',
    'network_stack' => '0',
    'ipv4_pxe' => '0',
    'ipv6_pxe' => '0',
    
    // Chipset
    'pch_thermal' => '1',
    'hpet' => '1',
    'dmi_speed' => 'auto',
    'deep_sleep' => 'enabled',
    'vt_d' => '1',
    'graphics_voltage' => 'auto',
    'memory_profile' => 'auto',
    'mem_freq' => 'auto',
    'mem_fast_boot' => '1',
    'gear_mode' => 'auto',
    'mem_remap' => '1',
    'primary_gpu' => 'auto',
    'internal_gpu' => 'auto',
    'igpu_memory' => '64',
    'dvmt' => '32M',
    'pcie_speed' => 'auto',
    'pcie_slot1' => 'auto',
    'pcie_slot2' => 'auto',
    'pcie_slot3' => 'auto',
    'm2_slot1' => 'enabled',
    'm2_slot2' => 'enabled',
    'usb_controller' => '1',
    'usb_ports' => 'auto',
    'usb3_support' => '1',
    'xhci_mode' => 'auto',
    'sata_controller_chipset' => '1',
    'sata_mode_chipset' => 'ahci',
    
    // Boot
    'fast_boot' => '1',
    'boot_logo' => '1',
    'quiet_boot' => '1',
    'csm_support' => 'auto',
    'secure_boot' => 'standard',
    'boot_order' => ['Windows Boot Manager', 'SATA SSD: Samsung 970 EVO', 'SATA HDD: WD Blue 1TB', 'USB Drive', 'CD/DVD-ROM Drive', 'Network: PXE Boot'],
    
    // Power Management
    'ac_power_loss' => 'power_off',
    'wake_on_lan' => '0',
    'wake_on_usb' => '0',
    'wake_on_rtc' => '0',
    'rtc_date' => '1',
    'rtc_time' => '08:00:00',
    'erp_ready' => '0'
]);

// ============================================
// Системная информация (для отображения в Main)
// ============================================
define('SYSTEM_INFO', [
    'cpu' => [
        'name' => 'Intel Core i9-14900K',
        'speed' => '3.2 GHz (5.8 GHz Turbo)',
        'cores' => '24 (8P + 16E)',
        'microcode' => '0x11C',
        'cache' => '36 MB'
    ],
    'memory' => [
        'total' => '32 GB',
        'frequency' => 'DDR5-7200',
        'dimm1' => '16 GB Kingston Fury',
        'dimm2' => '16 GB Kingston Fury',
        'dimm3' => 'Empty',
        'dimm4' => 'Empty'
    ]
]);

// ============================================
// Дополнительные настройки окружения
// ============================================
// Включение/выключение режима отладки
define('DEBUG_MODE', false);

// Часовой пояс
date_default_timezone_set('Europe/Moscow');

// Обработка ошибок (только если не в production)
if (DEBUG_MODE) {
    ini_set('display_errors', 1);
    error_reporting(E_ALL);
} else {
    ini_set('display_errors', 0);
    error_reporting(E_ALL & ~E_NOTICE & ~E_DEPRECATED);
}
?>