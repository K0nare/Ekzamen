<?php
/**
 * AMI BIOS Functions
 */

require_once __DIR__ . '/config.php';

// ============================================
// Защита от повторного объявления функций (конфликт с db_functions.php)
// ============================================

if (!function_exists('loadBiosSettings')) {
    /**
     * Загрузка настроек BIOS
     */
    function loadBiosSettings() {
        if (file_exists(DATA_FILE)) {
            $data = json_decode(file_get_contents(DATA_FILE), true);
            if ($data) {
                return array_merge(DEFAULT_SETTINGS, $data);
            }
        }
        return DEFAULT_SETTINGS;
    }
}

if (!function_exists('saveBiosSettings')) {
    /**
     * Сохранение настроек BIOS
     */
    function saveBiosSettings($settings) {
        $current = loadBiosSettings();
        $newSettings = array_merge($current, $settings);
        
        if (!is_dir(dirname(DATA_FILE))) {
            mkdir(dirname(DATA_FILE), 0777, true);
        }
        
        return file_put_contents(DATA_FILE, json_encode($newSettings, JSON_PRETTY_PRINT));
    }
}

if (!function_exists('getSystemInfo')) {
    /**
     * Получение системной информации
     */
    function getSystemInfo() {
        return SYSTEM_INFO;
    }
}

if (!function_exists('hasAdminPassword')) {
    /**
     * Проверка наличия пароля администратора
     */
    function hasAdminPassword() {
        if (file_exists(PASSWORD_FILE)) {
            include PASSWORD_FILE;
            return isset($admin_password) && !empty($admin_password);
        }
        return false;
    }
}

if (!function_exists('hasUserPassword')) {
    /**
     * Проверка наличия пользовательского пароля
     */
    function hasUserPassword() {
        if (file_exists(PASSWORD_FILE)) {
            include PASSWORD_FILE;
            return isset($user_password) && !empty($user_password);
        }
        return false;
    }
}

if (!function_exists('setPasswordFile')) {
    /**
     * Установка пароля
     */
    function setPasswordFile($type, $password) {
        $passwords = [];
        if (file_exists(PASSWORD_FILE)) {
            include PASSWORD_FILE;
            $passwords = [
                'admin_password' => $admin_password ?? '',
                'user_password' => $user_password ?? ''
            ];
        }
        
        if ($type === 'admin') {
            $passwords['admin_password'] = password_hash($password, PASSWORD_DEFAULT);
        } else {
            $passwords['user_password'] = password_hash($password, PASSWORD_DEFAULT);
        }
        
        $content = "<?php\n";
        $content .= "// BIOS Password File\n";
        $content .= "// Generated: " . date('Y-m-d H:i:s') . "\n\n";
        $content .= "\$admin_password = '" . addslashes($passwords['admin_password']) . "';\n";
        $content .= "\$user_password = '" . addslashes($passwords['user_password']) . "';\n";
        
        return file_put_contents(PASSWORD_FILE, $content);
    }
}

if (!function_exists('verifyPasswordFile')) {
    /**
     * Проверка пароля
     */
    function verifyPasswordFile($type, $password) {
        if (!file_exists(PASSWORD_FILE)) {
            return false;
        }
        
        include PASSWORD_FILE;
        
        if ($type === 'admin' && isset($admin_password)) {
            return password_verify($password, $admin_password);
        } elseif ($type === 'user' && isset($user_password)) {
            return password_verify($password, $user_password);
        }
        
        return false;
    }
}

if (!function_exists('handleBiosRequest')) {
    /**
     * Обработка POST запросов
     */
    function handleBiosRequest($post) {
        $response = ['success' => false, 'message' => ''];
        
        if (!isset($post['action'])) {
            return $response;
        }
        
        switch ($post['action']) {
            case 'save_main':
            case 'save_advanced':
            case 'save_boot':
                $settings = array_filter($post, function($key) {
                    return !in_array($key, ['action', 'submit']);
                }, ARRAY_FILTER_USE_KEY);
                
                if (saveBiosSettings($settings)) {
                    $response['success'] = true;
                    $response['message'] = 'Settings saved successfully!';
                } else {
                    $response['message'] = 'Error saving settings!';
                }
                break;
                
            case 'set_password':
                if (isset($post['password_type']) && isset($post['new_password'])) {
                    if ($post['new_password'] === $post['confirm_password']) {
                        if (setPasswordFile($post['password_type'], $post['new_password'])) {
                            $response['success'] = true;
                            $response['message'] = 'Password set successfully!';
                        } else {
                            $response['message'] = 'Error setting password!';
                        }
                    } else {
                        $response['message'] = 'Passwords do not match!';
                    }
                }
                break;
                
            case 'load_defaults':
                if (saveBiosSettings(DEFAULT_SETTINGS)) {
                    $response['success'] = true;
                    $response['message'] = 'Default settings loaded!';
                }
                break;
                
            case 'clear_passwords':
                if (file_exists(PASSWORD_FILE)) {
                    unlink(PASSWORD_FILE);
                    $response['success'] = true;
                    $response['message'] = 'Passwords cleared!';
                }
                break;
        }
        
        return $response;
    }
}

if (!function_exists('logBiosAction')) {
    /**
     * Логирование действий BIOS
     */
    function logBiosAction($action, $user = 'system') {
        $logFile = DATA_DIR . '/bios.log';
        $timestamp = date('Y-m-d H:i:s');
        $logEntry = "[$timestamp] User: $user - Action: $action\n";
        
        file_put_contents($logFile, $logEntry, FILE_APPEND);
    }
}

if (!function_exists('getBiosLog')) {
    /**
     * Получение лога BIOS
     */
    function getBiosLog($lines = 100) {
        $logFile = DATA_DIR . '/bios.log';
        
        if (!file_exists($logFile)) {
            return [];
        }
        
        $logs = file($logFile);
        return array_slice($logs, -$lines);
    }
}
?>