<?php
require_once 'config.php';

try {
    // Проверяем, есть ли уже этот столбец
    $stmt = $pdo->prepare("SHOW COLUMNS FROM users LIKE 'failed_attempts'");
    $stmt->execute();
    $columnExists = $stmt->fetch();

    if (!$columnExists) {
        $pdo->exec("ALTER TABLE users ADD COLUMN failed_attempts INT DEFAULT 0");
        echo "✅ Столбец 'failed_attempts' успешно добавлен в таблицу users.<br>";
        echo "Теперь вход должен работать.<br>";
        echo "<a href='login.php'>→ Перейти к входу</a>";
    } else {
        echo "ℹ️ Столбец 'failed_attempts' уже существует. Ошибка исчезнет.<br>";
        echo "<a href='login.php'>→ Перейти к входу</a>";
    }
} catch (PDOException $e) {
    die("❌ Ошибка: " . $e->getMessage());
}
?>