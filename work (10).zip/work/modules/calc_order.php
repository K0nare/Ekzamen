<?php
require_once '../config.php';
require_once '../functions.php';

// Получаем ID заказа из URL (если нет — по умолчанию 1)
$orderId = isset($_GET['id']) ? (int)$_GET['id'] : 1;

// --- 1. Считаем стоимость материалов по нормам расхода ---
$sql = "
    SELECT 
        oi.order_id,
        SUM(oi.quantity * pn.quantity_per_unit * m.price) AS total_material_cost
    FROM order_items oi
    JOIN production_norms pn ON oi.product_id = pn.product_id
    JOIN materials m ON pn.material_id = m.id
    WHERE oi.order_id = ?
    GROUP BY oi.order_id;
";
$stmt = $pdo->prepare($sql);
$stmt->execute([$orderId]);
$materialCost = $stmt->fetchColumn();
if ($materialCost === false) {
    $materialCost = 0;
}

// --- 2. Считаем стоимость самой продукции ---
$sql2 = "
    SELECT 
        SUM(oi.quantity * oi.price) AS total_product_cost
    FROM order_items oi
    WHERE oi.order_id = ?
";
$stmt2 = $pdo->prepare($sql2);
$stmt2->execute([$orderId]);
$productCost = $stmt2->fetchColumn();
if ($productCost === false) {
    $productCost = 0;
}

// --- 3. Общая стоимость ---
$totalCost = $productCost + $materialCost;

// --- 4. Получаем список позиций заказа для детализации ---
$sqlItems = "
    SELECT 
        oi.id,
        p.name AS product_name,
        oi.quantity,
        oi.price AS product_price,
        pn.quantity_per_unit,
        m.name AS material_name,
        m.price AS material_price,
        (pn.quantity_per_unit * m.price) AS material_cost_per_unit
    FROM order_items oi
    JOIN products p ON oi.product_id = p.id
    LEFT JOIN production_norms pn ON oi.product_id = pn.product_id
    LEFT JOIN materials m ON pn.material_id = m.id
    WHERE oi.order_id = ?
    ORDER BY oi.id
";
$stmtItems = $pdo->prepare($sqlItems);
$stmtItems->execute([$orderId]);
$items = $stmtItems->fetchAll(PDO::FETCH_ASSOC);

include '../templates/header.php';
?>
<div class="container mt-4">
    <h2>Расчёт стоимости заказа №<?= $orderId ?></h2>

    <!-- Кнопка выбора заказа -->
    <div class="mb-3">
        <form method="get" class="row g-2">
            <div class="col-auto">
                <label for="orderId" class="visually-hidden">ID заказа</label>
                <input type="number" id="orderId" name="id" class="form-control" value="<?= $orderId ?>" min="1">
            </div>
            <div class="col-auto">
                <button type="submit" class="btn btn-primary">Пересчитать</button>
            </div>
        </form>
    </div>

    <!-- Результат -->
    <div class="card mb-4">
        <div class="card-header bg-success text-white">
            Итоговая стоимость
        </div>
        <div class="card-body">
            <p><strong>Стоимость продукции:</strong> <?= number_format($productCost, 2) ?> руб.</p>
            <p><strong>Стоимость материалов:</strong> <?= number_format($materialCost, 2) ?> руб.</p>
            <p><strong>Общая стоимость заказа:</strong> <?= number_format($totalCost, 2) ?> руб.</p>
        </div>
    </div>

    <!-- Детализация по позициям -->
    <?php if ($items): ?>
        <h3>Детализация</h3>
        <div class="table-responsive">
            <table class="table table-bordered table-hover">
                <thead class="table-light">
                    <tr>
                        <th>Продукция</th>
                        <th>Кол-во</th>
                        <th>Цена за шт.</th>
                        <th>Материал</th>
                        <th>Норма расхода</th>
                        <th>Цена материала</th>
                        <th>Стоимость материалов</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($items as $item): ?>
                        <tr>
                            <td><?= htmlspecialchars($item['product_name']) ?></td>
                            <td><?= $item['quantity'] ?></td>
                            <td><?= number_format($item['product_price'], 2) ?></td>
                            <td><?= htmlspecialchars($item['material_name'] ?? '—') ?></td>
                            <td><?= $item['quantity_per_unit'] ?? '—' ?></td>
                            <td><?= isset($item['material_price']) ? number_format($item['material_price'], 2) : '—' ?></td>
                            <td><?= isset($item['material_cost_per_unit']) ? number_format($item['material_cost_per_unit'] * $item['quantity'], 2) : '0.00' ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php else: ?>
        <div class="alert alert-warning">В этом заказе нет позиций.</div>
    <?php endif; ?>

    <a href="../index.php" class="btn btn-secondary mt-3">← Назад</a>
</div>
<?php include '../templates/footer.php'; ?>