<?php
require_once '../config.php';
require_once '../functions.php';

$fullName = '';
$resultMessage = '';

/**
 * Валидация ФИО клиента
 * @param string $name
 * @return array ['isValid' => bool, 'error' => string]
 */
function validateFullName($name) {
    // 1. Не пусто
    if (empty(trim($name))) {
        return ['isValid' => false, 'error' => 'ФИО не должно быть пустым'];
    }
    // 2. Проверка на запрещённые символы (из задания)
    $forbiddenChars = ['&', '!', '@', '#', '$', '%', '^', '*', '(', ')', '+', '=', '~', '`', '/', '\\', '|', '<', '>', '?'];
    foreach ($forbiddenChars as $char) {
        if (strpos($name, $char) !== false) {
            return ['isValid' => false, 'error' => "ФИО содержит запрещённый символ '$char'"];
        }
    }
    // 3. Проверка на цифры (в ФИО не должно быть цифр)
    if (preg_match('/\d/', $name)) {
        return ['isValid' => false, 'error' => 'ФИО не должно содержать цифр'];
    }
    // 4. Минимальная и максимальная длина (3–100 символов)
    $len = mb_strlen(trim($name), 'UTF-8');
    if ($len < 3 || $len > 100) {
        return ['isValid' => false, 'error' => 'ФИО должно содержать от 3 до 100 символов'];
    }
    // 5. Разрешённые символы (буквы, пробелы, тире, точка, апостроф)
    if (!preg_match('/^[\p{L}\s\-\'\.]+$/u', $name)) {
        return ['isValid' => false, 'error' => 'ФИО может содержать только буквы, пробелы, тире, точки и апострофы'];
    }
    return ['isValid' => true, 'error' => ''];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // 1. Получить данные с эмулятора
    if (isset($_POST['get_data'])) {
        $url = 'http://localhost:4444/TransferSimulator/fullName';
        $response = @file_get_contents($url);
        if ($response === false) {
            $resultMessage = '❌ Ошибка: эмулятор недоступен. Проверьте запуск TransferSimulator.';
        } else {
            $data = json_decode($response, true);
            $fullName = $data['value'] ?? '';
            $resultMessage = 'Данные получены: ' . htmlspecialchars($fullName);
        }
    }

    // 2. Отправить результат теста (валидация + запись в CSV)
    elseif (isset($_POST['submit_test'])) {
        $fullName = $_POST['full_name'] ?? '';
        
        // Вызываем расширенную валидацию
        $validation = validateFullName($fullName);
        
        if ($validation['isValid']) {
            $status = 'Успешно';
            $resultMessage = '✅ Валидация пройдена';
        } else {
            $status = 'Не успешно';
            $resultMessage = '❌ ' . $validation['error'];
        }
        $resultMessage .= '<br>ФИО: ' . htmlspecialchars($fullName);

        // Запись в testcase.csv
        $file = '../testcase.csv';
        $fp = fopen($file, 'a');
        fputcsv($fp, [date('Y-m-d H:i:s'), $fullName, $status]);
        fclose($fp);
        $resultMessage .= '<br>✅ Результат записан в testcase.csv (аналог ТестКейс.docx)';
    }
}

include '../templates/header.php';
?>
<div class="container mt-4">
    <h2>Валидация данных клиента</h2>
    <div class="card">
        <div class="card-body">
            <form method="post">
                <div class="row">
                    <div class="col-md-6">
                        <button type="submit" name="get_data" class="btn btn-info w-100">Получить данные</button>
                    </div>
                    <div class="col-md-6">
                        <button type="submit" name="submit_test" class="btn btn-primary w-100">Отправить результат теста</button>
                    </div>
                </div>
                <div class="form-group mt-3">
                    <label for="full_name">ФИО клиента</label>
                    <input type="text" class="form-control" id="full_name" name="full_name" value="<?= htmlspecialchars($fullName ?? '') ?>" readonly>
                </div>
                <?php if ($resultMessage): ?>
                    <div class="mt-3 alert alert-info"><?= $resultMessage ?></div>
                <?php endif; ?>
            </form>
        </div>
    </div>
    <a href="../index.php" class="btn btn-secondary mt-3">← Назад</a>
</div>
<?php include '../templates/footer.php'; ?>