This file is a merged representation of the entire codebase, combined into a single document by Repomix.

# File Summary

## Purpose
This file contains a packed representation of the entire repository's contents.
It is designed to be easily consumable by AI systems for analysis, code review,
or other automated processes.

## File Format
The content is organized as follows:
1. This summary section
2. Repository information
3. Directory structure
4. Repository files (if enabled)
5. Multiple file entries, each consisting of:
  a. A header with the file path (## File: path/to/file)
  b. The full contents of the file in a code block

## Usage Guidelines
- This file should be treated as read-only. Any changes should be made to the
  original repository files, not this packed version.
- When processing this file, use the file path to distinguish
  between different files in the repository.
- Be aware that this file may contain sensitive information. Handle it with
  the same level of security as you would the original repository.

## Notes
- Some files may have been excluded based on .gitignore rules and Repomix's configuration
- Binary files are not included in this packed representation. Please refer to the Repository Structure section for a complete list of file paths, including binary files
- Files matching patterns in .gitignore are excluded
- Files matching default ignore patterns are excluded
- Files are sorted by Git change count (files with more changes are at the bottom)

# Directory Structure
```
work/
  .vscode/
    settings.json
  admin/
    templates/
      footer.php
      header.php
    import_json.php
    index.php
    setup_db.php
  captcha/
    1.png
    2.png
    3.png
    4.png
  modules/
    api_client.php
    api_emulator.php
    calc_order.php
    profile.php
    todo.php
    upload.php
  templates/
    footer.php
    header.php
  uploads/
    1780507163.png
   ª §ç¨ª¨.json
  ¥áâ¥©á.docx
  config.php
  db_setup.php
  fix_db.php
  functions.php
  index.php
  login.php
  logout.php
  register.php
  tasks.json
  testcase.csv
  work_auth (4).sql
```

# Files

## File: work/.vscode/settings.json
```json
{
    "workbench.activityBar.location": "default",
    "workbench.colorTheme": "Default Dark Modern",
    "workbench.iconTheme": "vs-seti",
    "workbench.preferredDarkColorTheme": "Default Dark Modern",
    "window.autoDetectColorScheme": false
}
```

## File: work/admin/templates/footer.php
```php
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
```

## File: work/admin/templates/header.php
```php
<?php
if (!isset($_SESSION['user'])) {
    header('Location: ../login.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Админка</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-primary mb-4">
    <div class="container">
        <a class="navbar-brand" href="../index.php"><i class="fas fa-home me-2"></i>На главную</a>
        <span class="navbar-text text-white-50">Админка</span>
    </div>
</nav>
<div class="container"></div>
```

## File: work/admin/import_json.php
```php
<?php
session_start();
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    die('Доступ запрещён. Только для администратора.');
}
require_once '../config.php';

$message = '';
$error = '';

// Обработка загрузки файла
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['json_file'])) {
    $file = $_FILES['json_file'];
    
    // Проверка на ошибки
    if ($file['error'] !== UPLOAD_ERR_OK) {
        $error = 'Ошибка загрузки файла. Код: ' . $file['error'];
    } else {
        // Проверяем тип файла
        $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        if ($ext !== 'json') {
            $error = 'Разрешены только файлы с расширением .json';
        } else {
            // Читаем содержимое
            $json = file_get_contents($file['tmp_name']);
            $data = json_decode($json, true);
            
            if ($data === null) {
                $error = 'Ошибка декодирования JSON. Проверьте структуру файла.';
            } else {
                // Начинаем транзакцию
                $pdo->beginTransaction();
                try {
                    // Очищаем таблицу customers перед импортом
                    $pdo->exec("DELETE FROM customers");
                    
                    // Вставляем данные
                    $stmt = $pdo->prepare("INSERT INTO customers (id, name, inn, address, phone, salesman, buyer) VALUES (:id, :name, :inn, :address, :phone, :salesman, :buyer)");
                    
                    foreach ($data as $row) {
                        $stmt->execute([
                            ':id' => $row['id'],
                            ':name' => $row['name'],
                            ':inn' => $row['inn'] ?? '',
                            ':address' => $row['addres'] ?? '',
                            ':phone' => $row['phone'] ?? '',
                            ':salesman' => (int)($row['salesman'] ?? 0),
                            ':buyer' => (int)($row['buyer'] ?? 0)
                        ]);
                    }
                    
                    $pdo->commit();
                    $message = '✅ Импорт завершён. Загружено ' . count($data) . ' записей.';
                } catch (PDOException $e) {
                    $pdo->rollBack();
                    $error = 'Ошибка при импорте: ' . $e->getMessage();
                }
            }
        }
    }
}

include '../templates/header.php';
?>
<div class="container mt-4">
    <h2>Импорт Заказчики.json</h2>
    <p>Загрузите файл <code>Заказчики.json</code> для импорта в таблицу <code>customers</code>.</p>
    <p><strong>Внимание:</strong> Все существующие данные в таблице <code>customers</code> будут удалены перед импортом.</p>

    <?php if ($error): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>
    <?php if ($message): ?>
        <div class="alert alert-success"><?= $message ?></div>
    <?php endif; ?>

    <form method="post" enctype="multipart/form-data">
        <div class="mb-3">
            <label for="json_file" class="form-label">Выберите файл .json</label>
            <input type="file" class="form-control" id="json_file" name="json_file" accept=".json" required>
        </div>
        <button type="submit" class="btn btn-primary">
            <i class="fas fa-upload me-2"></i> Импортировать
        </button>
        <a href="index.php" class="btn btn-secondary">Назад в админку</a>
    </form>
</div>
<?php include '../templates/footer.php'; ?>
```

## File: work/admin/index.php
```php
<?php
session_start();
if (!isset($_SESSION['user'])) {
    header('Location: ../login.php');
    exit;
}
if (!isset($_SESSION['user']['role']) || $_SESSION['user']['role'] !== 'admin') {
    die('Доступ запрещён. Только для администратора.');
}
require_once '../config.php';
require_once '../functions.php';

// --- Список таблиц (исключаем системные) ---
$tables = getTables($pdo);
$tables = array_filter($tables, function($t) {
    return !in_array($t, ['login_attempts', 'logs']);
});

// --- Определяем режим ---
$mode = $_GET['mode'] ?? '';

// ==================== ОБЩИЕ ПЕРЕМЕННЫЕ ====================
$selectedTable = $_GET['table'] ?? '';
$action = $_GET['action'] ?? 'list';
$id = $_GET['id'] ?? null;
$page = max(1, intval($_GET['page'] ?? 1));
$limit = 10;
$offset = ($page - 1) * $limit;
$search = trim($_GET['search'] ?? '');

// Если режим не выбран — показываем кнопки выбора
if (!$mode) {
    include 'templates/header.php';
    ?>
    <div class="container mt-5">
        <h1 class="mb-4 text-center">Административная панель</h1>
        <div class="row justify-content-center">
            <div class="col-md-5">
                <a href="?mode=crud" class="btn btn-primary w-100 p-4 mb-3" style="font-size: 1.5rem;">
                    <i class="fas fa-database me-2"></i> CRUD интерфейс
                </a>
                <p class="text-muted text-center">Работа со всеми таблицами системы (включая пользователей)</p>
            </div>
            <div class="col-md-5">
                <a href="?mode=users" class="btn btn-success w-100 p-4 mb-3" style="font-size: 1.5rem;">
                    <i class="fas fa-users me-2"></i> Управление пользователями
                </a>
                <p class="text-muted text-center">Специализированный интерфейс для управления пользователями</p>
            </div>
        </div>
        <div class="row justify-content-center mt-3">
            <div class="col-md-5">
                <a href="setup_db.php" class="btn btn-danger w-100 p-3" style="font-size: 1.2rem;">
                    <i class="fas fa-database me-2"></i> Установка базы данных
                </a>
                <p class="text-muted text-center">Пересоздать БД и импортировать Заказчики.json</p>
            </div>
            <div class="col-md-5">
                <a href="import_json.php" class="btn btn-warning w-100 p-3" style="font-size: 1.2rem;">
                    <i class="fas fa-upload me-2"></i> Импорт .json
                </a>
                <p class="text-muted text-center">Импортировать Заказчики.json в таблицу customers</p>
            </div>
        </div>
        <div class="text-center mt-3">
            <a href="../index.php" class="btn btn-secondary">← На главную</a>
        </div>
    </div>
    <?php
    include 'templates/footer.php';
    exit;
}

// ==================== ФУНКЦИЯ ДЛЯ ВЫВОДА СПЕЦИАЛИЗИРОВАННОГО ИНТЕРФЕЙСА ПОЛЬЗОВАТЕЛЕЙ (режим users) ====================
function renderUserManagementInterface(
    PDO $pdo,
    int $page,
    int $limit,
    int $offset,
    string $search,
    string $action,
    ?int $id
): void {
    // --- Обработка POST (добавление/редактирование пользователей) ---
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
        if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== ($_SESSION['csrf_token'] ?? '')) {
            die('Ошибка CSRF токена');
        }

        if ($_POST['action'] === 'add_user') {
            $login = trim($_POST['login'] ?? '');
            $password = $_POST['password'] ?? '';
            $full_name = trim($_POST['full_name'] ?? '');
            $role = $_POST['role'] ?? 'user';
            $blocked = isset($_POST['blocked']) ? 1 : 0;

            $stmt = $pdo->prepare("SELECT id FROM users WHERE login = ?");
            $stmt->execute([$login]);
            if ($stmt->fetch()) {
                $_SESSION['flash'] = '❌ Пользователь с таким логином уже существует.';
                header('Location: ?mode=users&search=' . urlencode($search) . '&page=' . $page);
                exit;
            }

            $hash = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("INSERT INTO users (login, password_hash, full_name, role, blocked) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([$login, $hash, $full_name, $role, $blocked]);
            logAction($pdo, $_SESSION['user']['id'], "Добавлен пользователь $login");
            $_SESSION['flash'] = '✅ Пользователь добавлен.';
            header('Location: ?mode=users&search=' . urlencode($search) . '&page=' . $page);
            exit;
        } elseif ($_POST['action'] === 'edit_user' && isset($_POST['id'])) {
            $id = (int)$_POST['id'];
            $full_name = trim($_POST['full_name'] ?? '');
            $role = $_POST['role'] ?? 'user';
            $blocked = isset($_POST['blocked']) ? 1 : 0;
            $new_password = $_POST['new_password'] ?? '';

            if ($new_password !== '') {
                $hash = password_hash($new_password, PASSWORD_DEFAULT);
                $stmt = $pdo->prepare("UPDATE users SET full_name = ?, role = ?, blocked = ?, password_hash = ? WHERE id = ?");
                $stmt->execute([$full_name, $role, $blocked, $hash, $id]);
            } else {
                $stmt = $pdo->prepare("UPDATE users SET full_name = ?, role = ?, blocked = ? WHERE id = ?");
                $stmt->execute([$full_name, $role, $blocked, $id]);
            }
            logAction($pdo, $_SESSION['user']['id'], "Изменён пользователь ID $id");
            $_SESSION['flash'] = '✅ Пользователь обновлён.';
            header('Location: ?mode=users&search=' . urlencode($search) . '&page=' . $page);
            exit;
        }
    }

    // --- Обработка GET-действий (block/unblock/delete) ---
    if (isset($_GET['action']) && in_array($_GET['action'], ['block', 'unblock', 'delete'])) {
        if (!isset($_GET['csrf_token']) || $_GET['csrf_token'] !== ($_SESSION['csrf_token'] ?? '')) {
            die('Ошибка CSRF токена');
        }
        $id = (int)$_GET['id'];
        if ($_GET['action'] === 'block') {
            setUserBlocked($pdo, $id, 1);
            logAction($pdo, $_SESSION['user']['id'], "Заблокирован пользователь ID $id");
            $_SESSION['flash'] = 'Пользователь заблокирован.';
        } elseif ($_GET['action'] === 'unblock') {
            setUserBlocked($pdo, $id, 0);
            logAction($pdo, $_SESSION['user']['id'], "Разблокирован пользователь ID $id");
            $_SESSION['flash'] = 'Пользователь разблокирован.';
        } elseif ($_GET['action'] === 'delete') {
            $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
            $stmt->execute([$id]);
            logAction($pdo, $_SESSION['user']['id'], "Удалён пользователь ID $id");
            $_SESSION['flash'] = 'Пользователь удалён.';
        }
        header('Location: ?mode=users&search=' . urlencode($search) . '&page=' . $page);
        exit;
    }

    // --- Поиск и пагинация ---
    $countSql = "SELECT COUNT(*) FROM users";
    $countParams = [];
    if ($search) {
        $countSql .= " WHERE login LIKE ? OR full_name LIKE ?";
        $countParams = ["%$search%", "%$search%"];
    }
    $stmt = $pdo->prepare($countSql);
    $stmt->execute($countParams);
    $total = $stmt->fetchColumn();
    $totalPages = ceil($total / $limit);

    $sql = "SELECT * FROM users";
    if ($search) {
        $sql .= " WHERE login LIKE ? OR full_name LIKE ?";
        $params = ["%$search%", "%$search%"];
    } else {
        $params = [];
    }
    $sql .= " ORDER BY id LIMIT ? OFFSET ?";
    $stmt = $pdo->prepare($sql);
    $paramIndex = 1;
    foreach ($params as $p) {
        $stmt->bindValue($paramIndex++, $p, PDO::PARAM_STR);
    }
    $stmt->bindValue($paramIndex++, $limit, PDO::PARAM_INT);
    $stmt->bindValue($paramIndex++, $offset, PDO::PARAM_INT);
    $stmt->execute();
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Генерация CSRF-токена
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    ?>
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h2><i class="fas fa-users me-2"></i> Управление пользователями</h2>
        <a href="?mode=users&action=add_user" class="btn btn-success">
            <i class="fas fa-plus"></i> Добавить пользователя
        </a>
    </div>

    <form method="get" class="mb-3">
        <div class="input-group">
            <input type="text" name="search" class="form-control" placeholder="Поиск..." value="<?= htmlspecialchars($search) ?>">
            <button type="submit" class="btn btn-outline-primary">🔍</button>
            <?php if ($search): ?>
                <a href="?mode=users" class="btn btn-outline-secondary">Сбросить</a>
            <?php endif; ?>
        </div>
        <input type="hidden" name="mode" value="users">
    </form>

    <?php if ($rows): ?>
        <div class="table-responsive">
            <table class="table table-bordered table-hover">
                <thead class="table-light">
                    <tr><th>ID</th><th>Логин</th><th>Имя</th><th>Роль</th><th>Статус</th><th>Действия</th></tr>
                </thead>
                <tbody>
                    <?php foreach ($rows as $row): ?>
                        <tr>
                            <td><?= $row['id'] ?></td>
                            <td><?= htmlspecialchars($row['login']) ?></td>
                            <td><?= htmlspecialchars($row['full_name']) ?></td>
                            <td><?= htmlspecialchars($row['role']) ?></td>
                            <td><?= $row['blocked'] ? '<span class="badge bg-danger">Заблокирован</span>' : '<span class="badge bg-success">Активен</span>' ?></td>
                            <td>
                                <?php if ($row['blocked']): ?>
                                    <a href="?mode=users&action=unblock&id=<?= $row['id'] ?>&csrf_token=<?= $_SESSION['csrf_token'] ?>&search=<?= urlencode($search) ?>&page=<?= $page ?>" class="btn btn-sm btn-success">Разблокировать</a>
                                <?php else: ?>
                                    <a href="?mode=users&action=block&id=<?= $row['id'] ?>&csrf_token=<?= $_SESSION['csrf_token'] ?>&search=<?= urlencode($search) ?>&page=<?= $page ?>" class="btn btn-sm btn-danger">Заблокировать</a>
                                <?php endif; ?>
                                <a href="?mode=users&action=edit_user&id=<?= $row['id'] ?>&search=<?= urlencode($search) ?>&page=<?= $page ?>" class="btn btn-sm btn-warning">Редактировать</a>
                                <a href="?mode=users&action=delete&id=<?= $row['id'] ?>&csrf_token=<?= $_SESSION['csrf_token'] ?>&search=<?= urlencode($search) ?>&page=<?= $page ?>" class="btn btn-sm btn-secondary" onclick="return confirm('Удалить?')">Удалить</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <?php if ($totalPages > 1): ?>
            <nav>
                <ul class="pagination justify-content-center">
                    <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                        <li class="page-item <?= $i == $page ? 'active' : '' ?>">
                            <a class="page-link" href="?mode=users&page=<?= $i ?>&search=<?= urlencode($search) ?>"><?= $i ?></a>
                        </li>
                    <?php endfor; ?>
                </ul>
            </nav>
        <?php endif; ?>
    <?php else: ?>
        <div class="alert alert-info">Нет пользователей для отображения.</div>
    <?php endif; ?>

    <?php if (isset($_GET['action']) && $_GET['action'] === 'add_user'): ?>
        <!-- Форма добавления пользователя -->
        <div class="card mt-4">
            <div class="card-header bg-success text-white">
                <i class="fas fa-plus-circle me-2"></i> Добавить пользователя
            </div>
            <div class="card-body">
                <form method="post">
                    <input type="hidden" name="action" value="add_user">
                    <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                    <div class="row">
                        <div class="col-md-3">
                            <label>Логин</label>
                            <input type="text" name="login" class="form-control" required>
                        </div>
                        <div class="col-md-3">
                            <label>Пароль</label>
                            <input type="password" name="password" class="form-control" required>
                        </div>
                        <div class="col-md-3">
                            <label>Имя</label>
                            <input type="text" name="full_name" class="form-control">
                        </div>
                        <div class="col-md-3">
                            <label>Роль</label>
                            <select name="role" class="form-select">
                                <option value="user">Пользователь</option>
                                <option value="admin">Администратор</option>
                            </select>
                        </div>
                    </div>
                    <div class="mt-2 form-check">
                        <input type="checkbox" name="blocked" class="form-check-input" id="blockedAdd">
                        <label class="form-check-label" for="blockedAdd">Заблокирован</label>
                    </div>
                    <button type="submit" class="btn btn-success mt-2">Добавить</button>
                    <a href="?mode=users&search=<?= urlencode($search) ?>&page=<?= $page ?>" class="btn btn-secondary mt-2">Отмена</a>
                </form>
            </div>
        </div>
    <?php endif; ?>

    <?php if (isset($_GET['action']) && $_GET['action'] === 'edit_user' && isset($_GET['id'])): ?>
        <?php
        $id = (int)$_GET['id'];
        $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
        $stmt->execute([$id]);
        $editUser = $stmt->fetch(PDO::FETCH_ASSOC);
        ?>
        <?php if ($editUser): ?>
        <div class="card mt-4">
            <div class="card-header bg-warning text-white">
                <i class="fas fa-edit me-2"></i> Редактирование пользователя <?= htmlspecialchars($editUser['login']) ?>
            </div>
            <div class="card-body">
                <form method="post">
                    <input type="hidden" name="action" value="edit_user">
                    <input type="hidden" name="id" value="<?= $id ?>">
                    <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                    <div class="row">
                        <div class="col-md-4">
                            <label>Имя</label>
                            <input type="text" name="full_name" class="form-control" value="<?= htmlspecialchars($editUser['full_name']) ?>">
                        </div>
                        <div class="col-md-4">
                            <label>Роль</label>
                            <select name="role" class="form-select">
                                <option value="user" <?= $editUser['role'] === 'user' ? 'selected' : '' ?>>Пользователь</option>
                                <option value="admin" <?= $editUser['role'] === 'admin' ? 'selected' : '' ?>>Администратор</option>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label>Новый пароль (оставьте пустым, если не меняете)</label>
                            <input type="password" name="new_password" class="form-control">
                        </div>
                    </div>
                    <div class="mt-2 form-check">
                        <input type="checkbox" name="blocked" class="form-check-input" id="blockedEdit" <?= $editUser['blocked'] ? 'checked' : '' ?>>
                        <label class="form-check-label" for="blockedEdit">Заблокирован</label>
                    </div>
                    <button type="submit" class="btn btn-warning mt-2">Сохранить</button>
                    <a href="?mode=users&search=<?= urlencode($search) ?>&page=<?= $page ?>" class="btn btn-secondary mt-2">Отмена</a>
                </form>
            </div>
        </div>
        <?php endif; ?>
    <?php endif; ?>
    <?php
}

// ==================== УНИВЕРСАЛЬНЫЙ CRUD ДЛЯ ВСЕХ ТАБЛИЦ (режим crud) ====================
if ($mode === 'crud') {
    $colsInfo = [];
    $primaryKey = null;
    $foreignKeys = [];
    $rows = [];
    $total = 0;
    $totalPages = 0;
    $editRow = null;

    if ($selectedTable && in_array($selectedTable, $tables)) {
        [$colsInfo, $primaryKey] = getColumnsInfo($pdo, $selectedTable);
        $foreignKeys = getForeignKeys($pdo, $selectedTable);

        // Поиск и пагинация
        $countSql = "SELECT COUNT(*) FROM `$selectedTable`";
        $countParams = [];
        if ($search) {
            $searchFields = [];
            foreach ($colsInfo as $col) {
                if (in_array($col['type'], ['varchar', 'text', 'char', 'enum', 'date', 'datetime'])) {
                    $searchFields[] = "`{$col['name']}` LIKE ?";
                    $countParams[] = "%$search%";
                }
            }
            if ($searchFields) {
                $countSql .= " WHERE " . implode(' OR ', $searchFields);
            }
        }
        $stmt = $pdo->prepare($countSql);
        $stmt->execute($countParams);
        $total = $stmt->fetchColumn();
        $totalPages = ceil($total / $limit);

        $sql = "SELECT * FROM `$selectedTable`";
        $params = [];
        if ($search) {
            $searchFields = [];
            foreach ($colsInfo as $col) {
                if (in_array($col['type'], ['varchar', 'text', 'char', 'enum', 'date', 'datetime'])) {
                    $searchFields[] = "`{$col['name']}` LIKE ?";
                    $params[] = "%$search%";
                }
            }
            if ($searchFields) {
                $sql .= " WHERE " . implode(' OR ', $searchFields);
            }
        }
        $sql .= " ORDER BY `$primaryKey` LIMIT ? OFFSET ?";
        $stmt = $pdo->prepare($sql);
        $paramIndex = 1;
        foreach ($params as $p) {
            $stmt->bindValue($paramIndex++, $p, PDO::PARAM_STR);
        }
        $stmt->bindValue($paramIndex++, $limit, PDO::PARAM_INT);
        $stmt->bindValue($paramIndex++, $offset, PDO::PARAM_INT);
        $stmt->execute();
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // --- Обработка POST (добавление/редактирование) ---
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
            if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== ($_SESSION['csrf_token'] ?? '')) {
                die('Ошибка CSRF токена');
            }

            if ($_POST['action'] === 'add') {
                $setParts = [];
                $values = [];
                foreach ($colsInfo as $col) {
                    $name = $col['name'];
                    if ($name === $primaryKey) continue;
                    if (isset($_POST[$name]) && $_POST[$name] !== '') {
                        // Для таблицы users хешируем пароль
                        if ($selectedTable === 'users' && $name === 'password_hash') {
                            $values[] = password_hash($_POST[$name], PASSWORD_DEFAULT);
                        } else {
                            $values[] = $_POST[$name];
                        }
                        $setParts[] = "`$name` = ?";
                    }
                }
                if ($setParts) {
                    $sql = "INSERT INTO `$selectedTable` SET " . implode(',', $setParts);
                    $stmt = $pdo->prepare($sql);
                    $stmt->execute($values);
                    logAction($pdo, $_SESSION['user']['id'], "Добавлена запись в таблицу $selectedTable");
                    $_SESSION['flash'] = "✅ Запись добавлена.";
                }
                header('Location: ?mode=crud&table=' . urlencode($selectedTable) . '&page=' . $page . '&search=' . urlencode($search));
                exit;
            } elseif ($_POST['action'] === 'edit' && $id) {
                $setParts = [];
                $values = [];
                foreach ($colsInfo as $col) {
                    $name = $col['name'];
                    if ($name === $primaryKey) continue;
                    if (isset($_POST[$name]) && $_POST[$name] !== '') {
                        // Для таблицы users хешируем пароль
                        if ($selectedTable === 'users' && $name === 'password_hash') {
                            $values[] = password_hash($_POST[$name], PASSWORD_DEFAULT);
                        } else {
                            $values[] = $_POST[$name];
                        }
                        $setParts[] = "`$name` = ?";
                    }
                }
                if ($setParts) {
                    $values[] = $id;
                    $sql = "UPDATE `$selectedTable` SET " . implode(',', $setParts) . " WHERE `$primaryKey` = ?";
                    $stmt = $pdo->prepare($sql);
                    $stmt->execute($values);
                    logAction($pdo, $_SESSION['user']['id'], "Изменена запись ID $id в таблице $selectedTable");
                    $_SESSION['flash'] = "✅ Запись обновлена.";
                }
                header('Location: ?mode=crud&table=' . urlencode($selectedTable) . '&page=' . $page . '&search=' . urlencode($search));
                exit;
            }
        }

        // --- Удаление (GET) ---
        if ($action === 'delete' && $id) {
            if (!isset($_GET['csrf_token']) || $_GET['csrf_token'] !== ($_SESSION['csrf_token'] ?? '')) {
                die('Ошибка CSRF токена');
            }
            $stmt = $pdo->prepare("DELETE FROM `$selectedTable` WHERE `$primaryKey` = ?");
            $stmt->execute([$id]);
            logAction($pdo, $_SESSION['user']['id'], "Удалена запись ID $id из таблицы $selectedTable");
            $_SESSION['flash'] = "✅ Запись удалена.";
            header('Location: ?mode=crud&table=' . urlencode($selectedTable) . '&page=' . $page . '&search=' . urlencode($search));
            exit;
        }

        // --- Данные для редактирования ---
        if ($action === 'edit' && $id) {
            $editRow = getRowData($pdo, $selectedTable, $id, $primaryKey);
        }
    }

    // Генерация CSRF-токена
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));

    include 'templates/header.php';
    ?>
    <div class="mb-3">
        <a href="?mode=" class="btn btn-outline-secondary">
            <i class="fas fa-arrow-left me-1"></i> Назад к выбору режима
        </a>
    </div>
    <div class="card mb-4">
        <div class="card-header bg-primary text-white">
            <i class="fas fa-database me-2"></i> CRUD интерфейс
        </div>
        <div class="card-body">
            <form method="get" class="row g-3 align-items-end">
                <div class="col-md-4">
                    <label class="form-label fw-bold">Таблица</label>
                    <select name="table" class="form-select" onchange="this.form.submit()">
                        <option value="">-- Выберите таблицу --</option>
                        <?php foreach ($tables as $tbl): ?>
                            <option value="<?= htmlspecialchars($tbl) ?>" <?= $selectedTable === $tbl ? 'selected' : '' ?>>
                                <?= htmlspecialchars($tbl) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <?php if ($selectedTable): ?>
                    <div class="col-md-4">
                        <label class="form-label">Поиск</label>
                        <div class="input-group">
                            <input type="text" name="search" class="form-control" placeholder="Поиск..." value="<?= htmlspecialchars($search) ?>">
                            <button type="submit" class="btn btn-outline-primary">🔍</button>
                            <?php if ($search): ?>
                                <a href="?mode=crud&table=<?= urlencode($selectedTable) ?>" class="btn btn-outline-secondary">Сбросить</a>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endif; ?>
                <input type="hidden" name="mode" value="crud">
            </form>
        </div>
    </div>

    <?php if ($selectedTable): ?>
        <?php if (isset($_SESSION['flash'])): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?= htmlspecialchars($_SESSION['flash']) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
            <?php unset($_SESSION['flash']); ?>
        <?php endif; ?>

        <div class="d-flex justify-content-between align-items-center mb-3">
            <h2><i class="fas fa-table me-2"></i><?= htmlspecialchars($selectedTable) ?></h2>
            <a href="?mode=crud&table=<?= urlencode($selectedTable) ?>&action=add" class="btn btn-success">
                <i class="fas fa-plus"></i> Добавить запись
            </a>
        </div>

        <?php if ($rows): ?>
            <div class="table-responsive">
                <table class="table table-bordered table-hover">
                    <thead class="table-light">
                        <tr>
                            <?php foreach ($colsInfo as $col): ?>
                                <th><?= htmlspecialchars($col['name']) ?></th>
                            <?php endforeach; ?>
                            <th>Действия</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($rows as $row): ?>
                            <tr>
                                <?php foreach ($colsInfo as $col): 
                                    $val = $row[$col['name']];
                                    // Для таблицы users поле password_hash показываем как обычное поле
                                    $isFk = false;
                                    foreach ($foreignKeys as $fk) {
                                        if ($fk['COLUMN_NAME'] === $col['name']) {
                                            $isFk = true;
                                            $refTable = $fk['REFERENCED_TABLE_NAME'];
                                            $refCol = $fk['REFERENCED_COLUMN_NAME'];
                                            echo "<td>" . htmlspecialchars(getDisplayValue($pdo, $refTable, $val, $refCol)) . "</td>";
                                            break;
                                        }
                                    }
                                    if (!$isFk) echo "<td>" . htmlspecialchars($val ?? '') . "</td>";
                                endforeach; ?>
                                <td class="action-icons">
                                    <a href="?mode=crud&table=<?= urlencode($selectedTable) ?>&action=edit&id=<?= $row[$primaryKey] ?>&csrf_token=<?= $_SESSION['csrf_token'] ?>&page=<?= $page ?>&search=<?= urlencode($search) ?>" class="btn btn-sm btn-outline-primary">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <a href="?mode=crud&table=<?= urlencode($selectedTable) ?>&action=delete&id=<?= $row[$primaryKey] ?>&csrf_token=<?= $_SESSION['csrf_token'] ?>&page=<?= $page ?>&search=<?= urlencode($search) ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Удалить запись?')">
                                        <i class="fas fa-trash-alt"></i>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <?php if ($totalPages > 1): ?>
                <nav>
                    <ul class="pagination justify-content-center">
                        <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                            <li class="page-item <?= $i == $page ? 'active' : '' ?>">
                                <a class="page-link" href="?mode=crud&table=<?= urlencode($selectedTable) ?>&page=<?= $i ?>&search=<?= urlencode($search) ?>"><?= $i ?></a>
                            </li>
                        <?php endfor; ?>
                    </ul>
                </nav>
            <?php endif; ?>
        <?php else: ?>
            <div class="alert alert-info">Нет данных для отображения.</div>
        <?php endif; ?>

        <!-- Форма добавления/редактирования -->
        <?php if ($action === 'add' || ($action === 'edit' && $editRow)): ?>
            <div class="card mt-4">
                <div class="card-header bg-primary text-white">
                    <i class="fas <?= $action === 'add' ? 'fa-plus-circle' : 'fa-pen' ?> me-2"></i>
                    <?= $action === 'add' ? 'Добавление записи' : 'Редактирование записи' ?>
                </div>
                <div class="card-body">
                    <form method="post">
                        <input type="hidden" name="action" value="<?= $action === 'add' ? 'add' : 'edit' ?>">
                        <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                        <?php foreach ($colsInfo as $col): 
                            $name = $col['name'];
                            if ($name === $primaryKey) continue;
                            $value = $editRow ? ($editRow[$name] ?? '') : '';
                            $isFk = false;
                            $fkTable = $fkColumn = '';
                            foreach ($foreignKeys as $fk) {
                                if ($fk['COLUMN_NAME'] === $name) {
                                    $isFk = true;
                                    $fkTable = $fk['REFERENCED_TABLE_NAME'];
                                    $fkColumn = $fk['REFERENCED_COLUMN_NAME'];
                                    break;
                                }
                            }
                        ?>
                            <div class="mb-3">
                                <label class="form-label fw-bold"><?= htmlspecialchars($name) ?></label>
                                <?php if ($isFk && $fkTable): ?>
                                    <select name="<?= $name ?>" class="form-select">
                                        <option value="">-- Не выбрано --</option>
                                        <?php
                                        $fkRows = $pdo->query("SELECT * FROM `$fkTable`")->fetchAll(PDO::FETCH_ASSOC);
                                        foreach ($fkRows as $opt) {
                                            $optId = $opt[$fkColumn];
                                            $selected = ($value == $optId) ? 'selected' : '';
                                            $display = $optId;
                                            foreach (['name', 'title', 'full_name', 'login', 'company_name', 'description'] as $candidate) {
                                                if (isset($opt[$candidate])) { $display = $opt[$candidate]; break; }
                                            }
                                            echo "<option value='$optId' $selected>" . htmlspecialchars($display) . "</option>";
                                        }
                                        ?>
                                    </select>
                                <?php elseif (!empty($col['enum'])): ?>
                                    <select name="<?= $name ?>" class="form-select">
                                        <option value="">-- Выберите --</option>
                                        <?php foreach ($col['enum'] as $enumVal): ?>
                                            <option value="<?= htmlspecialchars($enumVal) ?>" <?= ($value == $enumVal) ? 'selected' : '' ?>><?= htmlspecialchars($enumVal) ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                <?php else: ?>
                                    <input type="text" name="<?= $name ?>" class="form-control" value="<?= htmlspecialchars($value) ?>">
                                <?php endif; ?>
                            </div>
                        <?php endforeach; ?>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save"></i> <?= $action === 'add' ? 'Добавить' : 'Сохранить' ?>
                        </button>
                        <a href="?mode=crud&table=<?= urlencode($selectedTable) ?>" class="btn btn-secondary">Отмена</a>
                    </form>
                </div>
            </div>
        <?php endif; ?>
    <?php else: ?>
        <div class="alert alert-info">Выберите таблицу для работы.</div>
    <?php endif; ?>
    <?php include 'templates/footer.php'; ?>
    <?php
}

// ==================== УПРАВЛЕНИЕ ПОЛЬЗОВАТЕЛЯМИ (режим users) ====================
if ($mode === 'users') {
    include 'templates/header.php';
    ?>
    <div class="mb-3">
        <a href="?mode=" class="btn btn-outline-secondary">
            <i class="fas fa-arrow-left me-1"></i> Назад к выбору режима
        </a>
    </div>
    <?php
    if (isset($_SESSION['flash'])) {
        echo '<div class="alert alert-success alert-dismissible fade show" role="alert">' . htmlspecialchars($_SESSION['flash']) . '<button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>';
        unset($_SESSION['flash']);
    }
    renderUserManagementInterface($pdo, $page, $limit, $offset, $search, $action, $id);
    include 'templates/footer.php';
    ?>
    <?php
}
?>
```

## File: work/admin/setup_db.php
```php
<?php
session_start();
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    die('Доступ запрещён. Только для администратора.');
}
require_once '../config.php';

$message = '';
$error = '';

// Если нажата кнопка «Установить БД»
if (isset($_POST['install'])) {
    try {
        // Сначала удаляем существующие таблицы (если есть)
        $tables = [
            'order_items', 'orders', 'production_norms', 'materials', 'products', 'customers', 'users', 'tasks', 'login_attempts', 'logs'
        ];
        foreach ($tables as $table) {
            $pdo->exec("DROP TABLE IF EXISTS `$table`");
        }

        // Создаём таблицы заново
        $pdo->exec("
            CREATE TABLE IF NOT EXISTS `users` (
                `id` int(11) NOT NULL AUTO_INCREMENT,
                `login` varchar(50) NOT NULL,
                `password_hash` varchar(255) NOT NULL,
                `full_name` varchar(100) DEFAULT NULL,
                `blocked` tinyint(1) DEFAULT 0,
                `role` enum('user','admin') DEFAULT 'user',
                PRIMARY KEY (`id`),
                UNIQUE KEY `login` (`login`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

            CREATE TABLE IF NOT EXISTS `tasks` (
                `id` int(11) NOT NULL AUTO_INCREMENT,
                `user_id` int(11) DEFAULT NULL,
                `text` text NOT NULL,
                `done` tinyint(1) DEFAULT 0,
                `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (`id`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

            CREATE TABLE IF NOT EXISTS `customers` (
                `id` varchar(20) NOT NULL,
                `name` varchar(255) NOT NULL,
                `inn` varchar(20) DEFAULT NULL,
                `address` varchar(255) DEFAULT NULL,
                `phone` varchar(20) DEFAULT NULL,
                `salesman` tinyint(1) DEFAULT 0,
                `buyer` tinyint(1) DEFAULT 0,
                PRIMARY KEY (`id`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

            CREATE TABLE IF NOT EXISTS `products` (
                `id` int(11) NOT NULL AUTO_INCREMENT,
                `name` varchar(255) NOT NULL,
                `code` varchar(50) DEFAULT NULL,
                `price` decimal(10,2) NOT NULL,
                `unit` varchar(20) DEFAULT 'шт',
                PRIMARY KEY (`id`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

            CREATE TABLE IF NOT EXISTS `orders` (
                `id` int(11) NOT NULL AUTO_INCREMENT,
                `customer_id` varchar(20) DEFAULT NULL,
                `order_date` date DEFAULT NULL,
                `total_amount` decimal(10,2) DEFAULT '0.00',
                PRIMARY KEY (`id`),
                KEY `customer_id` (`customer_id`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

            CREATE TABLE IF NOT EXISTS `order_items` (
                `id` int(11) NOT NULL AUTO_INCREMENT,
                `order_id` int(11) DEFAULT NULL,
                `product_id` int(11) DEFAULT NULL,
                `quantity` decimal(10,2) NOT NULL,
                `price` decimal(10,2) NOT NULL,
                PRIMARY KEY (`id`),
                KEY `order_id` (`order_id`),
                KEY `product_id` (`product_id`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

            CREATE TABLE IF NOT EXISTS `materials` (
                `id` int(11) NOT NULL AUTO_INCREMENT,
                `name` varchar(255) NOT NULL,
                `code` varchar(50) DEFAULT NULL,
                `price` decimal(10,2) NOT NULL,
                `unit` varchar(20) DEFAULT 'кг',
                PRIMARY KEY (`id`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

            CREATE TABLE IF NOT EXISTS `production_norms` (
                `id` int(11) NOT NULL AUTO_INCREMENT,
                `product_id` int(11) DEFAULT NULL,
                `material_id` int(11) DEFAULT NULL,
                `quantity_per_unit` decimal(10,4) NOT NULL,
                PRIMARY KEY (`id`),
                KEY `product_id` (`product_id`),
                KEY `material_id` (`material_id`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        ");

        // Импорт из Заказчики.json
        $jsonFile = realpath(__DIR__ . '/../Заказчики.json');
        if (file_exists($jsonFile)) {
            $json = file_get_contents($jsonFile);
            $data = json_decode($json, true);
            $stmt = $pdo->prepare("INSERT IGNORE INTO customers (id, name, inn, address, phone, salesman, buyer) VALUES (:id, :name, :inn, :address, :phone, :salesman, :buyer)");
            foreach ($data as $row) {
                $stmt->execute([
                    ':id' => $row['id'],
                    ':name' => $row['name'],
                    ':inn' => $row['inn'],
                    ':address' => $row['addres'],
                    ':phone' => $row['phone'],
                    ':salesman' => (int)$row['salesman'],
                    ':buyer' => (int)$row['buyer']
                ]);
            }
            $message .= "✅ Данные из Заказчики.json импортированы.<br>";
        } else {
            $message .= "⚠️ Файл Заказчики.json не найден. Пропускаем импорт.<br>";
        }

        // Добавляем тестовые товары, материалы, нормы, заказы
        $pdo->exec("
            INSERT IGNORE INTO products (id, name, code, price, unit) VALUES
            (1, 'Кефир 2,5% 900г', 'KEF-001', 80.00, 'шт'),
            (2, 'Кефир 3,2% 900г', 'KEF-002', 82.00, 'шт'),
            (3, 'Молоко 2,5% 900г', 'MOL-001', 70.00, 'шт'),
            (4, 'Сметана классическая 15% 540г', 'SME-001', 89.00, 'шт');

            INSERT IGNORE INTO materials (id, name, code, price, unit) VALUES
            (1, 'Молоко нормализованное', 'MAT-001', 34.00, 'кг'),
            (2, 'Закваска сметанная', 'MAT-002', 45.00, 'кг');

            INSERT IGNORE INTO production_norms (id, product_id, material_id, quantity_per_unit) VALUES
            (1, 4, 1, 0.9000),
            (2, 4, 2, 0.0700);

            INSERT IGNORE INTO orders (id, customer_id, order_date, total_amount) VALUES
            (1, '000000010', '2025-06-06', 2488.00);

            INSERT IGNORE INTO order_items (id, order_id, product_id, quantity, price) VALUES
            (1, 1, 1, 12.00, 80.00),
            (2, 1, 2, 9.00, 82.00),
            (3, 1, 3, 10.00, 79.00);
        ");
        $message .= "✅ Тестовые данные добавлены.<br>";

        // Создаём администратора, если его нет
        $hash = password_hash('12345', PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("SELECT id FROM users WHERE login = 'admin'");
        $stmt->execute();
        if (!$stmt->fetch()) {
            $pdo->exec("INSERT INTO users (login, password_hash, full_name, blocked, role) VALUES ('admin', '$hash', 'Администратор', 0, 'admin')");
            $message .= "✅ Администратор создан.<br>";
        } else {
            $message .= "ℹ️ Администратор уже существует.<br>";
        }

        $message .= "<br><strong>✅ Установка завершена!</strong>";

    } catch (PDOException $e) {
        $error = "❌ Ошибка: " . $e->getMessage();
    }
}

include '../templates/header.php';
?>
<div class="container mt-4">
    <h2>Установка базы данных</h2>
    <p>Нажмите кнопку ниже, чтобы <strong>пересоздать базу данных</strong> (удалить все таблицы, создать заново и импортировать данные из <code>Заказчики.json</code>).</p>

    <?php if ($error): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>
    <?php if ($message): ?>
        <div class="alert alert-success"><?= $message ?></div>
    <?php endif; ?>

    <form method="post">
        <button type="submit" name="install" class="btn btn-danger" onclick="return confirm('Внимание! Это действие удалит все таблицы и создаст их заново. Продолжить?')">
            <i class="fas fa-database me-2"></i> Установить базу данных
        </button>
        <a href="index.php" class="btn btn-secondary">Назад в админку</a>
    </form>
</div>
<?php include '../templates/footer.php'; ?>
```

## File: work/modules/api_client.php
```php
<?php
require_once '../config.php';
require_once '../functions.php';

$fullName = '';
$resultMessage = '';

/**
 * Валидация ФИО клиента
 * @param string $name
 * @return array ['isValid' => bool, 'error' => string]
 */
function validateFullName($name) {
    // 1. Не пусто
    if (empty(trim($name))) {
        return ['isValid' => false, 'error' => 'ФИО не должно быть пустым'];
    }
    // 2. Проверка на запрещённые символы (из задания)
    $forbiddenChars = ['&', '!', '@', '#', '$', '%', '^', '*', '(', ')', '+', '=', '~', '`', '/', '\\', '|', '<', '>', '?'];
    foreach ($forbiddenChars as $char) {
        if (strpos($name, $char) !== false) {
            return ['isValid' => false, 'error' => "ФИО содержит запрещённый символ '$char'"];
        }
    }
    // 3. Проверка на цифры (в ФИО не должно быть цифр)
    if (preg_match('/\d/', $name)) {
        return ['isValid' => false, 'error' => 'ФИО не должно содержать цифр'];
    }
    // 4. Минимальная и максимальная длина (3–100 символов)
    $len = mb_strlen(trim($name), 'UTF-8');
    if ($len < 3 || $len > 100) {
        return ['isValid' => false, 'error' => 'ФИО должно содержать от 3 до 100 символов'];
    }
    // 5. Разрешённые символы (буквы, пробелы, тире, точка, апостроф)
    if (!preg_match('/^[\p{L}\s\-\'\.]+$/u', $name)) {
        return ['isValid' => false, 'error' => 'ФИО может содержать только буквы, пробелы, тире, точки и апострофы'];
    }
    return ['isValid' => true, 'error' => ''];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // 1. Получить данные с эмулятора
    if (isset($_POST['get_data'])) {
        $url = 'http://localhost:4444/TransferSimulator/fullName';
        $response = @file_get_contents($url);
        if ($response === false) {
            $resultMessage = '❌ Ошибка: эмулятор недоступен. Проверьте запуск TransferSimulator.';
        } else {
            $data = json_decode($response, true);
            $fullName = $data['value'] ?? '';
            $resultMessage = 'Данные получены: ' . htmlspecialchars($fullName);
        }
    }

    // 2. Отправить результат теста (валидация + запись в CSV)
    elseif (isset($_POST['submit_test'])) {
        $fullName = $_POST['full_name'] ?? '';
        
        // Вызываем расширенную валидацию
        $validation = validateFullName($fullName);
        
        if ($validation['isValid']) {
            $status = 'Успешно';
            $resultMessage = '✅ Валидация пройдена';
        } else {
            $status = 'Не успешно';
            $resultMessage = '❌ ' . $validation['error'];
        }
        $resultMessage .= '<br>ФИО: ' . htmlspecialchars($fullName);

        // Запись в testcase.csv
        $file = '../testcase.csv';
        $fp = fopen($file, 'a');
        fputcsv($fp, [date('Y-m-d H:i:s'), $fullName, $status]);
        fclose($fp);
        $resultMessage .= '<br>✅ Результат записан в testcase.csv (аналог ТестКейс.docx)';
    }
}

include '../templates/header.php';
?>
<div class="container mt-4">
    <h2>Валидация данных клиента</h2>
    <div class="card">
        <div class="card-body">
            <form method="post">
                <div class="row">
                    <div class="col-md-6">
                        <button type="submit" name="get_data" class="btn btn-info w-100">Получить данные</button>
                    </div>
                    <div class="col-md-6">
                        <button type="submit" name="submit_test" class="btn btn-primary w-100">Отправить результат теста</button>
                    </div>
                </div>
                <div class="form-group mt-3">
                    <label for="full_name">ФИО клиента</label>
                    <input type="text" class="form-control" id="full_name" name="full_name" value="<?= htmlspecialchars($fullName ?? '') ?>" readonly>
                </div>
                <?php if ($resultMessage): ?>
                    <div class="mt-3 alert alert-info"><?= $resultMessage ?></div>
                <?php endif; ?>
            </form>
        </div>
    </div>
    <a href="../index.php" class="btn btn-secondary mt-3">← Назад</a>
</div>
<?php include '../templates/footer.php'; ?>
```

## File: work/modules/api_emulator.php
```php
<?php
// modules/api_emulator.php
header('Content-Type: application/json');

// Массив случайных ФИО
$names = [
    'Иванов Иван Иванович',
    'Петров Петр Петрович',
    'Сидоров Сидор Сидорович',
    'Кузнецова Анна Сергеевна',
    'Соколов& Сокол& Соколович', // содержит запрещённый символ &
    'Смирнова Екатерина Дмитриевна',
    'Васильев! Василий! Васильевич', // содержит запрещённый символ !
    'Попов Александр Владимирович',
    'Морозова@ Ольга@ Ивановна', // содержит запрещённый символ @
    'Козлов Денис Андреевич'
];

// Выбираем случайное имя
$randomName = $names[array_rand($names)];

// Возвращаем JSON
echo json_encode(['value' => $randomName]);
?>
```

## File: work/modules/calc_order.php
```php
<?php
require_once '../config.php';
require_once '../functions.php';

// Получаем ID заказа из URL (если нет — по умолчанию 1)
$orderId = isset($_GET['id']) ? (int)$_GET['id'] : 1;

// --- 1. Считаем стоимость материалов по нормам расхода ---
$sql = "
    SELECT 
        oi.order_id,
        SUM(oi.quantity * pn.quantity_per_unit * m.price) AS total_material_cost
    FROM order_items oi
    JOIN production_norms pn ON oi.product_id = pn.product_id
    JOIN materials m ON pn.material_id = m.id
    WHERE oi.order_id = ?
    GROUP BY oi.order_id;
";
$stmt = $pdo->prepare($sql);
$stmt->execute([$orderId]);
$materialCost = $stmt->fetchColumn();
if ($materialCost === false) {
    $materialCost = 0;
}

// --- 2. Считаем стоимость самой продукции ---
$sql2 = "
    SELECT 
        SUM(oi.quantity * oi.price) AS total_product_cost
    FROM order_items oi
    WHERE oi.order_id = ?
";
$stmt2 = $pdo->prepare($sql2);
$stmt2->execute([$orderId]);
$productCost = $stmt2->fetchColumn();
if ($productCost === false) {
    $productCost = 0;
}

// --- 3. Общая стоимость ---
$totalCost = $productCost + $materialCost;

// --- 4. Получаем список позиций заказа для детализации ---
$sqlItems = "
    SELECT 
        oi.id,
        p.name AS product_name,
        oi.quantity,
        oi.price AS product_price,
        pn.quantity_per_unit,
        m.name AS material_name,
        m.price AS material_price,
        (pn.quantity_per_unit * m.price) AS material_cost_per_unit
    FROM order_items oi
    JOIN products p ON oi.product_id = p.id
    LEFT JOIN production_norms pn ON oi.product_id = pn.product_id
    LEFT JOIN materials m ON pn.material_id = m.id
    WHERE oi.order_id = ?
    ORDER BY oi.id
";
$stmtItems = $pdo->prepare($sqlItems);
$stmtItems->execute([$orderId]);
$items = $stmtItems->fetchAll(PDO::FETCH_ASSOC);

include '../templates/header.php';
?>
<div class="container mt-4">
    <h2>Расчёт стоимости заказа №<?= $orderId ?></h2>

    <!-- Кнопка выбора заказа -->
    <div class="mb-3">
        <form method="get" class="row g-2">
            <div class="col-auto">
                <label for="orderId" class="visually-hidden">ID заказа</label>
                <input type="number" id="orderId" name="id" class="form-control" value="<?= $orderId ?>" min="1">
            </div>
            <div class="col-auto">
                <button type="submit" class="btn btn-primary">Пересчитать</button>
            </div>
        </form>
    </div>

    <!-- Результат -->
    <div class="card mb-4">
        <div class="card-header bg-success text-white">
            Итоговая стоимость
        </div>
        <div class="card-body">
            <p><strong>Стоимость продукции:</strong> <?= number_format($productCost, 2) ?> руб.</p>
            <p><strong>Стоимость материалов:</strong> <?= number_format($materialCost, 2) ?> руб.</p>
            <p><strong>Общая стоимость заказа:</strong> <?= number_format($totalCost, 2) ?> руб.</p>
        </div>
    </div>

    <!-- Детализация по позициям -->
    <?php if ($items): ?>
        <h3>Детализация</h3>
        <div class="table-responsive">
            <table class="table table-bordered table-hover">
                <thead class="table-light">
                    <tr>
                        <th>Продукция</th>
                        <th>Кол-во</th>
                        <th>Цена за шт.</th>
                        <th>Материал</th>
                        <th>Норма расхода</th>
                        <th>Цена материала</th>
                        <th>Стоимость материалов</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($items as $item): ?>
                        <tr>
                            <td><?= htmlspecialchars($item['product_name']) ?></td>
                            <td><?= $item['quantity'] ?></td>
                            <td><?= number_format($item['product_price'], 2) ?></td>
                            <td><?= htmlspecialchars($item['material_name'] ?? '—') ?></td>
                            <td><?= $item['quantity_per_unit'] ?? '—' ?></td>
                            <td><?= isset($item['material_price']) ? number_format($item['material_price'], 2) : '—' ?></td>
                            <td><?= isset($item['material_cost_per_unit']) ? number_format($item['material_cost_per_unit'] * $item['quantity'], 2) : '0.00' ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php else: ?>
        <div class="alert alert-warning">В этом заказе нет позиций.</div>
    <?php endif; ?>

    <a href="../index.php" class="btn btn-secondary mt-3">← Назад</a>
</div>
<?php include '../templates/footer.php'; ?>
```

## File: work/modules/profile.php
```php
<?php
session_start();
require_once '../config.php';
require_once '../functions.php';

if (!isset($_SESSION['user'])) {
    header('Location: ../login.php');
    exit;
}

$user = $_SESSION['user'];
$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'update_profile') {
        $full_name = trim($_POST['full_name'] ?? '');
        $stmt = $pdo->prepare("UPDATE users SET full_name = ? WHERE id = ?");
        $stmt->execute([$full_name, $user['id']]);
        $_SESSION['user']['full_name'] = $full_name;
        $message = '✅ Имя обновлено.';
    } elseif ($action === 'change_password') {
        $current = $_POST['current_password'] ?? '';
        $new = $_POST['new_password'] ?? '';
        $confirm = $_POST['confirm_password'] ?? '';

        if (!password_verify($current, $user['password_hash'])) {
            $error = '❌ Неверный текущий пароль.';
        } elseif (strlen($new) < 6) {
            $error = '❌ Новый пароль не менее 6 символов.';
        } elseif ($new !== $confirm) {
            $error = '❌ Пароли не совпадают.';
        } else {
            $hash = password_hash($new, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("UPDATE users SET password_hash = ? WHERE id = ?");
            $stmt->execute([$hash, $user['id']]);
            $_SESSION['user']['password_hash'] = $hash;
            $message = '✅ Пароль изменён.';
        }
    }
}

include '../templates/header.php';
?>
<div class="container mt-4">
    <h2>Профиль пользователя</h2>
    <?php if ($message): ?>
        <div class="alert alert-success"><?= $message ?></div>
    <?php endif; ?>
    <?php if ($error): ?>
        <div class="alert alert-danger"><?= $error ?></div>
    <?php endif; ?>

    <div class="card mb-4">
        <div class="card-header">Изменить имя</div>
        <div class="card-body">
            <form method="post">
                <input type="hidden" name="action" value="update_profile">
                <div class="mb-3">
                    <label>Полное имя</label>
                    <input type="text" name="full_name" class="form-control" value="<?= htmlspecialchars($user['full_name'] ?? '') ?>">
                </div>
                <button type="submit" class="btn btn-primary">Сохранить</button>
            </form>
        </div>
    </div>

    <div class="card">
        <div class="card-header">Сменить пароль</div>
        <div class="card-body">
            <form method="post">
                <input type="hidden" name="action" value="change_password">
                <div class="mb-3">
                    <label>Текущий пароль</label>
                    <input type="password" name="current_password" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label>Новый пароль</label>
                    <input type="password" name="new_password" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label>Подтверждение нового пароля</label>
                    <input type="password" name="confirm_password" class="form-control" required>
                </div>
                <button type="submit" class="btn btn-primary">Сменить пароль</button>
            </form>
        </div>
    </div>

    <a href="../index.php" class="btn btn-secondary mt-3">← Назад</a>
</div>
<?php include '../templates/footer.php'; ?>
```

## File: work/modules/todo.php
```php
<?php
require_once '../config.php';
require_once '../functions.php';

$file = '../tasks.json';
$tasks = file_exists($file) ? json_decode(file_get_contents($file), true) : [];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add'])) {
    $task = trim($_POST['task']);
    if (!empty($task)) {
        $tasks[] = ['id' => time(), 'text' => $task, 'done' => false];
        file_put_contents($file, json_encode($tasks));
    }
    header('Location: ?page=todo');
    exit;
}

if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $tasks = array_filter($tasks, fn($t) => $t['id'] !== $id);
    file_put_contents($file, json_encode(array_values($tasks)));
    header('Location: ?page=todo');
    exit;
}

if (isset($_GET['toggle'])) {
    $id = (int)$_GET['toggle'];
    foreach ($tasks as &$t) {
        if ($t['id'] === $id) { $t['done'] = !$t['done']; break; }
    }
    file_put_contents($file, json_encode($tasks));
    header('Location: ?page=todo');
    exit;
}

include '../templates/header.php';
?>
<div class="container mt-4">
    <h2>Список задач</h2>
    <form method="post" class="mb-3">
        <div class="input-group">
            <input type="text" name="task" class="form-control" placeholder="Новая задача" required>
            <button type="submit" name="add" class="btn btn-primary">Добавить</button>
        </div>
    </form>
    <ul class="list-group">
        <?php foreach ($tasks as $t): ?>
            <li class="list-group-item d-flex justify-content-between align-items-center" style="<?= $t['done'] ? 'text-decoration:line-through; opacity:0.7' : '' ?>">
                <?= htmlspecialchars($t['text']) ?>
                <div>
                    <a href="?page=todo&toggle=<?= $t['id'] ?>" class="btn btn-sm btn-success">✓</a>
                    <a href="?page=todo&delete=<?= $t['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Удалить?')">✗</a>
                </div>
            </li>
        <?php endforeach; ?>
    </ul>
    <a href="../index.php" class="btn btn-secondary mt-3">← Назад</a>
</div>
<?php include '../templates/footer.php'; ?>
```

## File: work/modules/upload.php
```php
<?php
require_once '../config.php';
require_once '../functions.php';

$message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['image'])) {
    $file = $_FILES['image'];
    $allowed = ['image/jpeg', 'image/png'];
    if ($file['error'] !== UPLOAD_ERR_OK) {
        $message = 'Ошибка загрузки';
    } elseif (!in_array($file['type'], $allowed)) {
        $message = 'Разрешены только JPG и PNG';
    } elseif ($file['size'] > 2 * 1024 * 1024) {
        $message = 'Файл не более 2 Мб';
    } else {
        $ext = pathinfo($file['name'], PATHINFO_EXTENSION);
        $newName = time() . '.' . $ext;
        if (!is_dir('../uploads')) mkdir('../uploads', 0777, true);
        if (move_uploaded_file($file['tmp_name'], '../uploads/' . $newName)) {
            $message = 'Файл загружен: ' . $newName;
            $uploaded = $newName;
        } else {
            $message = 'Не удалось сохранить файл';
        }
    }
}

include '../templates/header.php';
?>
<div class="container mt-4">
    <h2>Загрузка изображения</h2>
    <?php if ($message): ?><div class="alert alert-info"><?= $message ?></div><?php endif; ?>
    <form method="post" enctype="multipart/form-data">
        <input type="file" name="image" accept="image/jpeg,image/png" required>
        <button type="submit" class="btn btn-primary">Загрузить</button>
    </form>
    <?php if (isset($uploaded)): ?>
        <p><img src="../uploads/<?= $uploaded ?>" width="200" class="mt-3"></p>
    <?php endif; ?>
    <a href="../index.php" class="btn btn-secondary mt-3">← Назад</a>
</div>
<?php include '../templates/footer.php'; ?>
```

## File: work/templates/footer.php
```php
</div> <!-- конец container -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
```

## File: work/templates/header.php
```php
<?php if (session_status() === PHP_SESSION_NONE) session_start(); ?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ООО Молочный комбинат "Полесье" — Демо-экзамен</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        body { background: #f0f2f5; }
        .navbar-brand { font-weight: bold; }
        .card { border-radius: 1rem; box-shadow: 0 0.5rem 1rem rgba(0,0,0,0.05); }
        .action-icons a { margin: 0 4px; text-decoration: none; }
        .puzzle-slot, .puzzle-piece { box-sizing: border-box; }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-primary mb-4">
    <div class="container">
        <a class="navbar-brand" href="index.php"><i class="fas fa-home me-2"></i>ООО "Полесье" — ДЭ</a>
        <span class="navbar-text text-white-50">
            <?php if (isset($_SESSION['user'])): ?>
                <i class="fas fa-user me-1"></i><?= htmlspecialchars($_SESSION['user']['login']) ?>
            <?php else: ?>
                Гость
            <?php endif; ?>
        </span>
    </div>
</nav>
<div class="container">
```

## File: work/ ª §ç¨ª¨.json
```json
[
	{
		"id": "000000001",
		"name": "ООО \"Поставка\"",
		"inn": "",
		"addres": "г.Пятигорск",
		"phone": "+79198634592",
		"salesman": true,
		"buyer": true
	},
	{
		"id": "000000002",
		"name": "ООО \"Кинотеатр Квант\"",
		"inn": "26320045123",
		"addres": "г. Железноводск, ул. Мира, 123",
		"phone": "+79884581555",
		"salesman": true,
		"buyer": false
	},
	{
		"id": "000000008",
		"name": "ООО \"Новый JDTO\"",
		"inn": "26320045111",
		"addres": "г. Железноводсу",
		"phone": "+79884581555",
		"salesman": true,
		"buyer": false
	},
	{
		"id": "000000003",
		"name": "ООО \"Ромашка\"",
		"inn": "4140784214",
		"addres": "г. Омск, ул. Строителей, 294",
		"phone": "+79882584546",
		"salesman": false,
		"buyer": true
	},
	{
		"id": "000000009",
		"name": "ООО \"Ипподром\"",
		"inn": "5874045632",
		"addres": "г. Уфа, ул. Набережная,  37",
		"phone": "+79627486389",
		"salesman": true,
		"buyer": true
	},
	{
		"id": "000000010",
		"name": "ООО \"Ассоль\"",
		"inn": "2629011278",
		"addres": "г. Калуга, ул. Пушкина, 94",
		"phone": "+79184572398",
		"salesman": false,
		"buyer": true
	}
]
```

## File: work/config.php
```php
<?php
$host = 'localhost';
$user = 'root';
$pass = 'root'; // ваш пароль
$db_name = 'work_auth';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db_name;charset=utf8mb4", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Ошибка подключения: " . $e->getMessage());
}

// Константы для эмулятора
define('API_URL', 'http://localhost:4444/TransferSimulator/fullName');
?>
```

## File: work/db_setup.php
```php
<?php
$host = 'localhost';
$user = 'root';
$pass = 'root';
$db_name = 'work_auth';

try {
    $pdo = new PDO("mysql:host=$host;charset=utf8mb4", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $pdo->exec("CREATE DATABASE IF NOT EXISTS `$db_name` CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci");
    $pdo->exec("USE `$db_name`");

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS `users` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `login` varchar(50) NOT NULL,
            `password_hash` varchar(255) NOT NULL,
            `full_name` varchar(100) DEFAULT NULL,
            `blocked` tinyint(1) DEFAULT 0,
            `role` enum('user','admin') DEFAULT 'user',
            PRIMARY KEY (`id`),
            UNIQUE KEY `login` (`login`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

        CREATE TABLE IF NOT EXISTS `tasks` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `user_id` int(11) DEFAULT NULL,
            `text` text NOT NULL,
            `done` tinyint(1) DEFAULT 0,
            `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

        CREATE TABLE IF NOT EXISTS `customers` (
            `id` varchar(20) NOT NULL,
            `name` varchar(255) NOT NULL,
            `inn` varchar(20) DEFAULT NULL,
            `address` varchar(255) DEFAULT NULL,
            `phone` varchar(20) DEFAULT NULL,
            `salesman` tinyint(1) DEFAULT 0,
            `buyer` tinyint(1) DEFAULT 0,
            PRIMARY KEY (`id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

        CREATE TABLE IF NOT EXISTS `products` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `name` varchar(255) NOT NULL,
            `code` varchar(50) DEFAULT NULL,
            `price` decimal(10,2) NOT NULL,
            `unit` varchar(20) DEFAULT 'шт',
            PRIMARY KEY (`id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

        CREATE TABLE IF NOT EXISTS `orders` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `customer_id` varchar(20) DEFAULT NULL,
            `order_date` date DEFAULT NULL,
            `total_amount` decimal(10,2) DEFAULT '0.00',
            PRIMARY KEY (`id`),
            KEY `customer_id` (`customer_id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

        CREATE TABLE IF NOT EXISTS `order_items` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `order_id` int(11) DEFAULT NULL,
            `product_id` int(11) DEFAULT NULL,
            `quantity` decimal(10,2) NOT NULL,
            `price` decimal(10,2) NOT NULL,
            PRIMARY KEY (`id`),
            KEY `order_id` (`order_id`),
            KEY `product_id` (`product_id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

        CREATE TABLE IF NOT EXISTS `materials` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `name` varchar(255) NOT NULL,
            `code` varchar(50) DEFAULT NULL,
            `price` decimal(10,2) NOT NULL,
            `unit` varchar(20) DEFAULT 'кг',
            PRIMARY KEY (`id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

        CREATE TABLE IF NOT EXISTS `production_norms` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `product_id` int(11) DEFAULT NULL,
            `material_id` int(11) DEFAULT NULL,
            `quantity_per_unit` decimal(10,4) NOT NULL,
            PRIMARY KEY (`id`),
            KEY `product_id` (`product_id`),
            KEY `material_id` (`material_id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

        CREATE TABLE IF NOT EXISTS `login_attempts` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `ip` varchar(45) NOT NULL,
            `attempt_time` datetime NOT NULL,
            PRIMARY KEY (`id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

        CREATE TABLE IF NOT EXISTS `logs` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `user_id` int(11) DEFAULT NULL,
            `action` varchar(255) NOT NULL,
            `ip` varchar(45) DEFAULT NULL,
            `created_at` datetime NOT NULL,
            PRIMARY KEY (`id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    ");

    $hash = password_hash('12345', PASSWORD_DEFAULT);
    $stmt = $pdo->prepare("SELECT id FROM users WHERE login = 'admin'");
    $stmt->execute();
    if (!$stmt->fetch()) {
        $pdo->exec("INSERT INTO users (login, password_hash, full_name, blocked, role) VALUES ('admin', '$hash', 'Администратор', 0, 'admin')");
        echo "✅ Администратор (admin / 12345) создан.<br>";
    } else {
        echo "ℹ️ Администратор уже существует.<br>";
    }

    if (file_exists('Заказчики.json')) {
        $json = file_get_contents('Заказчики.json');
        $data = json_decode($json, true);
        $stmt = $pdo->prepare("INSERT IGNORE INTO customers (id, name, inn, address, phone, salesman, buyer) VALUES (:id, :name, :inn, :address, :phone, :salesman, :buyer)");
        foreach ($data as $row) {
            $stmt->execute([
                ':id' => $row['id'],
                ':name' => $row['name'],
                ':inn' => $row['inn'],
                ':address' => $row['addres'],
                ':phone' => $row['phone'],
                ':salesman' => (int)$row['salesman'],
                ':buyer' => (int)$row['buyer']
            ]);
        }
        echo "✅ Данные из Заказчики.json импортированы.<br>";
    } else {
        echo "ℹ️ Файл Заказчики.json не найден. Пропускаем импорт.<br>";
    }

    $pdo->exec("
        INSERT IGNORE INTO products (id, name, code, price, unit) VALUES
        (1, 'Кефир 2,5% 900г', 'KEF-001', 80.00, 'шт'),
        (2, 'Кефир 3,2% 900г', 'KEF-002', 82.00, 'шт'),
        (3, 'Молоко 2,5% 900г', 'MOL-001', 70.00, 'шт'),
        (4, 'Сметана классическая 15% 540г', 'SME-001', 89.00, 'шт');
    ");
    echo "✅ Тестовые товары добавлены.<br>";

    $pdo->exec("
        INSERT IGNORE INTO materials (id, name, code, price, unit) VALUES
        (1, 'Молоко нормализованное', 'MAT-001', 34.00, 'кг'),
        (2, 'Закваска сметанная', 'MAT-002', 45.00, 'кг');
    ");
    echo "✅ Материалы добавлены.<br>";

    $pdo->exec("
        INSERT IGNORE INTO production_norms (id, product_id, material_id, quantity_per_unit) VALUES
        (1, 4, 1, 0.9000),
        (2, 4, 2, 0.0700);
    ");
    echo "✅ Нормы расхода добавлены.<br>";

    $pdo->exec("
        INSERT IGNORE INTO orders (id, customer_id, order_date, total_amount) VALUES
        (1, '000000010', '2025-06-06', 2488.00);
    ");
    $pdo->exec("
        INSERT IGNORE INTO order_items (id, order_id, product_id, quantity, price) VALUES
        (1, 1, 1, 12.00, 80.00),
        (2, 1, 2, 9.00, 82.00),
        (3, 1, 3, 10.00, 79.00);
    ");
    echo "✅ Тестовый заказ добавлен.<br>";

    echo "<br><strong>✅ Установка завершена!</strong><br>";
    echo "<a href='login.php'>→ Перейти к входу</a>";

} catch (PDOException $e) {
    die("❌ Ошибка: " . $e->getMessage());
}
?>
```

## File: work/fix_db.php
```php
<?php
require_once 'config.php';

try {
    // Проверяем, есть ли уже этот столбец
    $stmt = $pdo->prepare("SHOW COLUMNS FROM users LIKE 'failed_attempts'");
    $stmt->execute();
    $columnExists = $stmt->fetch();

    if (!$columnExists) {
        $pdo->exec("ALTER TABLE users ADD COLUMN failed_attempts INT DEFAULT 0");
        echo "✅ Столбец 'failed_attempts' успешно добавлен в таблицу users.<br>";
        echo "Теперь вход должен работать.<br>";
        echo "<a href='login.php'>→ Перейти к входу</a>";
    } else {
        echo "ℹ️ Столбец 'failed_attempts' уже существует. Ошибка исчезнет.<br>";
        echo "<a href='login.php'>→ Перейти к входу</a>";
    }
} catch (PDOException $e) {
    die("❌ Ошибка: " . $e->getMessage());
}
?>
```

## File: work/functions.php
```php
<?php
require_once 'config.php';

// --- БД (CRUD) ---
function getTables($pdo) {
    return $pdo->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
}

function getColumnsInfo($pdo, $table) {
    $stmt = $pdo->prepare("DESCRIBE `$table`");
    $stmt->execute();
    $cols = [];
    $pk = null;
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $type = $row['Type'];
        $enum = [];
        if (preg_match('/^enum\((.*)\)$/i', $type, $matches)) {
            $enum = str_getcsv($matches[1], ',', "'");
        }
        $cols[] = [
            'name' => $row['Field'],
            'type' => $type,
            'null' => $row['Null'] === 'YES',
            'key' => $row['Key'],
            'default' => $row['Default'],
            'enum' => $enum
        ];
        if ($row['Key'] === 'PRI') $pk = $row['Field'];
    }
    return [$cols, $pk];
}

function getForeignKeys($pdo, $table) {
    $sql = "SELECT COLUMN_NAME, REFERENCED_TABLE_NAME, REFERENCED_COLUMN_NAME 
            FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE 
            WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND REFERENCED_TABLE_NAME IS NOT NULL";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$GLOBALS['db_name'], $table]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function getDisplayValue($pdo, $table, $id, $keyColumn) {
    if (!$id) return '';
    $displayCol = $keyColumn;
    $stmt = $pdo->prepare("DESCRIBE `$table`");
    $stmt->execute();
    $cols = $stmt->fetchAll(PDO::FETCH_ASSOC);
    foreach ($cols as $col) {
        $name = $col['Field'];
        if (in_array($name, ['name', 'title', 'full_name', 'login', 'company_name', 'description'])) {
            $displayCol = $name;
            break;
        }
    }
    $stmt2 = $pdo->prepare("SELECT `$displayCol` FROM `$table` WHERE `$keyColumn` = ?");
    $stmt2->execute([$id]);
    $row = $stmt2->fetch(PDO::FETCH_ASSOC);
    return $row ? $row[$displayCol] : $id;
}

function getAllRows($pdo, $table) {
    return $pdo->query("SELECT * FROM `$table`")->fetchAll(PDO::FETCH_ASSOC);
}

function getRowData($pdo, $table, $id, $pk) {
    $stmt = $pdo->prepare("SELECT * FROM `$table` WHERE `$pk` = ?");
    $stmt->execute([$id]);
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

// --- Авторизация ---
function getUserByLogin($pdo, $login) {
    $stmt = $pdo->prepare("SELECT * FROM users WHERE login = ?");
    $stmt->execute([$login]);
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

/**
 * Проверка логина и пароля.
 * При неудачной попытке увеличивает счётчик failed_attempts.
 * Если достигнуто 3 неудачных попытки — блокирует пользователя.
 */
function checkLogin($pdo, $login, $password) {
    $user = getUserByLogin($pdo, $login);
    if (!$user) {
        return false;
    }
    // Если пользователь уже заблокирован
    if ($user['blocked'] == 1) {
        return $user; // возвращаем пользователя, но с блокировкой
    }
    // Проверка пароля
    if (password_verify($password, $user['password_hash'])) {
        // Сбрасываем счетчик неудачных попыток при успехе
        $stmt = $pdo->prepare("UPDATE users SET failed_attempts = 0 WHERE id = ?");
        $stmt->execute([$user['id']]);
        return $user;
    } else {
        // Увеличиваем счетчик неудачных попыток
        $newAttempts = ($user['failed_attempts'] ?? 0) + 1;
        $stmt = $pdo->prepare("UPDATE users SET failed_attempts = ? WHERE id = ?");
        $stmt->execute([$newAttempts, $user['id']]);
        // Если 3 неудачные попытки — блокируем
        if ($newAttempts >= 3) {
            $stmt = $pdo->prepare("UPDATE users SET blocked = 1 WHERE id = ?");
            $stmt->execute([$user['id']]);
        }
        return false;
    }
}

function createUser($pdo, $login, $password, $full_name) {
    $hash = password_hash($password, PASSWORD_DEFAULT);
    $stmt = $pdo->prepare("INSERT INTO users (login, password_hash, full_name, blocked, role) VALUES (?, ?, ?, 0, 'user')");
    return $stmt->execute([$login, $hash, $full_name]);
}

function setUserBlocked($pdo, $id, $blocked) {
    $stmt = $pdo->prepare("UPDATE users SET blocked = ? WHERE id = ?");
    return $stmt->execute([$blocked ? 1 : 0, $id]);
}

function getAllUsers($pdo) {
    return $pdo->query("SELECT id, login, full_name, role, blocked FROM users ORDER BY id")->fetchAll(PDO::FETCH_ASSOC);
}

// --- Расчёт заказа (с учётом материалов) ---
function getOrderTotal($pdo, $orderId) {
    $sql = "SELECT 
                SUM(oi.quantity * oi.price) AS total_products
            FROM order_items oi
            WHERE oi.order_id = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$orderId]);
    $total = $stmt->fetchColumn();

    $sql2 = "SELECT SUM(pn.quantity_per_unit * m.price * oi.quantity) 
             FROM order_items oi
             JOIN production_norms pn ON oi.product_id = pn.product_id
             JOIN materials m ON pn.material_id = m.id
             WHERE oi.order_id = ?";
    $stmt2 = $pdo->prepare($sql2);
    $stmt2->execute([$orderId]);
    $totalMaterials = $stmt2->fetchColumn();

    return $total + ($totalMaterials ?? 0);
}

// --- Логирование ---
function logAction($pdo, $userId, $action) {
    $ip = $_SERVER['REMOTE_ADDR'];
    $stmt = $pdo->prepare("INSERT INTO logs (user_id, action, ip, created_at) VALUES (?, ?, ?, NOW())");
    $stmt->execute([$userId, $action, $ip]);
}
/**
 * Универсальная валидация строковых полей
 * @param string $value Проверяемое значение
 * @param array $rules Правила: ['required' => bool, 'min' => int, 'max' => int, 'regex' => string, 'forbidden_chars' => array]
 * @return array ['isValid' => bool, 'error' => string]
 */
function validateField($value, $rules = []) {
    $value = trim($value);
    // Обязательное поле
    if (isset($rules['required']) && $rules['required'] && empty($value)) {
        return ['isValid' => false, 'error' => 'Поле обязательно для заполнения'];
    }
    // Длина
    if (isset($rules['min']) && mb_strlen($value, 'UTF-8') < $rules['min']) {
        return ['isValid' => false, 'error' => "Минимальная длина: {$rules['min']} символов"];
    }
    if (isset($rules['max']) && mb_strlen($value, 'UTF-8') > $rules['max']) {
        return ['isValid' => false, 'error' => "Максимальная длина: {$rules['max']} символов"];
    }
    // Запрещённые символы
    if (isset($rules['forbidden_chars'])) {
        foreach ($rules['forbidden_chars'] as $char) {
            if (strpos($value, $char) !== false) {
                return ['isValid' => false, 'error' => "Поле содержит запрещённый символ '$char'"];
            }
        }
    }
    // Регулярное выражение
    if (isset($rules['regex']) && !preg_match($rules['regex'], $value)) {
        return ['isValid' => false, 'error' => 'Значение не соответствует формату'];
    }
    return ['isValid' => true, 'error' => ''];
}
?>
```

## File: work/index.php
```php
<?php
session_start();
if (!isset($_SESSION['user'])) {
    header('Location: login.php');
    exit;
}
include 'templates/header.php';
?>
<div class="container mt-4">
    <?php if (isset($_SESSION['flash'])): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?= htmlspecialchars($_SESSION['flash']) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php unset($_SESSION['flash']); ?>
    <?php endif; ?>

    <h1>Добро пожаловать, <?= htmlspecialchars($_SESSION['user']['login']) ?></h1>
    <div class="row mt-4">
        <div class="col-md-4">
            <a href="modules/calc_order.php?id=1" class="btn btn-success w-100 p-3">🧮 Расчёт заказа</a>
        </div>
        <div class="col-md-4">
            <a href="modules/api_client.php" class="btn btn-info w-100 p-3">🔌 API эмулятор</a>
        </div>
        <div class="col-md-4">
            <a href="modules/upload.php" class="btn btn-warning w-100 p-3">📤 Загрузка</a>
        </div>
        <div class="col-md-4">
            <a href="modules/todo.php" class="btn btn-dark w-100 p-3">📋 Список задач</a>
        </div>
        <div class="col-md-4">
            <a href="modules/profile.php" class="btn btn-secondary w-100 p-3">👤 Профиль</a>
        </div>
        <div class="col-md-4">
            <a href="admin/index.php" class="btn btn-primary w-100 p-3">👤 Админка (CRUD)</a>
        </div>
        <div class="col-md-4">
            <a href="logout.php" class="btn btn-danger w-100 p-3">🚪 Выход</a>
        </div>
    </div>
</div>
<?php include 'templates/footer.php'; ?>
```

## File: work/login.php
```php
<?php
session_start();
require_once 'config.php';
require_once 'functions.php';

if (isset($_SESSION['user'])) {
    header('Location: index.php');
    exit;
}

$error = '';

// --- Обработка AJAX-проверки капчи ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['captcha_order'])) {
    $order = json_decode($_POST['captcha_order'], true);
    $correct = [1, 2, 3, 4];
    if ($order == $correct) {
        $_SESSION['captcha_passed'] = true;
        echo json_encode(['success' => true]);
    } else {
        $_SESSION['captcha_attempts'] = ($_SESSION['captcha_attempts'] ?? 0) + 1;
        if ($_SESSION['captcha_attempts'] >= 3) {
            echo json_encode(['success' => false, 'blocked' => true]);
        } else {
            echo json_encode(['success' => false, 'blocked' => false]);
        }
    }
    exit;
}

// --- Обычная отправка формы ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !isset($_POST['captcha_order'])) {
    if (!isset($_SESSION['captcha_passed']) || $_SESSION['captcha_passed'] !== true) {
        $error = '❌ Сначала соберите пазл из 4 фрагментов!';
    } else {
        $login = trim($_POST['login'] ?? '');
        $password = $_POST['password'] ?? '';
        $user = checkLogin($pdo, $login, $password);
        if ($user) {
            if ($user['blocked'] == 1) {
                $error = '🚫 Вы заблокированы. Обратитесь к администратору.';
            } else {
                $_SESSION['user'] = $user;
                header('Location: index.php');
                exit;
            }
        } else {
            $error = 'Вы ввели неверный логин или пароль. Пожалуйста проверьте ещё раз введенные данные.';
        }
    }
}

include 'templates/header.php';
?>
<div class="container mt-5" style="max-width: 600px;">
    <h2 class="mb-4">Вход в систему</h2>
    <?php if ($error): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form method="post" id="loginForm">
        <div class="row">
            <div class="col-md-6">
                <div class="mb-3">
                    <label for="login">Логин</label>
                    <input type="text" name="login" id="login" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label for="password">Пароль</label>
                    <input type="password" name="password" id="password" class="form-control" required>
                </div>
                <button type="submit" id="loginBtn" class="btn btn-primary w-100" disabled>Войти</button>
            </div>
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header bg-secondary text-white">Соберите пазл</div>
                    <div class="card-body">
                        <p class="small text-muted">Перетащите фрагменты в пустые ячейки.<br>
                        Правильный порядок: 1 (левый верх) → 2 (правый верх) → 3 (левый низ) → 4 (правый низ).</p>
                        <div id="puzzleGrid" class="d-flex flex-wrap" style="width: 166px; height: 166px;"></div>
                        <div id="puzzlePool" class="d-flex flex-wrap gap-2 mt-3"></div>
                        <input type="hidden" id="captcha_ok" value="0">
                    </div>
                </div>
            </div>
        </div>
    </form>

    <p class="mt-3 text-center"><a href="register.php">Нет аккаунта? Зарегистрируйтесь</a></p>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const correctOrder = [1, 2, 3, 4];
    let userOrder = [];
    let attempts = 0;
    const grid = document.getElementById('puzzleGrid');
    const pool = document.getElementById('puzzlePool');
    const hidden = document.getElementById('captcha_ok');
    const loginBtn = document.getElementById('loginBtn');

    const imgPath = 'captcha/';

    const pieces = [
        { id: 1, src: imgPath + '1.png', label: '1' },
        { id: 2, src: imgPath + '2.png', label: '2' },
        { id: 3, src: imgPath + '3.png', label: '3' },
        { id: 4, src: imgPath + '4.png', label: '4' }
    ];

    // Создаём сетку 2x2 с пустыми ячейками
    for (let i = 0; i < 4; i++) {
        const slot = document.createElement('div');
        slot.className = 'puzzle-slot';
        slot.style.width = '80px';
        slot.style.height = '80px';
        slot.style.border = '2px dashed #ccc';
        slot.style.background = '#f0f0f0';
        slot.style.borderRadius = '4px';
        slot.dataset.expected = i + 1;
        slot.dataset.filled = 'false';
        slot.addEventListener('dragover', onDragOver);
        slot.addEventListener('drop', onDrop);
        grid.appendChild(slot);
    }

    // Перемешиваем и выводим фрагменты в пул
    const shuffled = [...pieces].sort(() => Math.random() - 0.5);
    shuffled.forEach(piece => {
        const el = document.createElement('div');
        el.className = 'puzzle-piece';
        el.draggable = true;
        el.dataset.id = piece.id;
        el.style.width = '80px';
        el.style.height = '80px';
        el.style.backgroundImage = `url(${piece.src})`;
        el.style.backgroundSize = 'cover';
        el.style.border = '2px solid #999';
        el.style.borderRadius = '4px';
        el.style.cursor = 'grab';
        el.addEventListener('dragstart', onDragStart);
        el.addEventListener('dragend', onDragEnd);
        pool.appendChild(el);
    });

    let draggedElement = null;

    function onDragStart(e) {
        draggedElement = this;
        this.style.opacity = '0.5';
        e.dataTransfer.setData('text/plain', this.dataset.id);
    }

    function onDragEnd(e) {
        this.style.opacity = '1';
    }

    function onDragOver(e) {
        e.preventDefault();
    }

    function onDrop(e) {
        e.preventDefault();
        const slot = this;
        if (slot.dataset.filled === 'true') return;

        const pieceId = parseInt(e.dataTransfer.getData('text/plain'));
        const expected = parseInt(slot.dataset.expected);
        if (pieceId === expected) {
            // Правильно: вставляем фрагмент в ячейку
            slot.style.border = '2px solid green';
            slot.style.background = 'transparent';
            const img = document.createElement('div');
            img.style.width = '80px';
            img.style.height = '80px';
            img.style.backgroundImage = `url(${imgPath + pieceId + '.png'})`;
            img.style.backgroundSize = 'cover';
            slot.appendChild(img);
            slot.dataset.filled = 'true';
            userOrder.push(pieceId);
            if (draggedElement) draggedElement.remove();
            if (userOrder.length === 4) {
                checkPuzzle();
            }
        } else {
            // Неправильно: возвращаем фрагмент в пул
            attempts++;
            if (attempts >= 3) {
                alert('❌ Вы заблокированы! Обратитесь к администратору.');
                document.querySelector('.container').innerHTML = '<h2 class="text-danger">Вы заблокированы.</h2>';
                blockUser();
                return;
            } else {
                alert('❌ Неверный фрагмент! Попробуйте снова.');
                resetPuzzle();
            }
        }
    }

    function resetPuzzle() {
        userOrder = [];
        document.querySelectorAll('.puzzle-slot').forEach(s => {
            s.style.border = '2px dashed #ccc';
            s.style.background = '#f0f0f0';
            s.innerHTML = '';
            s.dataset.filled = 'false';
        });
        pool.innerHTML = '';
        const shuffled = [...pieces].sort(() => Math.random() - 0.5);
        shuffled.forEach(piece => {
            const el = document.createElement('div');
            el.className = 'puzzle-piece';
            el.draggable = true;
            el.dataset.id = piece.id;
            el.style.width = '80px';
            el.style.height = '80px';
            el.style.backgroundImage = `url(${piece.src})`;
            el.style.backgroundSize = 'cover';
            el.style.border = '2px solid #999';
            el.style.borderRadius = '4px';
            el.style.cursor = 'grab';
            el.addEventListener('dragstart', onDragStart);
            el.addEventListener('dragend', onDragEnd);
            pool.appendChild(el);
        });
    }

    function checkPuzzle() {
        let ok = userOrder.every((val, idx) => val === correctOrder[idx]);
        if (ok) {
            hidden.value = '1';
            loginBtn.disabled = false;
            fetch('login.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: 'captcha_order=' + encodeURIComponent(JSON.stringify(userOrder))
            }).then(r => r.json()).then(data => {
                if (data.success) {
                    alert('✅ Пазл собран верно!');
                }
            });
        } else {
            resetPuzzle();
        }
    }

    function blockUser() {
        const login = document.getElementById('login').value;
        if (login) {
            fetch('login.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: 'block_login=' + encodeURIComponent(login)
            });
        }
    }
});
</script>

<style>
.puzzle-slot, .puzzle-piece { box-sizing: border-box; }
</style>
<?php include 'templates/footer.php'; ?>
```

## File: work/logout.php
```php
<?php
session_start();
session_destroy();
header('Location: login.php');
exit;
```

## File: work/register.php
```php
<?php
session_start();
require_once 'config.php';
require_once 'functions.php';

if (isset($_SESSION['user'])) {
    header('Location: index.php');
    exit;
}

$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $login = trim($_POST['login']);
    $pass = $_POST['password'];
    $confirm = $_POST['confirm'];
    $full_name = trim($_POST['full_name']);

    if (empty($login)) $errors[] = "Логин обязателен";
    if (strlen($pass) < 6) $errors[] = "Пароль не менее 6 символов";
    if ($pass !== $confirm) $errors[] = "Пароли не совпадают";
    if (getUserByLogin($pdo, $login)) $errors[] = "Логин уже занят";

    if (empty($errors)) {
        createUser($pdo, $login, $pass, $full_name);
        header('Location: login.php');
        exit;
    }
}
include 'templates/header.php';
?>
<div class="container mt-5" style="max-width:400px;">
    <h2>Регистрация</h2>
    <?php foreach ($errors as $e): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($e) ?></div>
    <?php endforeach; ?>
    <form method="post">
        <div class="mb-3"><label>Логин</label><input type="text" name="login" class="form-control" required></div>
        <div class="mb-3"><label>Имя</label><input type="text" name="full_name" class="form-control"></div>
        <div class="mb-3"><label>Пароль</label><input type="password" name="password" class="form-control" required></div>
        <div class="mb-3"><label>Подтверждение</label><input type="password" name="confirm" class="form-control" required></div>
        <button type="submit" class="btn btn-primary w-100">Зарегистрироваться</button>
    </form>
    <p class="mt-3 text-center"><a href="login.php">Уже есть аккаунт?</a></p>
</div>
<?php include 'templates/footer.php'; ?>
```

## File: work/tasks.json
```json
[{"id":1780507149,"text":"11","done":false}]
```

## File: work/testcase.csv
```
"2026-06-03 19:24:26",,Успешно
"2026-06-03 19:24:29",,Успешно
"2026-06-03 19:24:29",,Успешно
"2026-06-03 19:24:33",,Успешно
"2026-06-04 00:01:48",,Успешно
"2026-06-04 00:01:49",,Успешно
"2026-06-04 00:01:49",,Успешно
"2026-06-04 00:04:45","Лебедев? Лебедь? Лебедевич",Успешно
"2026-06-04 00:05:13","Петров Петр Петрович",Успешно
"2026-06-04 00:05:16","Соколов& Сокол& Соколович",Успешно
"2026-06-04 00:06:22",,Успешно
"2026-06-04 00:06:35","Морозов* Морозов* Морозович",Успешно
"2026-06-04 00:09:39","Лебедев? Лебедь? Лебедевич","Не успешно"
"2026-06-04 00:11:01","Морозов: Морозов: Морозович","Не успешно"
"2026-06-04 00:11:06","Степанов= Степан= Степанович","Не успешно"
"2026-06-04 00:11:07","Соколов| Сокол| Соколович","Не успешно"
"2026-06-04 00:11:08","Лебедев) Лебедь) Лебедевич","Не успешно"
"2026-06-04 00:11:10","Васильев Василий Васильевич",Успешно
"2026-06-04 00:19:21","Морозов Морозов Морозович",Успешно
"2026-06-04 00:19:23","Иванов+ Иван+ Иванович","Не успешно"
```

## File: work/work_auth (4).sql
```sql
-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1
-- Время создания: Июн 04 2026 г., 00:32
-- Версия сервера: 5.5.23
-- Версия PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `work_auth`
--

-- --------------------------------------------------------

--
-- Структура таблицы `customers`
--

CREATE TABLE `customers` (
  `id` varchar(20) NOT NULL,
  `name` varchar(255) NOT NULL,
  `inn` varchar(20) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `salesman` tinyint(1) DEFAULT '0',
  `buyer` tinyint(1) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `customers`
--

INSERT INTO `customers` (`id`, `name`, `inn`, `address`, `phone`, `salesman`, `buyer`) VALUES
('000000001', 'ООО \"Поставка\"', '', 'г.Пятигорск', '+79198634592', 1, 1),
('000000002', 'ООО \"Кинотеатр Квант\"', '26320045123', 'г. Железноводск, ул. Мира, 123', '+79884581555', 1, 0),
('000000003', 'ООО \"Ромашка\"', '4140784214', 'г. Омск, ул. Строителей, 294', '+79882584546', 0, 1),
('000000008', 'ООО \"Новый JDTO\"', '26320045111', 'г. Железноводсу', '+79884581555', 1, 0),
('000000009', 'ООО \"Ипподром\"', '5874045632', 'г. Уфа, ул. Набережная,  37', '+79627486389', 1, 1),
('000000010', 'ООО \"Ассоль\"', '2629011278', 'г. Калуга, ул. Пушкина, 94', '+79184572398', 0, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `materials`
--

CREATE TABLE `materials` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `code` varchar(50) DEFAULT NULL,
  `price` decimal(10,2) NOT NULL,
  `unit` varchar(20) DEFAULT 'кг'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `materials`
--

INSERT INTO `materials` (`id`, `name`, `code`, `price`, `unit`) VALUES
(1, 'Молоко нормализованное', 'MAT-001', 34.00, 'кг'),
(2, 'Закваска сметанная', 'MAT-002', 45.00, 'кг');

-- --------------------------------------------------------

--
-- Структура таблицы `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `customer_id` varchar(20) DEFAULT NULL,
  `order_date` date DEFAULT NULL,
  `total_amount` decimal(10,2) DEFAULT '0.00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `orders`
--

INSERT INTO `orders` (`id`, `customer_id`, `order_date`, `total_amount`) VALUES
(1, '000000010', '2025-06-06', 2488.00);

-- --------------------------------------------------------

--
-- Структура таблицы `order_items`
--

CREATE TABLE `order_items` (
  `id` int(11) NOT NULL,
  `order_id` int(11) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `quantity` decimal(10,2) NOT NULL,
  `price` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `order_items`
--

INSERT INTO `order_items` (`id`, `order_id`, `product_id`, `quantity`, `price`) VALUES
(1, 1, 1, 12.00, 80.00),
(2, 1, 2, 9.00, 82.00),
(3, 1, 3, 10.00, 79.00);

-- --------------------------------------------------------

--
-- Структура таблицы `production_norms`
--

CREATE TABLE `production_norms` (
  `id` int(11) NOT NULL,
  `product_id` int(11) DEFAULT NULL,
  `material_id` int(11) DEFAULT NULL,
  `quantity_per_unit` decimal(10,4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `production_norms`
--

INSERT INTO `production_norms` (`id`, `product_id`, `material_id`, `quantity_per_unit`) VALUES
(1, 4, 1, 0.9000),
(2, 4, 2, 0.0700);

-- --------------------------------------------------------

--
-- Структура таблицы `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `code` varchar(50) DEFAULT NULL,
  `price` decimal(10,2) NOT NULL,
  `unit` varchar(20) DEFAULT 'шт'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `products`
--

INSERT INTO `products` (`id`, `name`, `code`, `price`, `unit`) VALUES
(1, 'Кефир 2,5% 900г', 'KEF-001', 80.00, 'шт'),
(2, 'Кефир 3,2% 900г', 'KEF-002', 82.00, 'шт'),
(3, 'Молоко 2,5% 900г', 'MOL-001', 70.00, 'шт'),
(4, 'Сметана классическая 15% 540г', 'SME-001', 89.00, 'шт');

-- --------------------------------------------------------

--
-- Структура таблицы `tasks`
--

CREATE TABLE `tasks` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `text` text NOT NULL,
  `done` tinyint(1) DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `login` varchar(50) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `full_name` varchar(100) DEFAULT NULL,
  `blocked` tinyint(1) DEFAULT '0',
  `role` enum('user','admin') DEFAULT 'user',
  `failed_attempts` int(11) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `login`, `password_hash`, `full_name`, `blocked`, `role`, `failed_attempts`) VALUES
(1, 'admin', '$2y$10$TYy.BHLy78LFpHWupPit3OjzYnvGPxnj3.AYVgiBmeatqQCdQyYEO', 'Администратор', 0, 'admin', 0);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `materials`
--
ALTER TABLE `materials`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `customer_id` (`customer_id`);

--
-- Индексы таблицы `order_items`
--
ALTER TABLE `order_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_id` (`order_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Индексы таблицы `production_norms`
--
ALTER TABLE `production_norms`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_id` (`product_id`),
  ADD KEY `material_id` (`material_id`);

--
-- Индексы таблицы `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `tasks`
--
ALTER TABLE `tasks`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `login` (`login`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `materials`
--
ALTER TABLE `materials`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT для таблицы `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT для таблицы `order_items`
--
ALTER TABLE `order_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT для таблицы `production_norms`
--
ALTER TABLE `production_norms`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT для таблицы `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT для таблицы `tasks`
--
ALTER TABLE `tasks`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
```
